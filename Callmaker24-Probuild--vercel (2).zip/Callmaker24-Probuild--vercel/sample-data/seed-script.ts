/**
 * Seed script to populate development database with sample data
 */

import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand } from '@aws-sdk/lib-dynamodb';
import { readFileSync } from 'fs';
import { parse } from 'csv-parse/sync';
import { v4 as uuidv4 } from 'uuid';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);

const CUSTOMERS_TABLE = process.env.DYNAMODB_CUSTOMERS_TABLE || 'marketing-platform-customers-development';
const CAMPAIGNS_TABLE = process.env.DYNAMODB_CAMPAIGNS_TABLE || 'marketing-platform-campaigns-development';
const TENANT_ID = 'default';

async function seedCustomers() {
  console.log('Seeding customers...');

  const csvContent = readFileSync('./sample-data/customers.csv', 'utf-8');
  const records = parse(csvContent, {
    columns: true,
    skip_empty_lines: true,
  });

  for (const record of records) {
    const customer = {
      id: uuidv4(),
      email: record.email,
      firstName: record.firstName,
      lastName: record.lastName,
      company: record.company,
      phoneNumber: record.phoneNumber,
      status: 'ACTIVE',
      tags: record.tags.split(',').map((t: string) => t.trim()),
      customFields: JSON.parse(record.customFields),
      segments: [],
      emailOptIn: true,
      smsOptIn: true,
      tenantId: TENANT_ID,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await docClient.send(
      new PutCommand({
        TableName: CUSTOMERS_TABLE,
        Item: customer,
      })
    );

    console.log(`✓ Created customer: ${customer.email}`);
  }

  console.log(`✓ Seeded ${records.length} customers`);
}

async function seedCampaigns() {
  console.log('Seeding campaigns...');

  const campaigns = [
    {
      id: uuidv4(),
      name: 'Welcome Email Campaign',
      type: 'EMAIL',
      status: 'DRAFT',
      subject: 'Welcome to Marketing Platform Pro!',
      content: 'Thank you for joining us. We\'re excited to help you grow your business.',
      htmlContent: '<h1>Welcome!</h1><p>Thank you for joining us. We\'re excited to help you grow your business.</p>',
      fromEmail: 'noreply@yourdomain.com',
      fromName: 'Marketing Platform Pro',
      segments: [],
      tags: ['onboarding', 'automated'],
      recipients: 0,
      tenantId: TENANT_ID,
      createdBy: 'admin',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: uuidv4(),
      name: 'Monthly Newsletter',
      type: 'EMAIL',
      status: 'DRAFT',
      subject: 'Your Monthly Update - {{month}}',
      content: 'Here\'s what\'s new this month...',
      htmlContent: '<h1>Monthly Update</h1><p>Here\'s what\'s new this month...</p>',
      fromEmail: 'newsletter@yourdomain.com',
      fromName: 'Marketing Platform Pro',
      segments: [],
      tags: ['newsletter', 'recurring'],
      recipients: 0,
      tenantId: TENANT_ID,
      createdBy: 'admin',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: uuidv4(),
      name: 'Product Launch SMS',
      type: 'SMS',
      status: 'DRAFT',
      content: 'Exciting news! Check out our new features: {{link}}',
      segments: [],
      tags: ['product-launch', 'sms'],
      recipients: 0,
      tenantId: TENANT_ID,
      createdBy: 'admin',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ];

  for (const campaign of campaigns) {
    await docClient.send(
      new PutCommand({
        TableName: CAMPAIGNS_TABLE,
        Item: campaign,
      })
    );

    console.log(`✓ Created campaign: ${campaign.name}`);
  }

  console.log(`✓ Seeded ${campaigns.length} campaigns`);
}

async function main() {
  try {
    console.log('Starting seed process...\n');

    await seedCustomers();
    console.log('');
    await seedCampaigns();

    console.log('\n✅ Seed completed successfully!');
  } catch (error) {
    console.error('❌ Seed failed:', error);
    process.exit(1);
  }
}

main();
