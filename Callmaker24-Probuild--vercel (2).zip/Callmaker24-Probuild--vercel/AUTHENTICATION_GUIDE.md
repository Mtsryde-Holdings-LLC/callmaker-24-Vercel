# Authentication & Authorization System Guide

## Overview

Complete role-based access control (RBAC) system with Super Admin and Admin roles, including subscription-tier-based permissions.

---

## Table of Contents

1. [User Roles](#user-roles)
2. [Subscription Tiers](#subscription-tiers)
3. [Permissions System](#permissions-system)
4. [API Endpoints](#api-endpoints)
5. [Usage Examples](#usage-examples)
6. [Security Features](#security-features)
7. [Database Schema](#database-schema)

---

## User Roles

### 1. SUPER_ADMIN
- **Full Access**: Complete access to all system features
- **Capabilities**:
  - Manage all users across all tenants
  - Assign roles to any user
  - Access all data and functionality
  - Create other Super Admins and Admins
  - Override all permission restrictions

### 2. ADMIN
- **Subscription-Based Access**: Access determined by subscription tier
- **Capabilities**:
  - Manage users within their tenant
  - Assign roles to users (except Super Admin)
  - Access features based on subscription tier
  - Configure system settings for their tenant

### 3. USER
- **Limited Access**: Basic user with read-only capabilities
- **Capabilities**:
  - View customers
  - View campaigns
  - View analytics
  - Cannot modify data

### 4. GUEST
- **Read-Only Access**: Very limited access
- **Capabilities**:
  - View customers (read-only)
  - View campaigns (read-only)
  - No modification permissions

---

## Subscription Tiers

### 1. FREE Tier
**Permissions**:
- `CUSTOMER_READ` - View customers
- `CAMPAIGN_READ` - View campaigns
- `ANALYTICS_VIEW` - View analytics

### 2. STARTER Tier
**Includes FREE +**:
- `CUSTOMER_CREATE` - Create customers
- `CUSTOMER_UPDATE` - Update customers
- `CAMPAIGN_CREATE` - Create campaigns
- `CAMPAIGN_UPDATE` - Update campaigns
- `EMAIL_SEND` - Send emails
- `SMS_SEND` - Send SMS messages

### 3. PROFESSIONAL Tier
**Includes STARTER +**:
- `CUSTOMER_DELETE` - Delete customers
- `CUSTOMER_IMPORT` - Import customers (CSV/Excel)
- `CUSTOMER_EXPORT` - Export customers
- `CAMPAIGN_DELETE` - Delete campaigns
- `CAMPAIGN_SEND` - Send campaigns
- `EMAIL_TEMPLATE_MANAGE` - Manage email templates
- `SMS_TEMPLATE_MANAGE` - Manage SMS templates
- `SMS_CONVERSATION_MANAGE` - Manage two-way SMS
- `SOCIAL_CONTENT_CREATE` - Create social media content
- `SOCIAL_CONTENT_PUBLISH` - Publish to social media
- `ANALYTICS_EXPORT` - Export analytics reports

### 4. ENTERPRISE Tier
**Includes PROFESSIONAL +**:
- `USER_CREATE` - Create users
- `USER_READ` - View users
- `USER_UPDATE` - Update users
- `VOICE_CALL_INITIATE` - Initiate voice calls
- `VOICE_FLOW_MANAGE` - Manage IVR flows
- `VOICE_ANALYTICS_VIEW` - View call analytics
- `SOCIAL_ACCOUNT_MANAGE` - Manage social accounts
- `INTEGRATION_MANAGE` - Manage integrations
- `BILLING_MANAGE` - Manage billing
- `SUBSCRIPTION_MANAGE` - Manage subscriptions

---

## Permissions System

### Complete Permission List

**User Management:**
- `USER_CREATE` - Create new users
- `USER_READ` - View user details
- `USER_UPDATE` - Update user information
- `USER_DELETE` - Delete users
- `USER_ASSIGN_ROLES` - Assign roles to users

**Customer Management:**
- `CUSTOMER_CREATE` - Create customers
- `CUSTOMER_READ` - View customers
- `CUSTOMER_UPDATE` - Update customers
- `CUSTOMER_DELETE` - Delete customers
- `CUSTOMER_IMPORT` - Import customer data
- `CUSTOMER_EXPORT` - Export customer data

**Campaign Management:**
- `CAMPAIGN_CREATE` - Create campaigns
- `CAMPAIGN_READ` - View campaigns
- `CAMPAIGN_UPDATE` - Update campaigns
- `CAMPAIGN_DELETE` - Delete campaigns
- `CAMPAIGN_SEND` - Send campaigns

**Email Marketing:**
- `EMAIL_SEND` - Send emails
- `EMAIL_TEMPLATE_MANAGE` - Manage email templates

**SMS Marketing:**
- `SMS_SEND` - Send SMS messages
- `SMS_TEMPLATE_MANAGE` - Manage SMS templates
- `SMS_CONVERSATION_MANAGE` - Manage conversations

**IVR/Voice:**
- `VOICE_CALL_INITIATE` - Initiate voice calls
- `VOICE_FLOW_MANAGE` - Manage IVR flows
- `VOICE_ANALYTICS_VIEW` - View call analytics

**Social Media:**
- `SOCIAL_CONTENT_CREATE` - Create content
- `SOCIAL_CONTENT_PUBLISH` - Publish content
- `SOCIAL_ACCOUNT_MANAGE` - Manage accounts

**Analytics:**
- `ANALYTICS_VIEW` - View analytics
- `ANALYTICS_EXPORT` - Export reports

**System:**
- `INTEGRATION_MANAGE` - Manage integrations
- `BILLING_MANAGE` - Manage billing
- `SUBSCRIPTION_MANAGE` - Manage subscriptions
- `SYSTEM_SETTINGS` - System settings
- `SYSTEM_LOGS` - View system logs
- `SYSTEM_BACKUP` - System backups

---

## API Endpoints

### Authentication Endpoints

#### 1. Signup
**Endpoint**: `POST /auth/signup`

**Request Body**:
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!",
  "name": "John Doe",
  "role": "USER",
  "subscriptionTier": "FREE",
  "tenantId": "optional-tenant-id"
}
```

**Response**:
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "user_123",
    "email": "user@example.com",
    "name": "John Doe",
    "role": "USER",
    "subscriptionTier": "FREE",
    "permissions": ["CUSTOMER_READ", "CAMPAIGN_READ", "ANALYTICS_VIEW"],
    "tenantId": "tenant_123"
  }
}
```

**Notes**:
- Only Super Admin can create users with `SUPER_ADMIN` or `ADMIN` roles
- Password must meet strength requirements (8+ chars, uppercase, lowercase, number, special char)
- If no `tenantId` provided, one is auto-generated

#### 2. Signin
**Endpoint**: `POST /auth/signin`

**Request Body**:
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!"
}
```

**Response**:
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "user_123",
    "email": "user@example.com",
    "name": "John Doe",
    "role": "ADMIN",
    "subscriptionTier": "PROFESSIONAL",
    "permissions": ["...array of permissions..."],
    "tenantId": "tenant_123"
  }
}
```

---

### User Management Endpoints (Admin/Super Admin)

#### 1. List Users
**Endpoint**: `GET /auth/users`

**Query Parameters**:
- `tenantId` (optional) - Filter by tenant (Super Admin only)

**Headers**:
```
Authorization: Bearer {token}
```

**Response**:
```json
{
  "success": true,
  "users": [
    {
      "id": "user_123",
      "email": "user@example.com",
      "name": "John Doe",
      "role": "USER",
      "subscriptionTier": "FREE",
      "tenantId": "tenant_123",
      "isActive": true,
      "lastLoginAt": "2025-11-04T10:30:00Z",
      "createdAt": "2025-11-01T08:00:00Z"
    }
  ]
}
```

#### 2. Get User Details
**Endpoint**: `GET /auth/users/{userId}`

**Headers**:
```
Authorization: Bearer {token}
```

**Response**:
```json
{
  "success": true,
  "user": {
    "id": "user_123",
    "email": "user@example.com",
    "name": "John Doe",
    "role": "ADMIN",
    "subscriptionTier": "PROFESSIONAL",
    "permissions": ["...array of permissions..."],
    "tenantId": "tenant_123",
    "isActive": true,
    "lastLoginAt": "2025-11-04T10:30:00Z",
    "createdAt": "2025-11-01T08:00:00Z",
    "updatedAt": "2025-11-04T10:30:00Z"
  }
}
```

#### 3. Assign Role (Super Admin Only)
**Endpoint**: `POST /auth/users/assign-role`

**Headers**:
```
Authorization: Bearer {token}
```

**Request Body**:
```json
{
  "userId": "user_123",
  "role": "ADMIN",
  "permissions": ["CUSTOMER_CREATE", "CAMPAIGN_CREATE"],
  "functions": ["sms-marketing", "email-marketing"]
}
```

**Response**:
```json
{
  "success": true,
  "message": "Role assigned successfully",
  "user": {
    "id": "user_123",
    "role": "ADMIN",
    "permissions": ["CUSTOMER_CREATE", "CAMPAIGN_CREATE"],
    "functions": ["sms-marketing", "email-marketing"]
  }
}
```

#### 4. Update User
**Endpoint**: `PUT /auth/users/{userId}`

**Headers**:
```
Authorization: Bearer {token}
```

**Request Body**:
```json
{
  "role": "ADMIN",
  "subscriptionTier": "PROFESSIONAL",
  "permissions": ["...custom permissions..."],
  "isActive": true
}
```

**Response**:
```json
{
  "success": true,
  "message": "User updated successfully"
}
```

**Notes**:
- Admin can only update users in their tenant
- Only Super Admin can change roles
- Changing subscription tier automatically updates permissions

#### 5. Delete User (Super Admin Only)
**Endpoint**: `DELETE /auth/users/{userId}`

**Headers**:
```
Authorization: Bearer {token}
```

**Response**:
```json
{
  "success": true,
  "message": "User deleted successfully"
}
```

---

## Usage Examples

### Example 1: Super Admin Creating an Admin

```javascript
// Step 1: Super Admin signs in
const signinResponse = await fetch('/auth/signin', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'superadmin@company.com',
    password: 'SuperSecure123!'
  })
});

const { token: superAdminToken } = await signinResponse.json();

// Step 2: Super Admin creates a new Admin
const createAdminResponse = await fetch('/auth/signup', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${superAdminToken}`
  },
  body: JSON.stringify({
    email: 'admin@company.com',
    password: 'AdminPassword123!',
    name: 'Admin User',
    role: 'ADMIN',
    subscriptionTier: 'PROFESSIONAL',
    tenantId: 'tenant_company_123'
  })
});

const newAdmin = await createAdminResponse.json();
console.log('New admin created:', newAdmin);
```

### Example 2: Admin Assigning Roles to Users

```javascript
// Admin signs in
const signinResponse = await fetch('/auth/signin', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'admin@company.com',
    password: 'AdminPassword123!'
  })
});

const { token: adminToken } = await signinResponse.json();

// List all users in tenant
const usersResponse = await fetch('/auth/users', {
  headers: { 'Authorization': `Bearer ${adminToken}` }
});

const { users } = await usersResponse.json();
console.log('Tenant users:', users);

// Update a user's subscription tier
await fetch(`/auth/users/${userId}`, {
  method: 'PUT',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${adminToken}`
  },
  body: JSON.stringify({
    subscriptionTier: 'PROFESSIONAL'
  })
});
```

### Example 3: Using Middleware in Lambda Functions

```typescript
import { requirePermission, requireAdmin } from '../../middleware/auth-middleware';
import { Permission } from '../../types/auth';

// Require specific permission
export const createCampaign = requirePermission(Permission.CAMPAIGN_CREATE)(
  async (event: AuthenticatedEvent) => {
    // User has CAMPAIGN_CREATE permission
    const user = event.user;
    // ... create campaign logic
  }
);

// Require admin role
export const viewAllUsers = requireAdmin()(
  async (event: AuthenticatedEvent) => {
    // User is Admin or Super Admin
    // ... view users logic
  }
);
```

---

## Security Features

### 1. Password Security
- **Minimum Length**: 8 characters
- **Requirements**:
  - At least one uppercase letter
  - At least one lowercase letter
  - At least one number
  - At least one special character
- **Hashing**: bcrypt with salt rounds of 10

### 2. JWT Tokens
- **Access Token**: Expires in 1 hour (configurable)
- **Refresh Token**: Expires in 7 days (configurable)
- **Secret Keys**: Environment-based (must be changed in production)
- **Payload Includes**:
  - User ID
  - Email
  - Role
  - Tenant ID
  - Subscription Tier
  - Permissions

### 3. Multi-Tenant Isolation
- Users can only access data from their tenant
- Super Admin can access all tenants
- Tenant ID validated on every request

### 4. Role Hierarchy
```
SUPER_ADMIN (Level 4)
    ↓
  ADMIN (Level 3)
    ↓
   USER (Level 2)
    ↓
  GUEST (Level 1)
```

### 5. Permission Validation
- Middleware automatically checks permissions
- Failed checks return 403 Forbidden
- Permissions cached in JWT token

---

## Database Schema

### Updated User Model (Prisma)

```prisma
model User {
  id                String              @id @default(cuid())
  email             String              @unique
  password          String?
  name              String?
  image             String?
  emailVerified     DateTime?
  role              UserRole            @default(USER)
  subscriptionTier  SubscriptionTier    @default(FREE)
  permissions       String[]            @default([])
  tenantId          String?
  isActive          Boolean             @default(true)
  lastLoginAt       DateTime?
  createdAt         DateTime            @default(now())
  updatedAt         DateTime            @updatedAt

  @@index([tenantId])
  @@index([role])
  @@map("users")
}

enum UserRole {
  SUPER_ADMIN
  ADMIN
  USER
  GUEST
}

enum SubscriptionTier {
  FREE
  STARTER
  PROFESSIONAL
  ENTERPRISE
}
```

### Required DynamoDB Tables

**users table**:
- Primary Key: `id`
- GSI: `email-index` (email as partition key)
- GSI: `tenantId-index` (tenantId as partition key)
- GSI: `role-index` (role as partition key)

---

## Environment Variables

```bash
# JWT Configuration
JWT_SECRET=your-secret-key-change-in-production
JWT_REFRESH_SECRET=your-refresh-secret-key-change-in-production
JWT_EXPIRES_IN=1h
JWT_REFRESH_EXPIRES_IN=7d

# Database
USERS_TABLE=users
AWS_REGION=us-east-1
```

---

## Migration Guide

### Step 1: Update Database Schema

```bash
cd apps/backend
npx prisma migrate dev --name add-auth-system
```

### Step 2: Create DynamoDB Indexes

Create GSIs for:
- `email-index`
- `tenantId-index`
- `role-index`

### Step 3: Create First Super Admin

```bash
# Use the signup endpoint without auth header to create first super admin manually
# Or create directly in database with hashed password
```

### Step 4: Deploy Lambda Functions

Deploy the new authentication Lambda functions:
- `/auth/signup`
- `/auth/signin`
- `/auth/users` (GET)
- `/auth/users/{id}` (GET, PUT, DELETE)
- `/auth/users/assign-role` (POST)

---

## Testing

### Test Signup

```bash
curl -X POST http://localhost:3000/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "TestPassword123!",
    "name": "Test User"
  }'
```

### Test Signin

```bash
curl -X POST http://localhost:3000/auth/signin \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "TestPassword123!"
  }'
```

### Test Protected Endpoint

```bash
curl -X GET http://localhost:3000/auth/users \
  -H "Authorization: Bearer {your-token}"
```

---

## Troubleshooting

### Common Issues

**1. "TOKEN_EXPIRED" Error**
- Token has expired (1 hour default)
- Use refresh token to get new access token

**2. "FORBIDDEN" Error**
- User lacks required permission
- Check user's role and subscription tier
- Verify permission requirements

**3. "WEAK_PASSWORD" Error**
- Password doesn't meet security requirements
- Must include uppercase, lowercase, number, special char
- Minimum 8 characters

**4. "USER_EXISTS" Error**
- Email already registered
- Use different email or signin instead

---

## Best Practices

1. **Never hardcode JWT secrets** - Use environment variables
2. **Always validate tokens** on protected endpoints
3. **Use HTTPS** in production for all requests
4. **Rotate JWT secrets** regularly
5. **Implement rate limiting** on auth endpoints
6. **Log authentication attempts** for security monitoring
7. **Use refresh tokens** to minimize access token lifetime
8. **Validate permissions** at both API Gateway and Lambda levels
9. **Implement account lockout** after failed login attempts
10. **Send email notifications** for security events

---

## Support

For issues or questions:
- Check the troubleshooting section
- Review the API documentation
- Contact system administrator

---

**Last Updated**: 2025-11-04
**Version**: 1.0.0
