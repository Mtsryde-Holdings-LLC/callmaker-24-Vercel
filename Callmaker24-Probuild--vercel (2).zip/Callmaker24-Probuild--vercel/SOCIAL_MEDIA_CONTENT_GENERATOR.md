# AI-Powered Social Media Content Generator

## Overview

A comprehensive Next.js application integrated into your marketing platform that functions as an AI-powered social media content generator with automated scheduling, cross-platform publishing, and engagement analytics.

## Table of Contents

1. [Features](#features)
2. [Architecture](#architecture)
3. [Setup & Installation](#setup--installation)
4. [Configuration](#configuration)
5. [Database Setup](#database-setup)
6. [API Documentation](#api-documentation)
7. [Frontend Components](#frontend-components)
8. [Usage Guide](#usage-guide)
9. [Deployment](#deployment)
10. [Troubleshooting](#troubleshooting)

---

## Features

### ✅ Implemented Features

#### 1. **Content Learning & Analysis**
- ✅ Web scraping to analyze existing content
- ✅ RSS feed integration for blog posts
- ✅ Brand voice and tone extraction using OpenAI GPT-4
- ✅ Content topic identification
- ✅ Keyword extraction from website content

**Location**: `apps/backend/src/services/ai/contentAnalyzer.ts`

#### 2. **AI Content Generation**
- ✅ Post captions with emojis and hashtags
- ✅ Content variations for A/B testing
- ✅ Platform-specific formatting (Twitter, LinkedIn, Facebook, Instagram, TikTok)
- ✅ Hashtag generation
- ✅ Image prompt generation for AI image tools
- ✅ Call-to-action optimization
- ✅ Tone customization (professional, casual, friendly, informative, humorous)

**Location**: `apps/backend/src/services/ai/contentGenerator.ts`

#### 3. **Scheduling & Publishing**
- ✅ EventBridge-based scheduling system
- ✅ Timezone management
- ✅ Bulk scheduling capability
- ✅ Platform-specific formatting
- ✅ Automated posting at scheduled times

**Location**: `apps/backend/src/functions/social-content/`

#### 4. **Social Media Integrations**
- ✅ Twitter/X API integration
- ✅ LinkedIn API integration
- ✅ Facebook Graph API integration
- ✅ Instagram Business API integration
- ✅ Cross-platform posting manager

**Location**: `apps/backend/src/services/social/`

#### 5. **Content Calendar**
- ✅ Calendar view with drag-and-drop
- ✅ Monthly view with post visualization
- ✅ Platform color coding
- ✅ Post detail view
- ✅ Reschedule posts by dragging

**Location**: `apps/frontend/src/app/(dashboard)/content-calendar/page.tsx`

#### 6. **AI Content Generator UI**
- ✅ Comprehensive input form
- ✅ Real-time content preview
- ✅ A/B testing variations
- ✅ Copy to clipboard functionality
- ✅ Schedule or post immediately

**Location**: `apps/frontend/src/app/(dashboard)/content-generator/page.tsx`

---

## Architecture

### Tech Stack

**Backend:**
- AWS Lambda (Serverless functions)
- Node.js + TypeScript
- OpenAI GPT-4 API
- Prisma ORM
- PostgreSQL Database
- AWS EventBridge (Scheduling)

**Frontend:**
- Next.js 14 (App Router)
- React 18
- TypeScript
- Tailwind CSS
- React Query (Data fetching)
- date-fns (Date manipulation)

**Integrations:**
- Twitter/X API v2
- LinkedIn API
- Facebook Graph API
- Instagram Business API
- OpenAI GPT-4

### Directory Structure

```
apps/
├── backend/
│   ├── src/
│   │   ├── functions/
│   │   │   └── social-content/
│   │   │       ├── generateContent.ts      # AI content generation
│   │   │       ├── analyzeWebsite.ts       # Website analysis
│   │   │       ├── schedulePost.ts         # Post scheduling
│   │   │       └── publishPost.ts          # Automated publishing
│   │   └── services/
│   │       ├── ai/
│   │       │   ├── contentGenerator.ts     # OpenAI integration
│   │       │   └── contentAnalyzer.ts      # Content analysis
│   │       └── social/
│   │           ├── twitter.ts              # Twitter integration
│   │           ├── linkedin.ts             # LinkedIn integration
│   │           ├── facebook.ts             # Facebook/Instagram
│   │           └── index.ts                # Unified manager
│   └── prisma/
│       └── schema.prisma                   # Database schema
│
└── frontend/
    └── src/
        └── app/
            └── (dashboard)/
                ├── content-calendar/
                │   └── page.tsx            # Calendar UI
                └── content-generator/
                    └── page.tsx            # Generator UI
```

---

## Setup & Installation

### Prerequisites

- Node.js 18+
- npm or yarn
- PostgreSQL database
- AWS Account (for Lambda and EventBridge)
- OpenAI API key
- Social media API credentials (Twitter, Facebook, LinkedIn, Instagram)

### Installation Steps

1. **Install Dependencies**

```bash
# Backend
cd apps/backend
npm install

# Frontend
cd apps/frontend
npm install
```

2. **Install Additional Packages**

The following packages have been installed:

**Frontend:**
- `cheerio` - Web scraping
- `next-auth` - Authentication
- `@dnd-kit/*` - Drag and drop
- `jspdf` - PDF generation
- `html2canvas` - HTML to canvas

**Backend:**
- `prisma` - Database ORM
- `@prisma/client` - Prisma client
- `cheerio` - Web scraping
- `node-cron` - Scheduling
- `rss-parser` - RSS feed parsing
- `twitter-api-v2` - Twitter API
- `openai` - Already installed

---

## Configuration

### Environment Variables

Create `.env` file in `apps/backend/`:

```bash
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/marketing_platform?schema=public"

# OpenAI
OPENAI_API_KEY="sk-..."

# Twitter/X
TWITTER_API_KEY="..."
TWITTER_API_SECRET="..."
TWITTER_ACCESS_TOKEN="..."
TWITTER_ACCESS_SECRET="..."
TWITTER_BEARER_TOKEN="..."

# LinkedIn
LINKEDIN_CLIENT_ID="..."
LINKEDIN_CLIENT_SECRET="..."
LINKEDIN_ACCESS_TOKEN="..."
LINKEDIN_PERSON_URN="urn:li:person:..."

# Facebook
FACEBOOK_APP_ID="..."
FACEBOOK_APP_SECRET="..."
FACEBOOK_ACCESS_TOKEN="..."
FACEBOOK_PAGE_ID="..."

# Instagram
INSTAGRAM_CLIENT_ID="..."
INSTAGRAM_CLIENT_SECRET="..."
INSTAGRAM_ACCESS_TOKEN="..."
INSTAGRAM_ACCOUNT_ID="..."

# AWS
AWS_REGION="us-east-1"
PUBLISH_POST_LAMBDA_ARN="arn:aws:lambda:..."
```

### Getting API Keys

#### OpenAI API Key
1. Visit https://platform.openai.com/
2. Create account and navigate to API Keys
3. Create new API key
4. Add to `.env` as `OPENAI_API_KEY`

#### Twitter/X API
1. Visit https://developer.twitter.com/
2. Create a new project and app
3. Generate OAuth 2.0 tokens
4. Enable read and write permissions

#### LinkedIn API
1. Visit https://www.linkedin.com/developers/
2. Create a new app
3. Request Marketing Developer Platform access
4. Generate access token with required scopes: `w_member_social`, `r_liteprofile`

#### Facebook/Instagram API
1. Visit https://developers.facebook.com/
2. Create a new app
3. Add Facebook Login and Instagram Basic Display
4. Get Page Access Token for posting
5. Connect Instagram Business Account to Facebook Page

---

## Database Setup

### Initialize Prisma

```bash
cd apps/backend

# Generate Prisma Client
npx prisma generate

# Run migrations
npx prisma migrate dev --name init

# (Optional) Seed database
npx prisma db seed
```

### Database Schema

The schema includes the following models:

- **User** - User accounts with authentication
- **Business** - Business profiles with brand information
- **SocialAccount** - Connected social media accounts
- **Content** - Posts and scheduled content
- **Engagement** - Engagement metrics per post
- **Schedule** - Recurring schedule configurations
- **Analytics** - Aggregated analytics data
- **RSSFeed** - RSS feed sources
- **ContentTemplate** - AI content templates

**Location**: `apps/backend/prisma/schema.prisma`

### Supported Platforms

```typescript
enum Platform {
  TWITTER
  FACEBOOK
  INSTAGRAM
  LINKEDIN
  TIKTOK
}
```

### Content Types

```typescript
enum ContentType {
  POST
  STORY
  TWEET
  ARTICLE
  VIDEO
  IMAGE
  CAROUSEL
  REEL
}
```

---

## API Documentation

### Content Generation

#### Generate Content

**Endpoint**: `POST /api/generate-content`

**Request Body**:
```json
{
  "topic": "New Product Launch",
  "businessType": "SaaS",
  "targetAudience": "Small business owners",
  "platform": "twitter",
  "tone": "professional",
  "contentType": "post",
  "maxLength": 280,
  "includeHashtags": true,
  "includeEmojis": true,
  "includeCallToAction": true,
  "brandVoice": "Innovative and customer-focused",
  "keywords": ["innovation", "productivity"]
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "mainContent": "🚀 Exciting news! We're launching...",
    "hashtags": ["#Innovation", "#SaaS", "#Productivity"],
    "suggestedImages": ["Professional workspace"],
    "bestTimeToPost": "Tuesday, 10 AM - 2 PM",
    "estimatedEngagement": "High (4-6% engagement rate)"
  }
}
```

#### Generate Hashtags

**Endpoint**: `POST /api/generate-hashtags`

**Request Body**:
```json
{
  "content": "Check out our new product!",
  "platform": "instagram",
  "count": 10
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "hashtags": [
      "#NewProduct",
      "#Innovation",
      "#Tech",
      ...
    ]
  }
}
```

### Website Analysis

#### Analyze Website

**Endpoint**: `POST /api/analyze-website`

**Request Body**:
```json
{
  "url": "https://example.com",
  "analyzeBrand": true
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "websiteData": {
      "title": "Company Name",
      "description": "...",
      "keywords": ["..."],
      "headings": ["..."]
    },
    "brandAnalysis": {
      "brandVoice": "Professional and innovative",
      "themes": ["technology", "innovation"],
      "keywords": ["cloud", "automation"],
      "tone": "professional"
    }
  }
}
```

### Scheduling

#### Schedule Post

**Endpoint**: `POST /api/schedule-post`

**Request Body**:
```json
{
  "businessId": "clx...",
  "platform": "TWITTER",
  "content": "Great content here!",
  "scheduledAt": "2025-11-10T14:00:00Z",
  "mediaUrls": ["https://..."],
  "hashtags": ["#Example"]
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "message": "Post scheduled successfully",
    "scheduledAt": "2025-11-10T14:00:00Z",
    "ruleName": "social-post-clx...-1234567890"
  }
}
```

#### Get Scheduled Posts

**Endpoint**: `GET /api/scheduled-posts?businessId=clx...`

**Response**:
```json
{
  "success": true,
  "data": [
    {
      "id": "clx...",
      "platform": "TWITTER",
      "content": "...",
      "scheduledAt": "2025-11-10T14:00:00Z",
      "status": "SCHEDULED"
    }
  ]
}
```

### Publishing

#### Publish Post Immediately

**Endpoint**: `POST /api/publish-post`

**Request Body**:
```json
{
  "businessId": "clx...",
  "platforms": ["twitter", "linkedin"],
  "content": "Great content!",
  "mediaUrl": "https://...",
  "link": "https://..."
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "results": [
      {
        "platform": "twitter",
        "success": true,
        "postId": "1234567890"
      },
      {
        "platform": "linkedin",
        "success": true,
        "postId": "urn:li:share:..."
      }
    ]
  }
}
```

---

## Frontend Components

### Content Calendar

**Route**: `/content-calendar`

**Features**:
- Monthly calendar view
- Drag-and-drop post rescheduling
- Platform color coding
- Post details on click
- Scheduled vs published status

**Usage**:
1. Navigate to Content Calendar
2. View scheduled posts by date
3. Drag posts to reschedule
4. Click date to see all posts
5. Edit or delete posts

### Content Generator

**Route**: `/content-generator`

**Features**:
- AI-powered content generation
- Platform selection
- Tone and style customization
- A/B testing variations
- Hashtag suggestions
- Best posting time recommendations
- Copy to clipboard
- Schedule or post immediately

**Usage**:
1. Fill in content parameters
2. Select platform and tone
3. Click "Generate Content"
4. Review generated content
5. Generate variations for A/B testing
6. Schedule or post immediately

---

## Usage Guide

### Complete Workflow Example

#### 1. Analyze Your Brand

```bash
# Use the website analyzer to understand your brand
POST /api/analyze-website
{
  "url": "https://yourbusiness.com",
  "analyzeBrand": true
}
```

This extracts:
- Brand voice
- Key themes
- Important keywords
- Communication style

#### 2. Generate Content

Visit `/content-generator` and:
1. Enter your topic
2. Select target platform
3. Choose tone (professional, casual, etc.)
4. Add keywords
5. Click "Generate Content"

The AI will create:
- Optimized post content
- Relevant hashtags
- Image suggestions
- Best posting time
- Engagement estimate

#### 3. Create Variations

Click "Generate A/B Test Variations" to get:
- 3 different versions
- Different approaches
- Varied hashtags

#### 4. Schedule Posts

Option A - From Generator:
1. Click "Schedule Post"
2. Select date and time
3. Confirm

Option B - Content Calendar:
1. Navigate to `/content-calendar`
2. Click on a date
3. Add new post
4. Set time
5. Save

#### 5. Monitor & Reschedule

In Content Calendar:
- Drag posts to reschedule
- View upcoming posts
- Check post status
- Edit content before publishing

---

## Deployment

### AWS Lambda Functions

The system uses AWS Lambda for serverless API handling:

**Functions to Deploy**:

1. **generateContent** - Content generation
2. **analyzeWebsite** - Website analysis
3. **schedulePost** - Scheduling
4. **publishPost** - Automated publishing

**Deployment Steps**:

```bash
cd apps/backend

# Build TypeScript
npm run build

# Package for Lambda
npm run package:zip

# Deploy to AWS (using CDK or Serverless Framework)
# Update infra/lib with new Lambda functions
```

### EventBridge Rules

Scheduled posts use EventBridge:

**What Happens**:
1. User schedules post → Creates EventBridge rule
2. At scheduled time → EventBridge triggers `publishPost` Lambda
3. Lambda posts to social media
4. Updates database status
5. Deletes EventBridge rule

**Required Permissions**:
```json
{
  "Effect": "Allow",
  "Action": [
    "events:PutRule",
    "events:PutTargets",
    "events:RemoveTargets",
    "events:DeleteRule"
  ],
  "Resource": "*"
}
```

### Database Migration

```bash
# Production migration
npx prisma migrate deploy

# Check status
npx prisma migrate status
```

### Environment Variables

Set in AWS Lambda:
- All API keys
- Database URL
- Lambda ARNs

---

## Troubleshooting

### Common Issues

#### 1. Prisma Engine Download Fails

**Error**: `Failed to fetch the engine file`

**Solution**:
```bash
# Use environment variable
PRISMA_ENGINES_CHECKSUM_IGNORE_MISSING=1 npx prisma generate
```

#### 2. OpenAI API Rate Limit

**Error**: `Rate limit exceeded`

**Solutions**:
- Add delays between requests
- Implement request queuing
- Upgrade OpenAI plan

#### 3. Social Media API Errors

**Twitter 403 Forbidden**:
- Check API credentials
- Verify app permissions
- Ensure elevated access

**Facebook/Instagram Errors**:
- Verify page connection
- Check token expiration
- Refresh access token

#### 4. EventBridge Not Triggering

**Check**:
- Rule is ENABLED
- Target Lambda has correct ARN
- Lambda has EventBridge permissions
- Cron expression is valid

#### 5. Posts Not Publishing

**Debug Steps**:
1. Check Lambda logs in CloudWatch
2. Verify social media credentials in database
3. Test API credentials manually
4. Check platform API status

### Logging

**Backend Logging**:
```typescript
console.log('Publishing scheduled post:', event.detail);
console.error('Error publishing post:', error);
```

**Check CloudWatch Logs**:
```bash
aws logs tail /aws/lambda/publishPost --follow
```

---

## Security Considerations

### API Key Storage

**❌ Don't:**
- Hardcode API keys
- Commit keys to Git
- Store in frontend

**✅ Do:**
- Use AWS Secrets Manager
- Store in environment variables
- Rotate keys regularly
- Use separate keys for dev/prod

### Database Security

```typescript
// Use Prisma prepared statements (automatic)
await prisma.content.findMany({
  where: { businessId: userInput } // Safe from SQL injection
});
```

### Rate Limiting

```typescript
// Implement rate limiting for API routes
const rateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
```

### Input Validation

```typescript
// Validate all user inputs
if (!topic || !businessType || !targetAudience) {
  return { statusCode: 400, body: 'Missing required fields' };
}
```

---

## Future Enhancements

### Potential Features

1. **Image Generation**
   - DALL-E integration
   - Canva template integration
   - Automatic image creation

2. **Advanced Analytics**
   - Competitor analysis
   - Trend detection
   - Sentiment analysis
   - ROI tracking

3. **Content Library**
   - Save successful posts
   - Template management
   - Content reuse suggestions

4. **Team Collaboration**
   - Approval workflows
   - Content review
   - Multi-user access

5. **Additional Platforms**
   - Pinterest
   - YouTube
   - TikTok (full integration)

6. **AI Improvements**
   - GPT-4 Vision for image analysis
   - Voice/tone learning from past posts
   - Automatic content optimization

---

## Support

For issues and questions:
- Check CloudWatch logs
- Review API documentation
- Test with Postman/cURL
- Check platform API status pages

---

## License

Part of the Callmaker24 Marketing Platform
