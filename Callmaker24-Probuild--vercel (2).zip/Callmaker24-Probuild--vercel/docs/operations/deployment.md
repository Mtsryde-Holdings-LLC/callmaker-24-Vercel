# Deployment Guide

## Prerequisites

### Required Tools

```bash
# Install Node.js 18+
node --version  # Should be >= 18.0.0

# Install npm
npm --version   # Should be >= 9.0.0

# Install AWS CLI
aws --version   # Should be >= 2.0.0

# Install AWS CDK
npm install -g aws-cdk
cdk --version   # Should be >= 2.100.0
```

### AWS Account Setup

1. **Create AWS Account** (if you don't have one)
   - Go to https://aws.amazon.com
   - Sign up for a new account
   - Complete verification

2. **Configure AWS CLI**
   ```bash
   aws configure
   # Enter your Access Key ID
   # Enter your Secret Access Key
   # Enter default region (e.g., us-east-1)
   # Enter default output format (json)
   ```

3. **Verify Credentials**
   ```bash
   aws sts get-caller-identity
   ```

### External Service Accounts

1. **Stripe Account** (for payments)
   - Sign up at https://stripe.com
   - Get API keys from Dashboard
   - Configure webhooks

2. **OpenAI Account** (for AI features)
   - Sign up at https://openai.com
   - Create API key
   - Set usage limits

3. **SES Setup** (for email)
   ```bash
   # Request production access
   aws ses verify-email-identity --email-address your-email@domain.com

   # Move out of sandbox
   # Go to AWS Console > SES > Account Dashboard > Request Production Access
   ```

## Local Development Setup

### 1. Clone and Install

```bash
# Clone repository
git clone <repository-url>
cd marketing-platform

# Install all dependencies
npm install
```

### 2. Configure Environment

```bash
# Copy environment template
cp .env.example .env.local

# Edit .env.local with your values
nano .env.local
```

Required environment variables:
```env
# AWS
AWS_REGION=us-east-1
AWS_ACCOUNT_ID=your-account-id

# These will be populated after deployment
NEXT_PUBLIC_COGNITO_USER_POOL_ID=
NEXT_PUBLIC_COGNITO_CLIENT_ID=
NEXT_PUBLIC_API_URL=

# External services
STRIPE_SECRET_KEY=sk_test_...
OPENAI_API_KEY=sk-...
```

### 3. Run Development Server

```bash
# Start Next.js development server
npm run dev

# Or run specific workspaces
npm run dev --workspace=apps/frontend
```

Navigate to http://localhost:3000

## Infrastructure Deployment

### First-Time Deployment

#### Step 1: Bootstrap CDK

```bash
# Navigate to infrastructure directory
cd infra

# Install dependencies
npm install

# Bootstrap CDK (only needed once per account/region)
export AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
export AWS_REGION=us-east-1

cdk bootstrap aws://$AWS_ACCOUNT_ID/$AWS_REGION
```

#### Step 2: Review Stack Changes

```bash
# See what will be deployed
cdk synth

# Review differences (first time will show all new resources)
cdk diff
```

#### Step 3: Deploy All Stacks

```bash
# Deploy all stacks to development
npm run deploy:dev

# Or deploy specific stacks
cdk deploy MarketingPlatform-Auth-development
cdk deploy MarketingPlatform-Database-development
cdk deploy MarketingPlatform-Storage-development
cdk deploy MarketingPlatform-Messaging-development
cdk deploy MarketingPlatform-Api-development
cdk deploy MarketingPlatform-Monitoring-development
```

#### Step 4: Capture Outputs

After deployment, note the outputs:

```bash
# User Pool ID
export USER_POOL_ID=$(aws cloudformation describe-stacks \
  --stack-name MarketingPlatform-Auth-development \
  --query 'Stacks[0].Outputs[?OutputKey==`UserPoolId`].OutputValue' \
  --output text)

# User Pool Client ID
export CLIENT_ID=$(aws cloudformation describe-stacks \
  --stack-name MarketingPlatform-Auth-development \
  --query 'Stacks[0].Outputs[?OutputKey==`UserPoolClientId`].OutputValue' \
  --output text)

# API URL
export API_URL=$(aws cloudformation describe-stacks \
  --stack-name MarketingPlatform-Api-development \
  --query 'Stacks[0].Outputs[?OutputKey==`ApiUrl`].OutputValue' \
  --output text)

# Save to .env.local
echo "NEXT_PUBLIC_COGNITO_USER_POOL_ID=$USER_POOL_ID" >> ../.env.local
echo "NEXT_PUBLIC_COGNITO_CLIENT_ID=$CLIENT_ID" >> ../.env.local
echo "NEXT_PUBLIC_API_URL=$API_URL" >> ../.env.local
```

### Production Deployment

#### Pre-deployment Checklist

- [ ] All tests passing
- [ ] Code reviewed and approved
- [ ] Environment variables configured
- [ ] Database backups enabled
- [ ] Monitoring and alarms configured
- [ ] SES out of sandbox
- [ ] Domain/SSL certificate configured
- [ ] Secrets stored in Secrets Manager

#### Deploy to Production

```bash
# Deploy to production (requires approval)
cd infra
npm run deploy:prod

# Or use CI/CD (recommended)
git tag -a v1.0.0 -m "Release v1.0.0"
git push origin v1.0.0
```

## Post-Deployment Configuration

### 1. Create Admin User

```bash
# Create first admin user via Cognito
aws cognito-idp admin-create-user \
  --user-pool-id $USER_POOL_ID \
  --username admin@yourdomain.com \
  --user-attributes Name=email,Value=admin@yourdomain.com \
    Name=email_verified,Value=true \
  --temporary-password "TempPassword123!" \
  --message-action SUPPRESS

# Add user to Admins group
aws cognito-idp admin-add-user-to-group \
  --user-pool-id $USER_POOL_ID \
  --username admin@yourdomain.com \
  --group-name Admins
```

### 2. Configure SES

```bash
# Verify sending domain
aws ses verify-domain-identity --domain yourdomain.com

# Add DNS records (check console for values)
# Then verify
aws ses get-identity-verification-attributes --identities yourdomain.com
```

### 3. Configure Amazon Connect (Optional)

1. Go to AWS Console > Amazon Connect
2. Create instance: `marketing-platform-prod`
3. Configure phone numbers
4. Import IVR flow from `infra/connect/flows/`
5. Update environment variable with instance ID

### 4. Seed Sample Data (Development Only)

```bash
# Run seed script
npm run seed
```

## CI/CD Setup

### GitHub Actions Configuration

#### 1. Configure AWS OIDC

```bash
# Create OIDC provider
aws iam create-open-id-connect-provider \
  --url https://token.actions.githubusercontent.com \
  --client-id-list sts.amazonaws.com \
  --thumbprint-list 6938fd4d98bab03faadb97b34396831e3780aea1
```

#### 2. Create IAM Roles

Development role:
```bash
aws iam create-role \
  --role-name GitHubActionsDevelopment \
  --assume-role-policy-document file://github-trust-policy.json

aws iam attach-role-policy \
  --role-name GitHubActionsDevelopment \
  --policy-arn arn:aws:iam::aws:policy/AdministratorAccess
```

Production role (more restrictive):
```bash
aws iam create-role \
  --role-name GitHubActionsProduction \
  --assume-role-policy-document file://github-trust-policy.json

# Attach specific policies for production
```

#### 3. Configure GitHub Secrets

In GitHub repository settings > Secrets and variables > Actions:

**Development:**
- `AWS_ROLE_ARN_DEV`: ARN of development role
- `COGNITO_USER_POOL_ID_DEV`
- `COGNITO_CLIENT_ID_DEV`

**Production:**
- `AWS_ROLE_ARN_PROD`: ARN of production role
- `COGNITO_USER_POOL_ID_PROD`
- `COGNITO_CLIENT_ID_PROD`

### Manual Deployment Commands

```bash
# Deploy specific environment
cd infra
cdk deploy --all --context environment=development

# Deploy with approval
cdk deploy --all --require-approval never

# Deploy specific stack
cdk deploy MarketingPlatform-Api-production
```

## Monitoring Deployment

### Check Stack Status

```bash
# List all stacks
aws cloudformation list-stacks \
  --stack-status-filter CREATE_COMPLETE UPDATE_COMPLETE

# Describe specific stack
aws cloudformation describe-stacks \
  --stack-name MarketingPlatform-Api-development
```

### View Logs

```bash
# Lambda logs
aws logs tail /aws/lambda/MarketingPlatform-CreateCustomer-dev --follow

# API Gateway logs
aws logs tail /aws/apigateway/MarketingPlatform-dev --follow
```

### Test Deployment

```bash
# Health check
curl $API_URL/health

# Test authentication
curl -X POST $API_URL/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@yourdomain.com","password":"your-password"}'
```

## Rollback Procedures

### Rollback CDK Stack

```bash
# Rollback to previous version
cdk deploy --rollback

# Or delete and redeploy
cdk destroy MarketingPlatform-Api-development
cdk deploy MarketingPlatform-Api-development
```

### Rollback via CloudFormation

```bash
# In AWS Console
# CloudFormation > Stacks > Select Stack > Actions > Roll back
```

## Troubleshooting

### Common Issues

**CDK Bootstrap Error:**
```bash
# Solution: Bootstrap with specific account/region
cdk bootstrap aws://ACCOUNT-ID/REGION
```

**Lambda Timeout:**
```bash
# Increase timeout in CDK stack
timeout: cdk.Duration.seconds(30)
```

**DynamoDB Throttling:**
```bash
# Switch to on-demand billing mode or increase provisioned capacity
```

**SES Sandbox Limits:**
```bash
# Request production access in SES console
```

## Cleanup

### Delete Development Environment

```bash
# Delete all stacks
cd infra
cdk destroy --all

# Confirm deletion
```

**Note:** Some resources like S3 buckets with objects will need manual deletion.

### Delete Specific Resources

```bash
# Empty S3 bucket first
aws s3 rm s3://bucket-name --recursive

# Then delete stack
cdk destroy MarketingPlatform-Storage-development
```

## Next Steps

After successful deployment:

1. [ ] Configure custom domain
2. [ ] Set up SSL certificate
3. [ ] Configure email templates
4. [ ] Import initial customer data
5. [ ] Test all integrations
6. [ ] Configure monitoring alerts
7. [ ] Schedule regular backups
8. [ ] Document environment-specific configurations

## Support

For deployment issues:
- Check CloudFormation events in AWS Console
- Review CloudWatch logs
- Consult `docs/operations/troubleshooting.md`
- Open GitHub issue with deployment logs
