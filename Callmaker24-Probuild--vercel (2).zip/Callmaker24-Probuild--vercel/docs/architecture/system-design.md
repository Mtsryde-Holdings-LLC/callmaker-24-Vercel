# System Design - Marketing Platform Pro

## Overview

Marketing Platform Pro is a serverless, cloud-native application built on AWS that provides comprehensive marketing automation, customer management, AI-powered support, and voice communication capabilities.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         Client Layer                             │
├─────────────────────────────────────────────────────────────────┤
│  Next.js Web App  │  Mobile Apps (Future)  │  Chat Widget       │
└──────────────────┬──────────────────────────┬───────────────────┘
                   │                          │
                   ▼                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                         CDN Layer                                │
├─────────────────────────────────────────────────────────────────┤
│                     CloudFront (S3 Origin)                       │
└──────────────────┬──────────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Authentication Layer                        │
├─────────────────────────────────────────────────────────────────┤
│  AWS Cognito  │  MFA  │  Social Login  │  JWT Tokens            │
└──────────────────┬──────────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                         API Layer                                │
├─────────────────────────────────────────────────────────────────┤
│  API Gateway (REST)  │  WebSocket API  │  Rate Limiting         │
└──────────────────┬───────────────┬──────────────────────────────┘
                   │               │
                   ▼               ▼
┌──────────────────────────────────────────────────────────────────┐
│                      Application Layer                           │
├──────────────────────────────────────────────────────────────────┤
│  AWS Lambda Functions (Node.js/TypeScript)                       │
│  ┌─────────────┬─────────────┬─────────────┬─────────────┐     │
│  │    Auth     │  Customers  │  Campaigns  │   Messages  │     │
│  ├─────────────┼─────────────┼─────────────┼─────────────┤     │
│  │     AI      │    Chat     │    IVR      │   Analytics │     │
│  └─────────────┴─────────────┴─────────────┴─────────────┘     │
└──────┬───────────────┬───────────────┬───────────────┬──────────┘
       │               │               │               │
       ▼               ▼               ▼               ▼
┌──────────────────────────────────────────────────────────────────┐
│                        Data Layer                                │
├──────────────────────────────────────────────────────────────────┤
│  DynamoDB Tables          │  RDS PostgreSQL (Analytics)          │
│  ┌─────────────────┐     │  ┌─────────────────┐                │
│  │  Customers      │     │  │  Reports        │                │
│  │  Campaigns      │     │  │  Aggregations   │                │
│  │  Messages       │     │  │  Time Series    │                │
│  │  Conversations  │     │  └─────────────────┘                │
│  └─────────────────┘     │                                       │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│                      Integration Layer                           │
├──────────────────────────────────────────────────────────────────┤
│  SES/Pinpoint  │  SNS  │  Amazon Connect  │  OpenAI  │  Stripe  │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│                      Monitoring Layer                            │
├──────────────────────────────────────────────────────────────────┤
│  CloudWatch Logs  │  X-Ray Tracing  │  Alarms  │  Dashboards    │
└──────────────────────────────────────────────────────────────────┘
```

## Component Details

### Frontend (Next.js)

**Technology Stack:**
- Next.js 14 with App Router
- React 18 with Server Components
- TypeScript for type safety
- Tailwind CSS for styling
- React Query for data fetching
- Zustand for state management

**Features:**
- Server-side rendering for SEO
- Client-side routing for SPA experience
- Optimistic UI updates
- Real-time WebSocket connections
- Responsive design (mobile-first)
- Dark mode support

### Backend (AWS Lambda)

**Technology Stack:**
- Node.js 18 runtime
- TypeScript compilation
- AWS SDK v3
- Express-like routing

**Function Categories:**

1. **Authentication Functions**
   - Login, signup, MFA verification
   - Password reset, email verification
   - Token refresh and validation

2. **Customer Management Functions**
   - CRUD operations
   - Bulk import/export
   - Segmentation queries

3. **Campaign Functions**
   - Campaign creation and editing
   - Scheduling and sending
   - Analytics tracking

4. **Messaging Functions**
   - Email sending via SES
   - SMS sending via SNS
   - Delivery tracking

5. **AI Functions**
   - Content generation (OpenAI)
   - Chatbot conversations
   - Sentiment analysis

6. **IVR Functions**
   - Call handling via Connect
   - Call routing logic
   - Recording management

### Database Architecture

**DynamoDB Tables:**

1. **Customers Table**
   - Partition Key: `id`
   - Sort Key: `tenantId`
   - GSI: Email index for lookups
   - Attributes: email, phone, name, tags, customFields

2. **Campaigns Table**
   - Partition Key: `id`
   - Sort Key: `tenantId`
   - GSI: Status index for filtering
   - Streams enabled for analytics

3. **Messages Table**
   - Partition Key: `id`
   - Sort Key: `campaignId`
   - GSI: Customer index
   - TTL enabled for cleanup

4. **Conversations Table**
   - Partition Key: `id`
   - Sort Key: `tenantId`
   - GSI: Status index
   - Streams for real-time updates

**RDS PostgreSQL** (Production only):
- Used for complex analytics queries
- Aggregated campaign metrics
- Time-series data
- Joins across multiple entities

### Messaging Architecture

**Email (SES + Pinpoint):**
- SES for transactional emails
- Pinpoint for campaign management
- Configuration sets for tracking
- Bounce and complaint handling

**SMS (SNS + Pinpoint):**
- SNS for two-way messaging
- Pinpoint for campaign orchestration
- Opt-in/opt-out management
- Delivery status tracking

**Voice (Amazon Connect):**
- IVR flow designer
- Lambda hooks for custom logic
- Call recording to S3
- Contact trace records

### AI Integration

**OpenAI API:**
- GPT-4 for content generation
- Few-shot prompting
- Token usage tracking
- Cost estimation

**Alternative: AWS Bedrock:**
- Claude 2/3 models
- Native AWS integration
- Lower latency
- Better for sensitive data

### Security Architecture

**Authentication & Authorization:**
- AWS Cognito User Pools
- JWT tokens with refresh
- MFA support (TOTP, SMS)
- Role-based access control (RBAC)

**Data Protection:**
- Encryption at rest (AWS-managed keys)
- Encryption in transit (TLS 1.2+)
- Secrets Manager for credentials
- VPC for RDS (production)

**API Security:**
- Cognito authorizer on API Gateway
- Rate limiting (1000 req/sec)
- CORS configuration
- Input validation (Zod schemas)

### Scalability

**Horizontal Scaling:**
- Lambda auto-scales to demand
- DynamoDB on-demand capacity
- API Gateway handles bursts

**Performance Optimizations:**
- CloudFront edge caching
- DynamoDB DAX (optional)
- RDS read replicas
- Lambda provisioned concurrency (optional)

### Monitoring & Observability

**Metrics:**
- API Gateway metrics (requests, latency, errors)
- Lambda metrics (invocations, duration, errors)
- DynamoDB metrics (read/write capacity)
- Custom business metrics

**Logging:**
- CloudWatch Logs for all services
- Structured JSON logging
- Log retention policies
- Log insights queries

**Tracing:**
- AWS X-Ray integration
- Distributed tracing
- Service map visualization
- Performance analysis

**Alerting:**
- SNS topics for alarms
- Email/SMS notifications
- Slack integration (optional)
- PagerDuty integration (optional)

## Data Flow Examples

### Campaign Sending Flow

```
1. User creates campaign in UI
   └─> POST /campaigns → Lambda → DynamoDB

2. User schedules campaign
   └─> POST /campaigns/:id/schedule → Lambda → EventBridge

3. EventBridge triggers at scheduled time
   └─> Triggers Step Functions workflow

4. Step Functions orchestrates sending:
   a. Query customers in segment → DynamoDB
   b. For each batch (1000 customers):
      - Lambda sends via SES/SNS
      - Stores message records → DynamoDB
      - Tracks delivery status

5. Delivery events (opens, clicks, bounces)
   └─> SES/Pinpoint → Lambda → DynamoDB → Analytics DB

6. User views analytics
   └─> GET /campaigns/:id/analytics → Lambda → RDS → Charts
```

### Chat Support Flow

```
1. Customer opens chat widget
   └─> WebSocket connection to API Gateway

2. Customer sends message
   └─> WebSocket → Lambda → AI bot

3. Bot processes message:
   a. Query knowledge base
   b. Generate response via OpenAI
   c. Store conversation → DynamoDB

4. If bot can't help, escalate to agent
   └─> Update conversation status
   └─> Notify agent via WebSocket

5. Agent joins conversation
   └─> Real-time message exchange via WebSocket
   └─> All messages stored in DynamoDB

6. Conversation resolved
   └─> Update status → DynamoDB
   └─> Customer satisfaction survey
```

## Deployment Architecture

**Environments:**
- Development: Single-region, minimal redundancy
- Staging: Production-like, separate accounts
- Production: Multi-AZ, backups, monitoring

**CI/CD Pipeline:**
```
1. Code push to GitHub
2. GitHub Actions triggered
3. Lint, test, build
4. Deploy CDK stacks:
   - Auth stack
   - Database stack
   - Storage stack
   - Messaging stack
   - API stack
   - Monitoring stack
5. Run smoke tests
6. Update CloudFront distribution
```

## Cost Optimization

**Strategies:**
- Use on-demand pricing for variable loads
- Reserved instances for RDS (production)
- S3 lifecycle policies
- CloudFront caching
- Lambda memory optimization
- DynamoDB on-demand vs provisioned

**Estimated Monthly Costs:**
- Development: $30-50
- Production (small): $200-400
- Production (medium): $1000-2000
- Production (large): $5000+

## Disaster Recovery

**Backup Strategy:**
- DynamoDB point-in-time recovery
- RDS automated backups (7 days)
- S3 versioning enabled
- Cross-region replication (optional)

**Recovery Objectives:**
- RTO (Recovery Time Objective): 1 hour
- RPO (Recovery Point Objective): 5 minutes

## Future Enhancements

1. **Multi-region deployment** for HA
2. **GraphQL API** alongside REST
3. **Machine learning** for predictive analytics
4. **WhatsApp integration**
5. **Mobile apps** (React Native)
6. **Advanced A/B testing**
7. **Customer journey automation**
8. **Predictive lead scoring**
