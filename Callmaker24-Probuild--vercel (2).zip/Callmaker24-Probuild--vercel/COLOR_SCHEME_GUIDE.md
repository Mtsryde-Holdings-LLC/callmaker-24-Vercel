# Callmaker24 Marketing Platform - Complete Color Scheme Guide

**Application**: Callmaker24 Marketing Platform
**Framework**: Next.js 14 with Tailwind CSS
**Design System**: Custom color palette with dark mode support
**Last Updated**: 2025-11-02

---

## 🎨 Overview

The Callmaker24 Marketing Platform uses a **professional, modern color system** designed for:
- Marketing automation interfaces
- Data visualization and analytics
- Multi-platform social media management
- Customer relationship management
- Campaign management

**Design Philosophy**: Clean, professional, accessible with strong visual hierarchy

---

## 🌈 Primary Brand Colors

### **Primary Color - Indigo** (Main Brand Identity)
Professional, trustworthy, tech-forward

| Shade | Hex Code | Usage |
|-------|----------|-------|
| primary-50 | `#EEF2FF` | Background tints, hover states |
| primary-100 | `#E0E7FF` | Light backgrounds, badges |
| primary-200 | `#C7D2FE` | Borders, dividers |
| primary-300 | `#A5B4FC` | Disabled states |
| primary-400 | `#818CF8` | Secondary text |
| **primary-500** | **`#6366F1`** | **Base primary color** |
| **primary-600** | **`#4F46E5`** | **Main buttons, primary actions** ⭐ |
| primary-700 | `#4338CA` | Hover states, pressed buttons |
| primary-800 | `#3730A3` | Dark mode elements |
| primary-900 | `#312E81` | Text on light backgrounds |
| primary-950 | `#1E1B4B` | Deepest shade |

**Used In**:
- Primary action buttons
- Active navigation items (`bg-primary-50`, `text-primary-700`)
- Focus rings and highlights
- Gradient text effects (from primary to secondary)
- Logo branding

---

### **Secondary Color - Sky Blue** (Complementary Actions)
Modern, energetic, friendly

| Shade | Hex Code | Usage |
|-------|----------|-------|
| secondary-50 | `#F0F9FF` | Light backgrounds |
| secondary-100 | `#E0F2FE` | Subtle highlights |
| secondary-200 | `#BAE6FD` | Borders |
| secondary-300 | `#7DD3FC` | Icons, decorative |
| secondary-400 | `#38BDF8` | Interactive elements |
| **secondary-500** | **`#0EA5E9`** | **Base secondary** |
| **secondary-600** | **`#0284C7`** | **Secondary buttons** ⭐ |
| secondary-700 | `#0369A1` | Hover states |
| secondary-800 | `#075985` | Dark mode |
| secondary-900 | `#0C4A6E` | Deep accents |
| secondary-950 | `#082F49` | Darkest |

**Used In**:
- Secondary action buttons
- Links and clickable elements
- Gradient text (combined with primary)
- Alternative highlighting

---

### **Accent Color - Cyan** (Special Highlights)
Fresh, modern, attention-grabbing

| Shade | Hex Code | Usage |
|-------|----------|-------|
| accent-50 | `#ECFEFF` | Backgrounds |
| accent-100 | `#CFFAFE` | Light accents |
| accent-200 | `#A5F3FC` | Subtle highlights |
| accent-300 | `#67E8F9` | Decorative |
| accent-400 | `#22D3EE` | Interactive |
| **accent-500** | **`#06B6D4`** | **Main accent** ⭐ |
| accent-600 | `#0891B2` | Hover states |
| accent-700 | `#0E7490` | Dark accents |
| accent-800 | `#155E75` | Deep tones |
| accent-900 | `#164E63` | Darkest |
| accent-950 | `#083344` | Almost black |

**Used In**:
- Special badges
- Notification indicators
- Highlights and callouts
- Decorative elements

---

## 🚦 Status & Semantic Colors

### **Success - Green** (Positive States)
Growth, completion, success metrics

| Shade | Hex Code | Usage |
|-------|----------|-------|
| success-50 | `#F0FDF4` | Success backgrounds |
| success-100 | `#DCFCE7` | Light success states |
| **success-500** | **`#22C55E`** | **Main success color** ⭐ |
| success-600 | `#16A34A` | Success buttons |
| success-700 | `#15803D` | Dark success |

**Badge**: `bg-success-100 text-success-800`

**Used For**:
- ✅ Sent campaigns
- ✅ Active customers
- ✅ Resolved conversations
- ✅ Completed tasks
- ✅ Positive metrics (up arrows)
- ✅ Success toasts

---

### **Warning - Amber** (Cautionary States)
Attention needed, pending actions

| Shade | Hex Code | Usage |
|-------|----------|-------|
| warning-50 | `#FFFBEB` | Warning backgrounds |
| warning-100 | `#FEF3C7` | Light warnings |
| **warning-500** | **`#F59E0B`** | **Main warning** ⭐ |
| warning-600 | `#D97706` | Warning buttons |
| warning-700 | `#B45309` | Dark warnings |

**Badge**: `bg-warning-100 text-warning-800`

**Used For**:
- ⚠️ Scheduled campaigns
- ⚠️ Assigned conversations
- ⚠️ Pending actions
- ⚠️ Sending status
- ⚠️ Warning alerts

---

### **Error/Danger - Red** (Critical States)
Errors, destructive actions, failures

| Shade | Hex Code | Usage |
|-------|----------|-------|
| error-50 | `#FEF2F2` | Error backgrounds |
| error-100 | `#FEE2E2` | Light error states |
| **error-500** | **`#EF4444`** | **Main error** ⭐ |
| error-600 | `#DC2626` | Error/Danger buttons |
| error-700 | `#B91C1C` | Dark errors |

**Badge**: `bg-error-100 text-error-800`

**Used For**:
- ❌ Failed campaigns
- ❌ Cancelled actions
- ❌ Unsubscribed customers
- ❌ Bounced emails
- ❌ Error messages
- ❌ Delete buttons
- ❌ Past due subscriptions

---

### **Gray/Neutral** (Base Interface)
Text, backgrounds, borders, neutral states

| Shade | Purpose | Light Mode | Dark Mode |
|-------|---------|------------|-----------|
| gray-50 | Lightest bg | Used | - |
| gray-100 | Light bg, hover | Used | - |
| gray-200 | Borders | Used | - |
| gray-300 | Dividers, input borders | Used | - |
| gray-400 | Placeholder text | Used | Icons |
| gray-500 | Secondary text | Used | - |
| gray-600 | Body text | Used | - |
| gray-700 | Primary text | Used | - |
| gray-800 | Darkest text | Used | Hover bg |
| gray-900 | Headings | Used | Cards/bg |

**Badge**: `bg-gray-100 text-gray-800`

**Used For**:
- Draft status
- Inactive customers
- Closed conversations
- Expired subscriptions
- Paused campaigns
- Disabled states
- Text hierarchy
- Borders and dividers

---

## 📱 Social Media Platform Colors

Authentic brand colors for social integrations

### **Twitter/X**
- **Color**: `#1DA1F2` (Twitter Blue)
- **Used**: Calendar events, analytics charts, badges
- **Badge**: `bg-blue-500` (Tailwind approximation)

### **LinkedIn**
- **Color**: `#0A66C2` (LinkedIn Blue)
- **Used**: Calendar events, analytics charts, badges
- **Badge**: `bg-blue-600` (Tailwind approximation)

### **Facebook**
- **Color**: `#1877F2` (Facebook Blue)
- **Used**: Calendar events, analytics charts, badges
- **Badge**: `bg-blue-700` (Tailwind approximation)

### **Instagram**
- **Color**: `#E4405F` (Instagram Pink)
- **Used**: Calendar events, analytics charts, badges
- **Badge**: `bg-pink-500` (Tailwind approximation)

---

## 🎯 Component Color Mapping

### **Buttons**

| Variant | Background | Hover | Text | Usage |
|---------|-----------|-------|------|-------|
| **Primary** | `primary-600` | `primary-700` | White | Main actions |
| **Secondary** | `secondary-600` | `secondary-700` | White | Secondary actions |
| **Outline** | Transparent | `gray-50` | Inherit | Tertiary actions |
| **Ghost** | Transparent | `gray-100` | Inherit | Subtle actions |
| **Danger** | `error-600` | `error-700` | White | Delete, cancel |
| **Success** | `success-600` | `success-700` | White | Confirm, save |

---

### **Badges**

| Status | Background | Text | Dark Mode |
|--------|-----------|------|-----------|
| **Draft** | `gray-100` | `gray-800` | `gray-800` / `gray-200` |
| **Scheduled** | `blue-100` | `blue-800` | Inverted |
| **Sending** | `yellow-100` | `yellow-800` | Inverted |
| **Sent** | `green-100` | `green-800` | `success` variant |
| **Paused** | `orange-100` | `orange-800` | Inverted |
| **Cancelled** | `red-100` | `red-800` | `error` variant |
| **Failed** | `red-100` | `red-800` | `error` variant |
| **Active** | `green-100` | `green-800` | `success` variant |
| **Inactive** | `gray-100` | `gray-800` | `gray` variant |

---

### **Status Function Mapping**

```typescript
getStatusColor() returns:
- 'gray' → Draft, Inactive, Closed, Expired
- 'blue' → Scheduled, Open
- 'yellow' → Sending, Assigned
- 'green' → Sent, Active, Resolved
- 'orange' → Paused
- 'red' → Cancelled, Failed, Unsubscribed, Bounced, Past Due
```

---

### **Dashboard Metrics Cards**

| Card Type | Icon Background | Icon Color | Usage |
|-----------|----------------|-----------|-------|
| **Users/Customers** | `blue-100` | `blue-600` | Total customers |
| **Engagement** | `pink-100` | `pink-600` | Engagement rate |
| **Posts/Messages** | `purple-100` | `purple-600` | Message count |
| **Revenue/Reach** | `green-100` | `green-600` | Financial/reach metrics |

---

### **Analytics Charts**

| Chart Element | Color(s) |
|--------------|----------|
| **Line charts** | Platform brand colors (Twitter blue, etc.) |
| **Bar charts (Likes)** | `#10B981` (Green) |
| **Bar charts (Shares)** | `#3B82F6` (Blue) |
| **Bar charts (Comments)** | `#F59E0B` (Amber) |
| **Pie charts** | Platform brand colors |
| **Grid lines** | `gray-200` |
| **Axes** | `gray-400` |

---

## 🌓 Light & Dark Mode

### **Light Mode Palette**
```css
Background: #FFFFFF (white)
Card Background: #FFFFFF (white)
Text Primary: #111827 (gray-900)
Text Secondary: #6B7280 (gray-500)
Border: #E5E7EB (gray-200)
Input Border: #D1D5DB (gray-300)
Hover: #F3F4F6 (gray-100)
```

### **Dark Mode Palette**
```css
Background: #09090B (near black with blue tint)
Card Background: #18181B (dark gray)
Text Primary: #FAFAFA (off-white)
Text Secondary: #A1A1AA (light gray)
Border: #27272A (dark gray)
Input Border: #3F3F46 (medium gray)
Hover: #27272A (dark gray)
```

**Dark Mode Toggle**: `class="dark"` on root element

---

## 🎨 Special Effects & Gradients

### **Gradient Text** (Logo, Headings)
```css
.gradient-text {
  background: linear-gradient(to right, #4F46E5, #0284C7);
  background-clip: text;
  color: transparent;
}
```
**Colors**: `primary-600` → `secondary-600`

### **Glass Morphism**
```css
.glass {
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(229, 231, 235, 0.5);
}
```

### **Focus Rings**
- Primary: `ring-primary-500`
- Secondary: `ring-secondary-500`
- Success: `ring-success-500`
- Error: `ring-error-500`

### **Shadows**
- Small: `shadow-sm` (subtle)
- Medium: `shadow-md` (cards)
- Large: `shadow-lg` (hover states)
- Inner: Custom `inner-lg`

---

## 📐 Color Usage Guidelines

### **Do's** ✅
- Use `primary-600` for main call-to-action buttons
- Use semantic colors (success/warning/error) for status indicators
- Maintain sufficient contrast (WCAG AA minimum)
- Use gray scale for text hierarchy
- Apply hover states consistently
- Use platform brand colors for social media elements

### **Don'ts** ❌
- Don't use too many colors in one view
- Don't mix semantic colors incorrectly
- Don't ignore dark mode considerations
- Don't use red/green as the only differentiator (accessibility)
- Don't override primary brand colors arbitrarily

---

## 🎯 Color Application By Page

### **Dashboard**
- **Primary**: Gray-900 headings, Gray-600 body
- **Cards**: White with subtle shadows
- **Metrics**: Icon colors (blue, pink, purple, green)
- **Charts**: Multi-color (platform specific)

### **Campaigns**
- **Primary Action**: Primary-600 ("New Campaign")
- **Status Badges**: Semantic colors based on state
- **Icons**: Gray-400 for type indicators
- **Table**: Gray-50 hover rows

### **Analytics**
- **Charts**: Platform brand colors + semantic colors
- **Export Button**: Outline variant
- **Time Range**: Primary-600 active, outline inactive

### **Content Calendar**
- **Platform Colors**: Twitter blue, LinkedIn blue, etc.
- **Selected Date**: Primary-50 background
- **Today**: Blue-50 background
- **Drag Items**: Platform-specific badge colors

### **Social Analytics**
- **Metric Cards**: Colored icon backgrounds
- **Charts**: Platform brand colors
- **Time Selector**: Primary-600 active state
- **Trend Indicators**: Green (up) / Red (down)

### **Settings**
- **Tabs**: Primary-700 active, Gray-500 inactive
- **Save Button**: Success-600
- **Delete Button**: Error-600
- **Input Focus**: Primary-500 ring

---

## 🔧 Implementation

### **Tailwind Configuration**
All colors defined in `tailwind.config.js` under `theme.extend.colors`

### **CSS Variables**
Global CSS variables in `globals.css` for theming

### **Component Library**
Consistent variants in:
- `components/ui/button.tsx`
- `components/ui/badge.tsx`
- `components/ui/card.tsx`

### **Utility Functions**
- `getStatusColor()` - Maps status strings to color names
- `cn()` - Merges Tailwind classes

---

## 📊 Accessibility

### **Contrast Ratios** (WCAG AA Compliant)
- Text on primary-600: ✅ Passes (White text)
- Text on success-500: ✅ Passes (White text)
- Text on error-500: ✅ Passes (White text)
- Text on gray-100: ✅ Passes (Gray-800 text)

### **Color Blind Considerations**
- Don't rely on color alone for status
- Use icons + text labels + colors together
- Red/Green always paired with shapes/icons

---

## 🎨 Summary

**Callmaker24 Color Identity**:
- **Primary**: Indigo (Professional, trustworthy)
- **Secondary**: Sky Blue (Modern, friendly)
- **Accent**: Cyan (Fresh, attention-grabbing)

**Design Style**:
- Clean, modern SaaS interface
- Professional marketing tool aesthetic
- Data-driven with clear visual hierarchy
- Accessible and WCAG compliant
- Full dark mode support
- Authentic social media platform integration

**Total Colors in Palette**: 60+ shades across 8 color families

---

**Created**: 2025-11-02
**Design System**: Custom Tailwind CSS Configuration
**Framework**: Next.js 14 + Tailwind CSS 3.4
**Platform**: Callmaker24 Marketing Platform
