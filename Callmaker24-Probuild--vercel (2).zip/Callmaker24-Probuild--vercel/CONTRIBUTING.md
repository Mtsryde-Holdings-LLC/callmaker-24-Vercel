# Contributing to Marketing Platform Pro

Thank you for your interest in contributing! This document provides guidelines and instructions for contributing to the project.

## Code of Conduct

Be respectful, inclusive, and professional in all interactions.

## Getting Started

1. **Fork the repository**
2. **Clone your fork**
   ```bash
   git clone https://github.com/your-username/marketing-platform.git
   cd marketing-platform
   ```

3. **Install dependencies**
   ```bash
   npm install
   ```

4. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

## Development Workflow

### Project Structure

- `apps/frontend/` - Next.js frontend application
- `apps/backend/` - Lambda functions
- `infra/` - AWS CDK infrastructure
- `docs/` - Documentation
- `tests/` - E2E tests

### Running Locally

```bash
# Start frontend development server
npm run dev

# Run tests
npm test

# Run linter
npm run lint

# Format code
npm run format
```

### Code Standards

#### TypeScript

- Use TypeScript for all code
- Enable `strict` mode
- Avoid `any` type when possible
- Document complex types

#### Naming Conventions

- **Files**: kebab-case (`user-service.ts`)
- **Components**: PascalCase (`UserProfile.tsx`)
- **Functions**: camelCase (`getUserById`)
- **Constants**: UPPER_SNAKE_CASE (`MAX_RETRY_COUNT`)

#### Code Style

```typescript
// Good
export async function createCustomer(data: CreateCustomerRequest): Promise<Customer> {
  const customer = {
    id: generateId(),
    ...data,
    createdAt: new Date().toISOString(),
  };

  await customersTable.put(customer);
  return customer;
}

// Bad
export async function create(data: any) {
  const customer = { id: Math.random().toString(), ...data };
  await customersTable.put(customer);
  return customer;
}
```

### Commit Messages

Follow the [Conventional Commits](https://www.conventionalcommits.org/) specification:

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, etc.)
- `refactor`: Code refactoring
- `test`: Adding or updating tests
- `chore`: Maintenance tasks

**Examples:**
```
feat(campaigns): add A/B testing support
fix(auth): resolve token refresh issue
docs(api): update endpoint documentation
```

### Testing

#### Unit Tests

```bash
# Run unit tests
npm run test:unit

# Run with coverage
npm run test:coverage
```

Write tests for:
- Business logic functions
- API utilities
- Data transformations
- Validation functions

Example:
```typescript
import { describe, it, expect } from '@jest/globals';
import { formatCurrency } from './utils';

describe('formatCurrency', () => {
  it('should format USD correctly', () => {
    expect(formatCurrency(1234.56, 'USD')).toBe('$1,234.56');
  });

  it('should handle zero', () => {
    expect(formatCurrency(0, 'USD')).toBe('$0.00');
  });
});
```

#### Integration Tests

Test Lambda functions with mock AWS services:

```typescript
import { handler } from './create-customer';
import { mockClient } from 'aws-sdk-client-mock';
import { DynamoDBDocumentClient, PutCommand } from '@aws-sdk/lib-dynamodb';

const ddbMock = mockClient(DynamoDBDocumentClient);

describe('createCustomer', () => {
  beforeEach(() => {
    ddbMock.reset();
  });

  it('should create customer', async () => {
    ddbMock.on(PutCommand).resolves({});

    const result = await handler({
      body: JSON.stringify({ email: 'test@example.com' }),
      headers: { 'X-Tenant-ID': 'test-tenant' },
    } as any);

    expect(result.statusCode).toBe(201);
  });
});
```

#### E2E Tests

```bash
# Run E2E tests
npm run test:e2e
```

### Pull Request Process

1. **Ensure all tests pass**
   ```bash
   npm test
   npm run lint
   npm run typecheck
   ```

2. **Update documentation** if needed

3. **Create pull request** with:
   - Clear title following commit conventions
   - Description of changes
   - Screenshots for UI changes
   - Link to related issue

4. **Request review** from maintainers

5. **Address feedback** and update PR

6. **Squash commits** before merge (if requested)

### Pull Request Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Unit tests added/updated
- [ ] Integration tests added/updated
- [ ] E2E tests added/updated
- [ ] Manual testing completed

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
- [ ] No new warnings
- [ ] Tests pass locally
- [ ] Dependent changes merged

## Screenshots
(if applicable)
```

## Project-Specific Guidelines

### Frontend (Next.js)

- Use Server Components by default
- Client Components only when needed (interactivity, hooks)
- Colocate styles with components
- Use React Query for data fetching
- Implement loading and error states

### Backend (Lambda)

- Keep functions small and focused
- Use environment variables for configuration
- Implement proper error handling
- Log structured JSON
- Set appropriate timeouts and memory

### Infrastructure (CDK)

- Use constructs for reusability
- Tag all resources
- Implement proper IAM policies (least privilege)
- Enable encryption and backups
- Document stack dependencies

### Documentation

- Update docs with code changes
- Use clear, concise language
- Include code examples
- Add diagrams where helpful
- Keep README up to date

## Release Process

### Versioning

Follow [Semantic Versioning](https://semver.org/):
- MAJOR: Breaking changes
- MINOR: New features (backward compatible)
- PATCH: Bug fixes

### Creating a Release

1. Update version in `package.json`
2. Update CHANGELOG.md
3. Create git tag
4. Push tag to trigger deployment

```bash
# Example
npm version minor
git push origin main --tags
```

## Getting Help

- **Documentation**: Check `docs/` folder
- **Issues**: Search existing issues
- **Discussions**: Use GitHub Discussions
- **Chat**: Join our community (if available)

## Recognition

Contributors will be recognized in:
- CONTRIBUTORS.md file
- Release notes
- GitHub contributors page

Thank you for contributing! 🎉
