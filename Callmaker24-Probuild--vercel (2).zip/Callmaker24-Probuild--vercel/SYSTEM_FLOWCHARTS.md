# Callmaker24 - Complete System Flow Charts

## Color Code Legend

```
🔵 BLUE     - Authentication & Security
🟢 GREEN    - Success Flows & Confirmations
🔴 RED      - Error Flows & Validations
🟣 PURPLE   - Super Admin Functions
🟠 ORANGE   - Admin Functions
🟡 YELLOW   - API Gateway / Endpoints
🔷 TEAL     - Database Operations
🟪 PINK     - External Integrations (AWS Services)
⚪ GRAY     - User Actions / Input
🟤 BROWN    - Background Jobs / Scheduled Tasks
```

---

## Table of Contents

1. [System Architecture Overview](#system-architecture-overview)
2. [Authentication Flows](#authentication-flows)
3. [User Management Flows](#user-management-flows)
4. [SMS Marketing Flows](#sms-marketing-flows)
5. [IVR/Voice System Flows](#ivrvoice-system-flows)
6. [Email Campaign Flows](#email-campaign-flows)
7. [Social Media Content Flows](#social-media-content-flows)
8. [Customer Management Flows](#customer-management-flows)
9. [Analytics & Reporting Flows](#analytics--reporting-flows)
10. [Subscription & Billing Flows](#subscription--billing-flows)

---

## System Architecture Overview

```mermaid
graph TB
    subgraph "Frontend Layer"
        A[⚪ Next.js 14 App]
        B[⚪ React Components]
        C[⚪ User Interface]
    end

    subgraph "API Gateway Layer"
        D[🟡 AWS API Gateway]
        E[🔵 Authentication Middleware]
        F[🔵 Permission Validator]
    end

    subgraph "Lambda Functions Layer"
        G1[🟠 Auth Functions]
        G2[🟠 User Management]
        G3[🟢 SMS Marketing]
        G4[🟢 IVR/Voice]
        G5[🟢 Email Campaigns]
        G6[🟢 Social Media]
        G7[🟢 Customer Management]
        G8[🟢 Analytics]
    end

    subgraph "Database Layer"
        H[🔷 DynamoDB]
        I[🔷 PostgreSQL/RDS]
    end

    subgraph "External Services"
        J[🟪 AWS SNS - SMS]
        K[🟪 Amazon Connect - IVR]
        L[🟪 AWS SES - Email]
        M[🟪 Social Media APIs]
        N[🟪 OpenAI GPT-4]
        O[🟪 Stripe - Payments]
    end

    subgraph "Background Jobs"
        P[🟤 EventBridge Scheduler]
        Q[🟤 Campaign Processor]
        R[🟤 Analytics Aggregator]
    end

    A --> B --> C
    C --> D
    D --> E
    E --> F
    F --> G1 & G2 & G3 & G4 & G5 & G6 & G7 & G8

    G1 & G2 --> I
    G3 & G4 & G5 & G6 & G7 & G8 --> H
    G3 & G4 & G5 & G6 & G7 & G8 --> I

    G3 --> J
    G4 --> K
    G5 --> L
    G6 --> M
    G6 --> N
    G2 --> O

    P --> Q
    P --> R
    Q --> G3 & G5
    R --> G8

    style D fill:#FFD700
    style E fill:#4169E1
    style F fill:#4169E1
    style G1 fill:#FF8C00
    style G2 fill:#FF8C00
    style G3 fill:#32CD32
    style G4 fill:#32CD32
    style G5 fill:#32CD32
    style G6 fill:#32CD32
    style G7 fill:#32CD32
    style G8 fill:#32CD32
    style H fill:#20B2AA
    style I fill:#20B2AA
    style J fill:#FF69B4
    style K fill:#FF69B4
    style L fill:#FF69B4
    style M fill:#FF69B4
    style N fill:#FF69B4
    style O fill:#FF69B4
    style P fill:#8B4513
    style Q fill:#8B4513
    style R fill:#8B4513
```

---

## Authentication Flows

### 1. User Signup Flow

```mermaid
sequenceDiagram
    participant U as ⚪ User
    participant UI as ⚪ Frontend
    participant AG as 🟡 API Gateway
    participant AM as 🔵 Auth Middleware
    participant SF as 🟠 Signup Function
    participant DB as 🔷 Database

    U->>UI: Enter email, password, name
    UI->>UI: 🔴 Validate input format

    alt Invalid Input
        UI-->>U: 🔴 Show validation errors
    end

    UI->>AG: 🟡 POST /auth/signup
    AG->>SF: Forward request

    SF->>SF: 🔴 Validate email format
    SF->>SF: 🔴 Check password strength

    alt Weak Password
        SF-->>UI: 🔴 Password requirements error
        UI-->>U: 🔴 Display error message
    end

    SF->>DB: 🔷 Check if email exists

    alt Email Exists
        DB-->>SF: 🔴 User found
        SF-->>UI: 🔴 USER_EXISTS error
        UI-->>U: 🔴 Email already registered
    end

    SF->>SF: 🔵 Hash password (bcrypt)
    SF->>SF: 🟢 Generate tenant ID
    SF->>SF: 🟢 Calculate permissions

    SF->>DB: 🔷 Create user record
    DB-->>SF: 🟢 User created

    SF->>SF: 🔵 Generate JWT tokens
    SF-->>UI: 🟢 Success + tokens + user data
    UI->>UI: 🔵 Store tokens
    UI-->>U: 🟢 Redirect to dashboard

    style SF fill:#FF8C00
    style AM fill:#4169E1
    style AG fill:#FFD700
    style DB fill:#20B2AA
```

### 2. User Signin Flow

```mermaid
sequenceDiagram
    participant U as ⚪ User
    participant UI as ⚪ Frontend
    participant AG as 🟡 API Gateway
    participant SI as 🟠 Signin Function
    participant DB as 🔷 Database

    U->>UI: Enter email, password
    UI->>AG: 🟡 POST /auth/signin
    AG->>SI: Forward request

    SI->>DB: 🔷 Query user by email

    alt User Not Found
        DB-->>SI: 🔴 No user
        SI-->>UI: 🔴 INVALID_CREDENTIALS
        UI-->>U: 🔴 Invalid email or password
    end

    DB-->>SI: 🟢 User record

    SI->>SI: 🔴 Check if user is active

    alt User Inactive
        SI-->>UI: 🔴 ACCOUNT_DISABLED
        UI-->>U: 🔴 Account disabled message
    end

    SI->>SI: 🔵 Compare password hash

    alt Invalid Password
        SI-->>UI: 🔴 INVALID_CREDENTIALS
        UI-->>U: 🔴 Invalid email or password
    end

    SI->>SI: 🟢 Load user permissions
    SI->>SI: 🔵 Generate JWT tokens

    SI->>DB: 🔷 Update lastLoginAt

    SI-->>UI: 🟢 Success + tokens + user data
    UI->>UI: 🔵 Store tokens
    UI-->>U: 🟢 Redirect to dashboard

    style SI fill:#FF8C00
    style AG fill:#FFD700
    style DB fill:#20B2AA
```

### 3. Protected Request Flow with Permission Check

```mermaid
sequenceDiagram
    participant U as ⚪ User
    participant UI as ⚪ Frontend
    participant AG as 🟡 API Gateway
    participant AM as 🔵 Auth Middleware
    participant PM as 🔵 Permission Middleware
    participant LF as 🟢 Lambda Function
    participant DB as 🔷 Database

    U->>UI: Perform action
    UI->>AG: 🟡 Request with Bearer token
    AG->>AM: Authenticate request

    AM->>AM: 🔵 Extract token from header

    alt No Token
        AM-->>UI: 🔴 401 UNAUTHORIZED
        UI-->>U: 🔴 Please sign in
    end

    AM->>AM: 🔵 Verify JWT signature

    alt Invalid/Expired Token
        AM-->>UI: 🔴 401 TOKEN_EXPIRED
        UI->>UI: 🔵 Refresh token
    end

    AM->>AM: 🟢 Decode user payload
    AM->>PM: Forward with user context

    PM->>PM: 🔴 Check required permission

    alt Missing Permission
        PM-->>UI: 🔴 403 FORBIDDEN
        UI-->>U: 🔴 Insufficient permissions
    end

    PM->>LF: 🟢 Execute function
    LF->>DB: 🔷 Perform operation
    DB-->>LF: 🟢 Result
    LF-->>UI: 🟢 Success response
    UI-->>U: 🟢 Show result

    style AM fill:#4169E1
    style PM fill:#4169E1
    style AG fill:#FFD700
    style LF fill:#32CD32
    style DB fill:#20B2AA
```

---

## User Management Flows

### 1. Super Admin Assigning Role to User

```mermaid
flowchart TD
    Start([⚪ Super Admin Action]) --> Input[⚪ Select user and role]
    Input --> API[🟡 POST /auth/users/assign-role]
    API --> Auth[🔵 Authenticate request]

    Auth --> CheckRole{🔴 Is Super Admin?}
    CheckRole -->|No| Forbidden[🔴 403 FORBIDDEN]
    CheckRole -->|Yes| GetUser[🔷 Get user from DB]

    GetUser --> UserExists{🔴 User exists?}
    UserExists -->|No| NotFound[🔴 404 USER_NOT_FOUND]
    UserExists -->|Yes| CalcPerms[🟢 Calculate new permissions]

    CalcPerms --> UpdateDB[🔷 Update user role & permissions]
    UpdateDB --> Success[🟢 200 Success]

    Success --> Response[🟢 Return updated user]
    Response --> End([🟢 Role Assigned])

    Forbidden --> End
    NotFound --> End

    style Start fill:#FFFFFF
    style API fill:#FFD700
    style Auth fill:#4169E1
    style CheckRole fill:#DC143C
    style Forbidden fill:#DC143C
    style NotFound fill:#DC143C
    style GetUser fill:#20B2AA
    style CalcPerms fill:#32CD32
    style UpdateDB fill:#20B2AA
    style Success fill:#32CD32
    style Response fill:#32CD32
    style End fill:#32CD32
```

### 2. Admin Managing Users in Tenant

```mermaid
flowchart TD
    Start([⚪ Admin Action]) --> List[🟡 GET /auth/users?tenantId=X]
    List --> Auth[🔵 Authenticate request]

    Auth --> CheckRole{🔴 Is Admin+?}
    CheckRole -->|No| Forbidden[🔴 403 FORBIDDEN]
    CheckRole -->|Yes| CheckTenant{🔴 Check tenant access}

    CheckTenant -->|Different Tenant & Not Super Admin| Forbidden
    CheckTenant -->|Same Tenant or Super Admin| Query[🔷 Query users by tenantId]

    Query --> Format[🟢 Format user list]
    Format --> Success[🟢 200 Success]
    Success --> Display[🟢 Display users]

    Display --> Action{⚪ Admin Action}
    Action -->|Update User| Update[🟡 PUT /auth/users/:id]
    Action -->|View Details| View[🟡 GET /auth/users/:id]
    Action -->|Done| End([🟢 Complete])

    Update --> UpdateFlow[🟠 Update user flow]
    View --> ViewFlow[🟠 View user flow]
    UpdateFlow --> End
    ViewFlow --> End

    Forbidden --> End

    style Start fill:#FFFFFF
    style List fill:#FFD700
    style Auth fill:#4169E1
    style CheckRole fill:#DC143C
    style CheckTenant fill:#DC143C
    style Forbidden fill:#DC143C
    style Query fill:#20B2AA
    style Format fill:#32CD32
    style Success fill:#32CD32
    style Update fill:#FFD700
    style View fill:#FFD700
    style UpdateFlow fill:#FF8C00
    style ViewFlow fill:#FF8C00
    style End fill:#32CD32
```

---

## SMS Marketing Flows

### 1. Send SMS Campaign Flow

```mermaid
sequenceDiagram
    participant A as ⚪ Admin
    participant UI as ⚪ Frontend
    participant AG as 🟡 API Gateway
    participant AM as 🔵 Auth Middleware
    participant SC as 🟢 Send Campaign Function
    participant DB as 🔷 Database
    participant SNS as 🟪 AWS SNS

    A->>UI: Create SMS campaign
    UI->>AG: 🟡 POST /sms/campaigns/:id/send
    AG->>AM: Authenticate
    AM->>AM: 🔴 Check SMS_SEND permission

    alt No Permission
        AM-->>UI: 🔴 403 FORBIDDEN
    end

    AM->>SC: Forward request
    SC->>DB: 🔷 Get campaign details

    alt Campaign Not Found
        DB-->>SC: 🔴 Not found
        SC-->>UI: 🔴 404 error
    end

    DB-->>SC: 🟢 Campaign data
    SC->>DB: 🔷 Query customers by segments

    alt smsOptIn filter
        DB-->>SC: 🟢 Opted-in customers only
    end

    DB-->>SC: 🟢 Customer list

    loop For each customer
        SC->>SC: 🟢 Personalize message
        SC->>SC: 🟢 Add STOP footer (TCPA)
        SC->>SNS: 🟪 Send SMS
        SNS-->>SC: 🟢 MessageId or error
        SC->>DB: 🔷 Save message record
    end

    SC->>DB: 🔷 Update campaign status
    SC-->>UI: 🟢 Campaign sent successfully
    UI-->>A: 🟢 Show delivery stats

    style SC fill:#32CD32
    style AM fill:#4169E1
    style AG fill:#FFD700
    style DB fill:#20B2AA
    style SNS fill:#FF69B4
```

### 2. Two-Way SMS Conversation Flow

```mermaid
flowchart TD
    Start([🟪 Incoming SMS from Customer]) --> Webhook[🟡 SNS Webhook to Lambda]
    Webhook --> Parse[🟢 Parse SMS data]

    Parse --> Handler[🟢 Two-Way SMS Handler]
    Handler --> FindConv{🔷 Find conversation?}

    FindConv -->|Not Found| CreateConv[🔷 Create new conversation]
    FindConv -->|Found| UseConv[🟢 Use existing conversation]

    CreateConv --> SaveMsg[🔷 Save incoming message]
    UseConv --> SaveMsg

    SaveMsg --> CheckKeyword{🔴 Check for keywords}

    CheckKeyword -->|STOP/UNSUBSCRIBE| OptOut[🟢 Process opt-out]
    CheckKeyword -->|START/SUBSCRIBE| OptIn[🟢 Process opt-in]
    CheckKeyword -->|Regular Message| Store[🟢 Store message]

    OptOut --> UpdateCustomer1[🔷 Update customer: smsOptIn=false]
    OptIn --> UpdateCustomer2[🔷 Update customer: smsOptIn=true]

    UpdateCustomer1 --> SendConfirm1[🟪 Send confirmation SMS]
    UpdateCustomer2 --> SendConfirm2[🟪 Send confirmation SMS]
    Store --> Notify[🟢 Notify admin of new message]

    SendConfirm1 --> End([🟢 Complete])
    SendConfirm2 --> End
    Notify --> End

    Notify -.->|Admin replies| Reply[⚪ Admin sends reply]
    Reply --> SendReply[🟡 POST /sms/conversations/:id/reply]
    SendReply --> SendSMS[🟪 Send SMS via SNS]
    SendSMS --> SaveReply[🔷 Save reply message]
    SaveReply --> End

    style Start fill:#FF69B4
    style Webhook fill:#FFD700
    style Parse fill:#32CD32
    style Handler fill:#32CD32
    style FindConv fill:#20B2AA
    style CreateConv fill:#20B2AA
    style SaveMsg fill:#20B2AA
    style CheckKeyword fill:#DC143C
    style OptOut fill:#32CD32
    style OptIn fill:#32CD32
    style Store fill:#32CD32
    style UpdateCustomer1 fill:#20B2AA
    style UpdateCustomer2 fill:#20B2AA
    style SendConfirm1 fill:#FF69B4
    style SendConfirm2 fill:#FF69B4
    style SendSMS fill:#FF69B4
    style SaveReply fill:#20B2AA
    style End fill:#32CD32
```

### 3. SMS Template Management Flow

```mermaid
flowchart LR
    Start([⚪ Admin Action]) --> Action{Select Action}

    Action -->|Create| Create[🟡 POST /sms/templates]
    Action -->|List| List[🟡 GET /sms/templates]
    Action -->|Update| Update[🟡 PUT /sms/templates/:id]
    Action -->|Delete| Delete[🟡 DELETE /sms/templates/:id]

    Create --> Auth1[🔵 Check SMS_TEMPLATE_MANAGE]
    List --> Auth2[🔵 Check SMS_TEMPLATE_MANAGE]
    Update --> Auth3[🔵 Check SMS_TEMPLATE_MANAGE]
    Delete --> Auth4[🔵 Check SMS_TEMPLATE_MANAGE]

    Auth1 --> Extract[🟢 Extract variables from content]
    Extract --> SaveTemplate[🔷 Save to DynamoDB]

    Auth2 --> QueryTemplates[🔷 Query templates]
    Auth3 --> UpdateTemplate[🔷 Update template]
    Auth4 --> DeleteTemplate[🔷 Delete template]

    SaveTemplate --> Success1[🟢 Template created]
    QueryTemplates --> Success2[🟢 Return template list]
    UpdateTemplate --> Success3[🟢 Template updated]
    DeleteTemplate --> Success4[🟢 Template deleted]

    Success1 & Success2 & Success3 & Success4 --> End([🟢 Complete])

    style Start fill:#FFFFFF
    style Create fill:#FFD700
    style List fill:#FFD700
    style Update fill:#FFD700
    style Delete fill:#FFD700
    style Auth1 fill:#4169E1
    style Auth2 fill:#4169E1
    style Auth3 fill:#4169E1
    style Auth4 fill:#4169E1
    style Extract fill:#32CD32
    style SaveTemplate fill:#20B2AA
    style QueryTemplates fill:#20B2AA
    style UpdateTemplate fill:#20B2AA
    style DeleteTemplate fill:#20B2AA
    style End fill:#32CD32
```

---

## IVR/Voice System Flows

### 1. Initiate Outbound Call Flow

```mermaid
sequenceDiagram
    participant A as ⚪ Admin
    participant UI as ⚪ Frontend
    participant AG as 🟡 API Gateway
    participant AM as 🔵 Auth Middleware
    participant IC as 🟢 Initiate Call Function
    participant DB as 🔷 Database
    participant AC as 🟪 Amazon Connect

    A->>UI: Click "Call Customer"
    UI->>AG: 🟡 POST /ivr/calls/initiate
    AG->>AM: Authenticate
    AM->>AM: 🔴 Check VOICE_CALL_INITIATE permission

    alt No Permission
        AM-->>UI: 🔴 403 FORBIDDEN
    end

    AM->>IC: Forward request
    IC->>IC: 🟢 Format phone number (E.164)
    IC->>IC: 🟢 Create contact attributes

    IC->>AC: 🟪 StartOutboundVoiceContact

    alt Connect API Error
        AC-->>IC: 🔴 API Error
        IC-->>UI: 🔴 Call initiation failed
    end

    AC-->>IC: 🟢 ContactId

    IC->>DB: 🔷 Create call record
    IC-->>UI: 🟢 Call initiated
    UI-->>A: 🟢 Show call status

    Note over AC: Call in progress

    AC->>IC: 🟪 ContactFlowEvent
    IC->>DB: 🔷 Update call status

    AC->>IC: 🟪 CallCompleted event
    IC->>DB: 🔷 Update final status & duration
    IC->>DB: 🔷 Save call recording URL

    style IC fill:#32CD32
    style AM fill:#4169E1
    style AG fill:#FFD700
    style DB fill:#20B2AA
    style AC fill:#FF69B4
```

### 2. IVR Flow Execution

```mermaid
flowchart TD
    Start([🟪 Customer calls in]) --> Connect[🟪 Amazon Connect answers]
    Connect --> GetFlow[🟡 GET /ivr/flows/:id/execute]

    GetFlow --> LoadFlow[🔷 Load IVR flow from DB]
    LoadFlow --> GetEntry[🟢 Get entry step]

    GetEntry --> StepType{🔴 Step Type?}

    StepType -->|message| PlayMsg[🟪 Play message/audio]
    StepType -->|menu| PlayMenu[🟪 Play menu options]
    StepType -->|input| CollectInput[🟪 Collect DTMF input]
    StepType -->|transfer| Transfer[🟪 Transfer to number]
    StepType -->|callback| ScheduleCallback[🔷 Schedule callback]
    StepType -->|voicemail| Voicemail[🟪 Record voicemail]
    StepType -->|hours| CheckHours{🔴 Business hours?}
    StepType -->|queue| AddToQueue[🟪 Add to queue]

    PlayMsg --> NextStep1[🟢 Get next step]
    PlayMenu --> WaitDTMF[🟪 Wait for DTMF]
    WaitDTMF --> ProcessDTMF[🟢 Process option]
    CollectInput --> SaveInput[🔷 Save input]

    CheckHours -->|Open| OpenMsg[🟪 Play open message]
    CheckHours -->|Closed| ClosedMsg[🟪 Play closed message]

    Transfer --> End([🟢 Call transferred])
    ScheduleCallback --> End
    Voicemail --> RecordMsg[🟪 Record message]
    RecordMsg --> SaveRecording[🔷 Save recording]
    AddToQueue --> QueuedEnd([🟢 In queue])

    NextStep1 --> HasNext{🔴 Has next step?}
    ProcessDTMF --> HasNext
    SaveInput --> HasNext
    OpenMsg --> HasNext
    ClosedMsg --> End

    HasNext -->|Yes| StepType
    HasNext -->|No| End
    SaveRecording --> End

    style Start fill:#FF69B4
    style Connect fill:#FF69B4
    style GetFlow fill:#FFD700
    style LoadFlow fill:#20B2AA
    style GetEntry fill:#32CD32
    style StepType fill:#DC143C
    style PlayMsg fill:#FF69B4
    style PlayMenu fill:#FF69B4
    style CollectInput fill:#FF69B4
    style Transfer fill:#FF69B4
    style ScheduleCallback fill:#20B2AA
    style Voicemail fill:#FF69B4
    style CheckHours fill:#DC143C
    style AddToQueue fill:#FF69B4
    style SaveInput fill:#20B2AA
    style RecordMsg fill:#FF69B4
    style SaveRecording fill:#20B2AA
    style End fill:#32CD32
```

### 3. Voice Campaign Flow

```mermaid
flowchart TD
    Start([⚪ Admin starts voice campaign]) --> API[🟡 POST /ivr/campaigns/:id/start]
    API --> Auth[🔵 Check VOICE_CALL_INITIATE permission]

    Auth --> GetCampaign[🔷 Get campaign details]
    GetCampaign --> GetCustomers[🔷 Query customers by segments]

    GetCustomers --> Batch[🟢 Batch customers]
    Batch --> Loop{🔴 More batches?}

    Loop -->|Yes| ProcessBatch[🟢 Process batch]
    Loop -->|No| Complete[🟢 Campaign complete]

    ProcessBatch --> Parallel[🟢 Initiate calls in parallel]
    Parallel --> Call1[🟪 Call customer 1]
    Parallel --> Call2[🟪 Call customer 2]
    Parallel --> Call3[🟪 Call customer N]

    Call1 --> Record1[🔷 Record call result]
    Call2 --> Record2[🔷 Record call result]
    Call3 --> Record3[🔷 Record call result]

    Record1 & Record2 & Record3 --> Delay[🟤 Wait 1 second]
    Delay --> Loop

    Complete --> UpdateCampaign[🔷 Update campaign status]
    UpdateCampaign --> Stats[🟢 Calculate statistics]
    Stats --> End([🟢 Campaign finished])

    style Start fill:#FFFFFF
    style API fill:#FFD700
    style Auth fill:#4169E1
    style GetCampaign fill:#20B2AA
    style GetCustomers fill:#20B2AA
    style Batch fill:#32CD32
    style Loop fill:#DC143C
    style ProcessBatch fill:#32CD32
    style Parallel fill:#32CD32
    style Call1 fill:#FF69B4
    style Call2 fill:#FF69B4
    style Call3 fill:#FF69B4
    style Record1 fill:#20B2AA
    style Record2 fill:#20B2AA
    style Record3 fill:#20B2AA
    style Delay fill:#8B4513
    style Complete fill:#32CD32
    style UpdateCampaign fill:#20B2AA
    style Stats fill:#32CD32
    style End fill:#32CD32
```

---

## Email Campaign Flows

### 1. Create and Send Email Campaign

```mermaid
sequenceDiagram
    participant A as ⚪ Admin
    participant UI as ⚪ Frontend
    participant AG as 🟡 API Gateway
    participant AM as 🔵 Auth Middleware
    participant EC as 🟢 Email Campaign Function
    participant DB as 🔷 Database
    participant SES as 🟪 AWS SES

    A->>UI: Create email campaign
    UI->>AG: 🟡 POST /campaigns
    AG->>AM: Authenticate
    AM->>AM: 🔴 Check CAMPAIGN_CREATE permission

    AM->>EC: Forward request
    EC->>DB: 🔷 Save campaign (status: DRAFT)
    DB-->>EC: 🟢 Campaign created
    EC-->>UI: 🟢 Campaign ID

    A->>UI: Design email content
    UI->>AG: 🟡 PUT /campaigns/:id
    AG->>AM: Authenticate
    AM->>EC: Forward request
    EC->>DB: 🔷 Update campaign content

    A->>UI: Select recipients (segments)
    UI->>AG: 🟡 PUT /campaigns/:id/recipients
    AG->>AM: Authenticate
    AM->>EC: Forward request
    EC->>DB: 🔷 Update campaign segments

    A->>UI: Schedule or send now
    UI->>AG: 🟡 POST /campaigns/:id/send
    AG->>AM: Authenticate
    AM->>AM: 🔴 Check CAMPAIGN_SEND permission
    AM->>EC: Forward request

    EC->>DB: 🔷 Query customers by segments
    DB-->>EC: 🟢 Customer list

    loop For each customer
        EC->>EC: 🟢 Personalize content
        EC->>SES: 🟪 Send email
        SES-->>EC: 🟢 MessageId
        EC->>DB: 🔷 Log sent email
    end

    EC->>DB: 🔷 Update campaign status (SENT)
    EC-->>UI: 🟢 Campaign sent
    UI-->>A: 🟢 Show delivery report

    style EC fill:#32CD32
    style AM fill:#4169E1
    style AG fill:#FFD700
    style DB fill:#20B2AA
    style SES fill:#FF69B4
```

---

## Social Media Content Flows

### 1. AI Content Generation Flow

```mermaid
flowchart TD
    Start([⚪ User requests AI content]) --> API[🟡 POST /social/content/generate]
    API --> Auth[🔵 Check SOCIAL_CONTENT_CREATE]

    Auth --> GetBrand[🔷 Get business brand voice]
    GetBrand --> BuildPrompt[🟢 Build AI prompt]

    BuildPrompt --> CallAI[🟪 Call OpenAI GPT-4]
    CallAI --> ParseResponse[🟢 Parse AI response]

    ParseResponse --> Extract[🟢 Extract content, hashtags]
    Extract --> SaveDraft[🔷 Save as DRAFT]

    SaveDraft --> Success[🟢 Return generated content]
    Success --> UserReview{⚪ User Action}

    UserReview -->|Edit| Edit[⚪ User edits content]
    UserReview -->|Regenerate| BuildPrompt
    UserReview -->|Approve| Schedule

    Edit --> Update[🔷 Update content]
    Update --> Schedule{⚪ Schedule or Post?}

    Schedule -->|Schedule| SetSchedule[🔷 Set scheduledAt]
    Schedule -->|Post Now| Publish

    SetSchedule --> EventBridge[🟤 EventBridge scheduled rule]
    EventBridge -.->|At scheduled time| Publish[🟡 POST /social/content/:id/publish]

    Publish --> AuthPub[🔵 Check SOCIAL_CONTENT_PUBLISH]
    AuthPub --> GetAccounts[🔷 Get social accounts]

    GetAccounts --> PostLoop{🔴 For each platform}
    PostLoop -->|Twitter| Twitter[🟪 Twitter API post]
    PostLoop -->|LinkedIn| LinkedIn[🟪 LinkedIn API post]
    PostLoop -->|Facebook| Facebook[🟪 Facebook API post]
    PostLoop -->|Instagram| Instagram[🟪 Instagram API post]

    Twitter --> SaveResult1[🔷 Save post result]
    LinkedIn --> SaveResult2[🔷 Save post result]
    Facebook --> SaveResult3[🔷 Save post result]
    Instagram --> SaveResult4[🔷 Save post result]

    SaveResult1 & SaveResult2 & SaveResult3 & SaveResult4 --> UpdateStatus[🔷 Update status to PUBLISHED]
    UpdateStatus --> End([🟢 Published])

    style Start fill:#FFFFFF
    style API fill:#FFD700
    style Auth fill:#4169E1
    style GetBrand fill:#20B2AA
    style BuildPrompt fill:#32CD32
    style CallAI fill:#FF69B4
    style ParseResponse fill:#32CD32
    style Extract fill:#32CD32
    style SaveDraft fill:#20B2AA
    style Success fill:#32CD32
    style Edit fill:#FFFFFF
    style Update fill:#20B2AA
    style SetSchedule fill:#20B2AA
    style EventBridge fill:#8B4513
    style Publish fill:#FFD700
    style AuthPub fill:#4169E1
    style GetAccounts fill:#20B2AA
    style Twitter fill:#FF69B4
    style LinkedIn fill:#FF69B4
    style Facebook fill:#FF69B4
    style Instagram fill:#FF69B4
    style UpdateStatus fill:#20B2AA
    style End fill:#32CD32
```

### 2. Social Media Analytics Collection

```mermaid
flowchart LR
    Start([🟤 Scheduled Job]) --> Trigger[🟤 EventBridge triggers]
    Trigger --> Function[🟢 Analytics Collector]

    Function --> GetPosts[🔷 Get published posts]
    GetPosts --> Loop{🔴 For each post}

    Loop -->|Has more| GetPlatform{🔴 Platform?}
    Loop -->|Done| Aggregate

    GetPlatform -->|Twitter| TwitterAPI[🟪 Twitter Analytics API]
    GetPlatform -->|LinkedIn| LinkedInAPI[🟪 LinkedIn Analytics API]
    GetPlatform -->|Facebook| FacebookAPI[🟪 Facebook Insights API]
    GetPlatform -->|Instagram| InstagramAPI[🟪 Instagram Insights API]

    TwitterAPI --> SaveMetrics1[🔷 Save engagement metrics]
    LinkedInAPI --> SaveMetrics2[🔷 Save engagement metrics]
    FacebookAPI --> SaveMetrics3[🔷 Save engagement metrics]
    InstagramAPI --> SaveMetrics4[🔷 Save engagement metrics]

    SaveMetrics1 & SaveMetrics2 & SaveMetrics3 & SaveMetrics4 --> Loop

    Aggregate[🟢 Aggregate analytics] --> SaveAnalytics[🔷 Save to analytics table]
    SaveAnalytics --> End([🟢 Complete])

    style Start fill:#8B4513
    style Trigger fill:#8B4513
    style Function fill:#32CD32
    style GetPosts fill:#20B2AA
    style Loop fill:#DC143C
    style GetPlatform fill:#DC143C
    style TwitterAPI fill:#FF69B4
    style LinkedInAPI fill:#FF69B4
    style FacebookAPI fill:#FF69B4
    style InstagramAPI fill:#FF69B4
    style SaveMetrics1 fill:#20B2AA
    style SaveMetrics2 fill:#20B2AA
    style SaveMetrics3 fill:#20B2AA
    style SaveMetrics4 fill:#20B2AA
    style Aggregate fill:#32CD32
    style SaveAnalytics fill:#20B2AA
    style End fill:#32CD32
```

---

## Customer Management Flows

### 1. Customer Import Flow

```mermaid
sequenceDiagram
    participant A as ⚪ Admin
    participant UI as ⚪ Frontend
    participant AG as 🟡 API Gateway
    participant AM as 🔵 Auth Middleware
    participant CI as 🟢 Customer Import Function
    participant S3 as 🟪 AWS S3
    participant DB as 🔷 Database

    A->>UI: Upload CSV/Excel file
    UI->>UI: 🟢 Validate file format

    alt Invalid Format
        UI-->>A: 🔴 Invalid file format
    end

    UI->>S3: 🟪 Upload file to S3
    S3-->>UI: 🟢 File URL

    UI->>AG: 🟡 POST /customers/import
    AG->>AM: Authenticate
    AM->>AM: 🔴 Check CUSTOMER_IMPORT permission

    alt No Permission
        AM-->>UI: 🔴 403 FORBIDDEN
    end

    AM->>CI: Forward request with S3 URL
    CI->>S3: 🟪 Download file
    S3-->>CI: 🟢 File content

    CI->>CI: 🟢 Parse CSV/Excel
    CI->>CI: 🔴 Validate data

    alt Validation Errors
        CI-->>UI: 🔴 Validation errors report
        UI-->>A: 🔴 Show errors
    end

    loop For each valid row
        CI->>DB: 🔷 Check if customer exists

        alt Exists
            DB-->>CI: 🟢 Customer found
            CI->>DB: 🔷 Update customer
        else New
            DB-->>CI: 🔴 Not found
            CI->>DB: 🔷 Create customer
        end
    end

    CI->>CI: 🟢 Generate import report
    CI-->>UI: 🟢 Import complete + report
    UI-->>A: 🟢 Show import results

    style CI fill:#32CD32
    style AM fill:#4169E1
    style AG fill:#FFD700
    style DB fill:#20B2AA
    style S3 fill:#FF69B4
```

### 2. Customer Segmentation Flow

```mermaid
flowchart TD
    Start([⚪ Admin creates segment]) --> API[🟡 POST /segments]
    API --> Auth[🔵 Check CUSTOMER_READ]

    Auth --> ParseRules[🟢 Parse segment rules]
    ParseRules --> ValidateRules{🔴 Valid rules?}

    ValidateRules -->|No| Error[🔴 Invalid rules error]
    ValidateRules -->|Yes| SaveSegment[🔷 Save segment definition]

    SaveSegment --> Calculate[🟢 Calculate matching customers]
    Calculate --> BuildQuery[🟢 Build DynamoDB query]

    BuildQuery --> QueryDB[🔷 Query customers]
    QueryDB --> Filter[🟢 Apply additional filters]

    Filter --> Count[🟢 Count matches]
    Count --> UpdateSegment[🔷 Update customer count]

    UpdateSegment --> Success[🟢 Segment created]
    Success --> End([🟢 Complete])

    Error --> End

    style Start fill:#FFFFFF
    style API fill:#FFD700
    style Auth fill:#4169E1
    style ParseRules fill:#32CD32
    style ValidateRules fill:#DC143C
    style Error fill:#DC143C
    style SaveSegment fill:#20B2AA
    style Calculate fill:#32CD32
    style BuildQuery fill:#32CD32
    style QueryDB fill:#20B2AA
    style Filter fill:#32CD32
    style Count fill:#32CD32
    style UpdateSegment fill:#20B2AA
    style Success fill:#32CD32
    style End fill:#32CD32
```

---

## Analytics & Reporting Flows

### 1. Real-Time Dashboard Data Flow

```mermaid
sequenceDiagram
    participant U as ⚪ User
    participant UI as ⚪ Frontend
    participant AG as 🟡 API Gateway
    participant AM as 🔵 Auth Middleware
    participant AF as 🟢 Analytics Function
    participant DB as 🔷 Database

    U->>UI: Open analytics dashboard
    UI->>AG: 🟡 GET /analytics?period=daily
    AG->>AM: Authenticate
    AM->>AM: 🔴 Check ANALYTICS_VIEW permission

    AM->>AF: Forward request
    AF->>DB: 🔷 Query analytics table

    par Parallel Queries
        AF->>DB: 🔷 Get campaign metrics
        AF->>DB: 🔷 Get customer metrics
        AF->>DB: 🔷 Get engagement metrics
        AF->>DB: 🔷 Get revenue metrics
    end

    DB-->>AF: 🟢 All metrics data

    AF->>AF: 🟢 Calculate KPIs
    AF->>AF: 🟢 Format for charts

    AF-->>UI: 🟢 Analytics data
    UI->>UI: 🟢 Render charts
    UI-->>U: 🟢 Display dashboard

    Note over U,UI: User changes date range

    U->>UI: Select date range
    UI->>AG: 🟡 GET /analytics?start=X&end=Y
    AG->>AM: Authenticate
    AM->>AF: Forward request
    AF->>DB: 🔷 Query with date filter
    DB-->>AF: 🟢 Filtered data
    AF-->>UI: 🟢 Updated metrics
    UI-->>U: 🟢 Refresh dashboard

    style AF fill:#32CD32
    style AM fill:#4169E1
    style AG fill:#FFD700
    style DB fill:#20B2AA
```

### 2. Report Export Flow

```mermaid
flowchart TD
    Start([⚪ User requests report export]) --> API[🟡 POST /analytics/export]
    API --> Auth[🔵 Check ANALYTICS_EXPORT]

    Auth --> GetData[🔷 Query analytics data]
    GetData --> Format{⚪ Export format?}

    Format -->|PDF| GeneratePDF[🟢 Generate PDF report]
    Format -->|CSV| GenerateCSV[🟢 Generate CSV file]
    Format -->|Excel| GenerateExcel[🟢 Generate Excel file]

    GeneratePDF --> UploadPDF[🟪 Upload to S3]
    GenerateCSV --> UploadCSV[🟪 Upload to S3]
    GenerateExcel --> UploadExcel[🟪 Upload to S3]

    UploadPDF --> GetURL1[🟢 Generate signed URL]
    UploadCSV --> GetURL2[🟢 Generate signed URL]
    UploadExcel --> GetURL3[🟢 Generate signed URL]

    GetURL1 & GetURL2 & GetURL3 --> SendEmail{⚪ Email report?}

    SendEmail -->|Yes| EmailReport[🟪 Send via SES]
    SendEmail -->|No| DirectDownload

    EmailReport --> DirectDownload[🟢 Return download URL]
    DirectDownload --> End([🟢 Complete])

    style Start fill:#FFFFFF
    style API fill:#FFD700
    style Auth fill:#4169E1
    style GetData fill:#20B2AA
    style Format fill:#FFFFFF
    style GeneratePDF fill:#32CD32
    style GenerateCSV fill:#32CD32
    style GenerateExcel fill:#32CD32
    style UploadPDF fill:#FF69B4
    style UploadCSV fill:#FF69B4
    style UploadExcel fill:#FF69B4
    style GetURL1 fill:#32CD32
    style GetURL2 fill:#32CD32
    style GetURL3 fill:#32CD32
    style EmailReport fill:#FF69B4
    style DirectDownload fill:#32CD32
    style End fill:#32CD32
```

---

## Subscription & Billing Flows

### 1. Subscription Upgrade Flow

```mermaid
sequenceDiagram
    participant A as ⚪ Admin
    participant UI as ⚪ Frontend
    participant AG as 🟡 API Gateway
    participant AM as 🔵 Auth Middleware
    participant SF as 🟢 Subscription Function
    participant DB as 🔷 Database
    participant Stripe as 🟪 Stripe API

    A->>UI: Select new tier (e.g., PROFESSIONAL)
    UI->>AG: 🟡 POST /subscriptions/upgrade
    AG->>AM: Authenticate

    AM->>SF: Forward request
    SF->>DB: 🔷 Get current subscription
    DB-->>SF: 🟢 Current tier (STARTER)

    SF->>SF: 🟢 Calculate prorated amount
    SF->>Stripe: 🟪 Create payment intent
    Stripe-->>SF: 🟢 Payment intent

    SF-->>UI: 🟢 Return payment intent
    UI->>UI: 🟪 Show Stripe payment form

    A->>UI: Enter payment details
    UI->>Stripe: 🟪 Confirm payment

    alt Payment Failed
        Stripe-->>UI: 🔴 Payment failed
        UI-->>A: 🔴 Show error
    end

    Stripe-->>UI: 🟢 Payment successful

    UI->>AG: 🟡 POST /subscriptions/confirm
    AG->>AM: Authenticate
    AM->>SF: Forward request

    SF->>Stripe: 🟪 Verify payment
    Stripe-->>SF: 🟢 Payment confirmed

    SF->>DB: 🔷 Update user subscriptionTier
    SF->>SF: 🟢 Recalculate permissions
    SF->>DB: 🔷 Update user permissions

    SF->>DB: 🔷 Create subscription record
    SF->>DB: 🔷 Create invoice record

    SF-->>UI: 🟢 Upgrade complete
    UI->>UI: 🔵 Refresh tokens with new permissions
    UI-->>A: 🟢 Show success + new features

    style SF fill:#32CD32
    style AM fill:#4169E1
    style AG fill:#FFD700
    style DB fill:#20B2AA
    style Stripe fill:#FF69B4
```

---

## Permission Matrix

### User Role to Feature Access

```
Feature                          | SUPER_ADMIN | ADMIN (FREE) | ADMIN (STARTER) | ADMIN (PRO) | ADMIN (ENTERPRISE) | USER | GUEST
--------------------------------|-------------|--------------|-----------------|-------------|-------------------|------|-------
Create Users                    |      ✅      |      ❌      |       ❌         |     ❌      |        ✅          |  ❌  |  ❌
Manage All Tenants              |      ✅      |      ❌      |       ❌         |     ❌      |        ❌          |  ❌  |  ❌
Assign Roles                    |      ✅      |      ❌      |       ❌         |     ❌      |        ✅          |  ❌  |  ❌
View Customers                  |      ✅      |      ✅      |       ✅         |     ✅      |        ✅          |  ✅  |  ✅
Create Customers                |      ✅      |      ❌      |       ✅         |     ✅      |        ✅          |  ❌  |  ❌
Delete Customers                |      ✅      |      ❌      |       ❌         |     ✅      |        ✅          |  ❌  |  ❌
Import/Export Customers         |      ✅      |      ❌      |       ❌         |     ✅      |        ✅          |  ❌  |  ❌
Send SMS                        |      ✅      |      ❌      |       ✅         |     ✅      |        ✅          |  ❌  |  ❌
Manage SMS Templates            |      ✅      |      ❌      |       ❌         |     ✅      |        ✅          |  ❌  |  ❌
Two-Way SMS                     |      ✅      |      ❌      |       ❌         |     ✅      |        ✅          |  ❌  |  ❌
Send Emails                     |      ✅      |      ❌      |       ✅         |     ✅      |        ✅          |  ❌  |  ❌
Initiate Voice Calls            |      ✅      |      ❌      |       ❌         |     ❌      |        ✅          |  ❌  |  ❌
Manage IVR Flows                |      ✅      |      ❌      |       ❌         |     ❌      |        ✅          |  ❌  |  ❌
View Call Analytics             |      ✅      |      ❌      |       ❌         |     ❌      |        ✅          |  ❌  |  ❌
Create Social Content           |      ✅      |      ❌      |       ❌         |     ✅      |        ✅          |  ❌  |  ❌
Publish to Social Media         |      ✅      |      ❌      |       ❌         |     ✅      |        ✅          |  ❌  |  ❌
View Analytics                  |      ✅      |      ✅      |       ✅         |     ✅      |        ✅          |  ✅  |  ❌
Export Reports                  |      ✅      |      ❌      |       ❌         |     ✅      |        ✅          |  ❌  |  ❌
Manage Integrations             |      ✅      |      ❌      |       ❌         |     ❌      |        ✅          |  ❌  |  ❌
Manage Billing                  |      ✅      |      ❌      |       ❌         |     ❌      |        ✅          |  ❌  |  ❌
```

---

## API Endpoint Color Reference

### Authentication Endpoints (🔵 Blue)
- `POST /auth/signup` - User registration
- `POST /auth/signin` - User authentication
- `POST /auth/refresh` - Refresh access token
- `POST /auth/logout` - User logout

### User Management Endpoints (🟠 Orange)
- `GET /auth/users` - List users
- `GET /auth/users/:id` - Get user details
- `POST /auth/users/assign-role` - Assign role (Super Admin)
- `PUT /auth/users/:id` - Update user
- `DELETE /auth/users/:id` - Delete user (Super Admin)

### SMS Marketing Endpoints (🟢 Green)
- `POST /sms/campaigns/:id/send` - Send SMS campaign
- `POST /sms/templates` - Create SMS template
- `GET /sms/templates` - List SMS templates
- `POST /sms/conversations/:id/reply` - Reply to SMS
- `GET /sms/conversations` - List conversations
- `POST /sms/opt-in` - Process opt-in
- `POST /sms/opt-out` - Process opt-out

### IVR/Voice Endpoints (🟢 Green)
- `POST /ivr/calls/initiate` - Initiate outbound call
- `POST /ivr/flows` - Create IVR flow
- `GET /ivr/flows` - List IVR flows
- `GET /ivr/flows/:id/execute` - Execute flow step
- `POST /ivr/campaigns/:id/start` - Start voice campaign
- `GET /ivr/analytics` - Get call analytics
- `GET /ivr/calls/:id` - Get call details

### Email Campaign Endpoints (🟢 Green)
- `POST /campaigns` - Create campaign
- `PUT /campaigns/:id` - Update campaign
- `POST /campaigns/:id/send` - Send campaign
- `GET /campaigns` - List campaigns
- `DELETE /campaigns/:id` - Delete campaign

### Social Media Endpoints (🟢 Green)
- `POST /social/content/generate` - Generate AI content
- `POST /social/content` - Create content
- `POST /social/content/:id/publish` - Publish content
- `GET /social/content` - List content
- `POST /social/accounts` - Connect social account
- `GET /social/analytics` - Get social analytics

### Customer Management Endpoints (🟢 Green)
- `POST /customers` - Create customer
- `GET /customers` - List customers
- `PUT /customers/:id` - Update customer
- `DELETE /customers/:id` - Delete customer
- `POST /customers/import` - Import customers
- `GET /customers/export` - Export customers

### Segment Endpoints (🟢 Green)
- `POST /segments` - Create segment
- `GET /segments` - List segments
- `PUT /segments/:id` - Update segment
- `GET /segments/:id/customers` - Get segment customers

### Analytics Endpoints (🟢 Green)
- `GET /analytics` - Get analytics data
- `POST /analytics/export` - Export report
- `GET /analytics/campaigns` - Campaign analytics
- `GET /analytics/customers` - Customer analytics

### Subscription Endpoints (🟪 Pink)
- `POST /subscriptions/upgrade` - Upgrade subscription
- `POST /subscriptions/confirm` - Confirm subscription
- `GET /subscriptions/current` - Get current subscription
- `POST /subscriptions/cancel` - Cancel subscription

---

## Database Operations Color Reference

### DynamoDB Operations (🔷 Teal)
- Query - Search with partition/sort keys
- Scan - Full table scan
- PutItem - Create or replace item
- UpdateItem - Update specific attributes
- DeleteItem - Delete item
- BatchWriteItem - Batch create/update
- GetItem - Retrieve single item

### PostgreSQL/RDS Operations (🔷 Teal)
- INSERT - Create records
- SELECT - Query records
- UPDATE - Update records
- DELETE - Delete records
- JOIN - Combine tables
- Transaction - Atomic operations

---

## External Service Color Reference

### AWS Services (🟪 Pink)
- **AWS SNS** - SMS message delivery
- **Amazon Connect** - IVR/Voice calls
- **AWS SES** - Email delivery
- **AWS S3** - File storage
- **EventBridge** - Scheduled jobs
- **CloudWatch** - Logging & monitoring

### Third-Party APIs (🟪 Pink)
- **OpenAI GPT-4** - AI content generation
- **Stripe** - Payment processing
- **Twitter API** - Social media posting
- **LinkedIn API** - Professional network
- **Facebook API** - Social media platform
- **Instagram API** - Image/video sharing

---

## Error Handling Flow

```mermaid
flowchart TD
    Start([🟡 API Request]) --> TryCatch{🔴 Try/Catch}

    TryCatch -->|Success| Process[🟢 Process request]
    TryCatch -->|Error| ErrorType{🔴 Error Type?}

    ErrorType -->|ValidationError| Return400[🔴 400 Bad Request]
    ErrorType -->|AuthError| Return401[🔴 401 Unauthorized]
    ErrorType -->|PermissionError| Return403[🔴 403 Forbidden]
    ErrorType -->|NotFoundError| Return404[🔴 404 Not Found]
    ErrorType -->|ConflictError| Return409[🔴 409 Conflict]
    ErrorType -->|ServerError| Return500[🔴 500 Internal Error]

    Return400 --> Log[🟤 Log error]
    Return401 --> Log
    Return403 --> Log
    Return404 --> Log
    Return409 --> Log
    Return500 --> Log

    Log --> Alert{🔴 Critical?}
    Alert -->|Yes| SendAlert[🟪 Send CloudWatch alarm]
    Alert -->|No| End

    SendAlert --> End([🔴 Error response])
    Process --> Success([🟢 Success response])

    style Start fill:#FFD700
    style TryCatch fill:#DC143C
    style Process fill:#32CD32
    style ErrorType fill:#DC143C
    style Return400 fill:#DC143C
    style Return401 fill:#DC143C
    style Return403 fill:#DC143C
    style Return404 fill:#DC143C
    style Return409 fill:#DC143C
    style Return500 fill:#DC143C
    style Log fill:#8B4513
    style Alert fill:#DC143C
    style SendAlert fill:#FF69B4
    style End fill:#DC143C
    style Success fill:#32CD32
```

---

## Complete Request Lifecycle

```mermaid
sequenceDiagram
    participant User as ⚪ User
    participant FE as ⚪ Frontend
    participant AG as 🟡 API Gateway
    participant Auth as 🔵 Auth Middleware
    participant Perm as 🔵 Permission Check
    participant Lambda as 🟢 Lambda Function
    participant DB as 🔷 Database
    participant Ext as 🟪 External Service
    participant CW as 🟤 CloudWatch

    User->>FE: Action
    FE->>FE: Validate input
    FE->>AG: HTTP Request + Bearer Token
    AG->>CW: Log request
    AG->>Auth: Authenticate

    Auth->>Auth: Verify JWT
    alt Invalid Token
        Auth-->>FE: 🔴 401 Unauthorized
        FE-->>User: 🔴 Please sign in
    end

    Auth->>Perm: Check permissions

    alt No Permission
        Perm-->>FE: 🔴 403 Forbidden
        FE-->>User: 🔴 Access denied
    end

    Perm->>Lambda: Execute function
    Lambda->>CW: Log execution start

    Lambda->>DB: Query/Update data
    DB-->>Lambda: Result

    opt External Service Needed
        Lambda->>Ext: API call
        Ext-->>Lambda: Response
    end

    Lambda->>CW: Log execution end
    Lambda-->>FE: Success response
    FE-->>User: Display result

    style User fill:#FFFFFF
    style FE fill:#FFFFFF
    style AG fill:#FFD700
    style Auth fill:#4169E1
    style Perm fill:#4169E1
    style Lambda fill:#32CD32
    style DB fill:#20B2AA
    style Ext fill:#FF69B4
    style CW fill:#8B4513
```

---

## Summary Statistics

### Total API Endpoints: **67**
- Authentication: 5 endpoints
- User Management: 5 endpoints
- SMS Marketing: 11 endpoints
- IVR/Voice: 12 endpoints
- Email Campaigns: 10 endpoints
- Social Media: 8 endpoints
- Customer Management: 8 endpoints
- Analytics: 5 endpoints
- Subscriptions: 3 endpoints

### Total Lambda Functions: **40+**
- Auth Functions: 3
- User Management: 5
- SMS Marketing: 4
- IVR/Voice: 5
- Email: 5
- Social Media: 6
- Customers: 5
- Analytics: 3
- Scheduled Jobs: 4+

### Total Permissions: **70+**
- User Management: 5
- Customer Management: 6
- Campaign Management: 5
- Email Marketing: 2
- SMS Marketing: 3
- IVR/Voice: 3
- Social Media: 3
- Analytics: 2
- System: 3+

### External Integrations: **10+**
- AWS Services: SNS, SES, Connect, S3, EventBridge
- Social Media: Twitter, LinkedIn, Facebook, Instagram
- AI: OpenAI GPT-4
- Payments: Stripe

---

**Document Version**: 1.0.0
**Last Updated**: 2025-11-04
**Total Diagrams**: 25+
