/**
 * Core type definitions for the Marketing Platform
 */

// ============================================
// Authentication & User Types
// ============================================

export enum UserRole {
  SUPER_ADMIN = 'SUPER_ADMIN',
  ADMIN = 'ADMIN',
  SUB_ADMIN = 'SUB_ADMIN',
  AGENT = 'AGENT',
  SUBSCRIBER = 'SUBSCRIBER',
}

export interface Permission {
  id: string;
  name: string;
  resource: string;
  action: 'create' | 'read' | 'update' | 'delete' | 'execute';
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  permissions: Permission[];
  tenantId: string;
  avatar?: string;
  phoneNumber?: string;
  company?: string;
  timezone?: string;
  mfaEnabled: boolean;
  emailVerified: boolean;
  lastLogin?: string;
  createdAt: string;
  updatedAt: string;
  subscription?: Subscription;
}

export interface AuthSession {
  user: User;
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
}

// ============================================
// Customer/CRM Types
// ============================================

export enum CustomerStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
  UNSUBSCRIBED = 'UNSUBSCRIBED',
  BOUNCED = 'BOUNCED',
}

export interface Customer {
  id: string;
  email: string;
  phoneNumber?: string;
  firstName?: string;
  lastName?: string;
  company?: string;
  status: CustomerStatus;
  tags: string[];
  customFields: Record<string, any>;
  segments: string[];
  source?: string;
  emailOptIn: boolean;
  smsOptIn: boolean;
  lastActivity?: string;
  totalPurchases?: number;
  totalRevenue?: number;
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustomerSegment {
  id: string;
  name: string;
  description?: string;
  filters: SegmentFilter[];
  customerCount: number;
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

export interface SegmentFilter {
  field: string;
  operator: 'eq' | 'ne' | 'gt' | 'lt' | 'gte' | 'lte' | 'contains' | 'in';
  value: any;
}

// ============================================
// Campaign Types
// ============================================

export enum CampaignType {
  EMAIL = 'EMAIL',
  SMS = 'SMS',
  VOICE = 'VOICE',
}

export enum CampaignStatus {
  DRAFT = 'DRAFT',
  SCHEDULED = 'SCHEDULED',
  SENDING = 'SENDING',
  SENT = 'SENT',
  PAUSED = 'PAUSED',
  CANCELLED = 'CANCELLED',
  FAILED = 'FAILED',
}

export interface Campaign {
  id: string;
  name: string;
  type: CampaignType;
  status: CampaignStatus;
  subject?: string; // For email
  content: string;
  htmlContent?: string; // For email
  fromEmail?: string;
  fromName?: string;
  replyToEmail?: string;
  segments: string[];
  tags: string[];
  scheduledAt?: string;
  sentAt?: string;
  recipients: number;
  tenantId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;

  // A/B Testing
  abTest?: {
    enabled: boolean;
    variants: CampaignVariant[];
    winnerCriteria: 'open_rate' | 'click_rate' | 'conversion_rate';
  };

  // Analytics
  analytics?: CampaignAnalytics;
}

export interface CampaignVariant {
  id: string;
  name: string;
  percentage: number;
  subject?: string;
  content: string;
}

export interface CampaignAnalytics {
  sent: number;
  delivered: number;
  opened: number;
  clicked: number;
  bounced: number;
  unsubscribed: number;
  complained: number;
  deliveryRate: number;
  openRate: number;
  clickRate: number;
  unsubscribeRate: number;
}

// ============================================
// Message Types
// ============================================

export enum MessageStatus {
  PENDING = 'PENDING',
  SENT = 'SENT',
  DELIVERED = 'DELIVERED',
  OPENED = 'OPENED',
  CLICKED = 'CLICKED',
  BOUNCED = 'BOUNCED',
  FAILED = 'FAILED',
}

export interface Message {
  id: string;
  campaignId?: string;
  customerId: string;
  type: CampaignType;
  subject?: string;
  content: string;
  status: MessageStatus;
  sender?: MessageSender;
  sentAt?: string;
  deliveredAt?: string;
  openedAt?: string;
  clickedAt?: string;
  error?: string;
  metadata: Record<string, any>;
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

// ============================================
// Chat/Support Types
// ============================================

export enum ConversationStatus {
  OPEN = 'OPEN',
  ASSIGNED = 'ASSIGNED',
  RESOLVED = 'RESOLVED',
  CLOSED = 'CLOSED',
}

export enum MessageSender {
  CUSTOMER = 'CUSTOMER',
  AGENT = 'AGENT',
  BOT = 'BOT',
  SYSTEM = 'SYSTEM',
}

export interface Conversation {
  id: string;
  customerId: string;
  customer: Customer;
  status: ConversationStatus;
  assignedTo?: string;
  assignedAgent?: User;
  channel: 'web' | 'email' | 'sms' | 'voice';
  subject?: string;
  messages: ChatMessage[];
  lastMessage?: string;
  unreadCount?: number;
  tags: string[];
  priority: 'low' | 'normal' | 'high' | 'urgent';
  tenantId: string;
  createdAt: string;
  updatedAt: string;
  closedAt?: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  sender: MessageSender;
  senderId: string;
  content: string;
  attachments?: Attachment[];
  metadata?: Record<string, any>;
  createdAt: string;
}

export interface Attachment {
  id: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  url: string;
}

export interface CannedResponse {
  id: string;
  title: string;
  content: string;
  shortcut?: string;
  tags: string[];
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

// ============================================
// IVR/Voice Types
// ============================================

export enum CallStatus {
  INITIATED = 'INITIATED',
  RINGING = 'RINGING',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  BUSY = 'BUSY',
  NO_ANSWER = 'NO_ANSWER',
}

export enum CallDirection {
  INBOUND = 'INBOUND',
  OUTBOUND = 'OUTBOUND',
}

export interface Call {
  id: string;
  customerId?: string;
  customer?: Customer;
  direction: CallDirection;
  status: CallStatus;
  fromNumber: string;
  toNumber: string;
  duration?: number;
  recordingUrl?: string;
  transcript?: string;
  connectContactId?: string;
  metadata: Record<string, any>;
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

export interface IVRFlow {
  id: string;
  name: string;
  description?: string;
  steps: IVRStep[];
  isActive: boolean;
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

export interface IVRStep {
  id: string;
  type: 'message' | 'menu' | 'input' | 'transfer' | 'callback';
  message?: string;
  options?: IVROption[];
  transferTo?: string;
  nextStep?: string;
}

export interface IVROption {
  digit: string;
  label: string;
  action: string;
}

// ============================================
// Payment/Subscription Types
// ============================================

export enum SubscriptionPlan {
  FREE = 'FREE',
  STARTER = 'STARTER',
  PROFESSIONAL = 'PROFESSIONAL',
  ENTERPRISE = 'ENTERPRISE',
}

export enum SubscriptionStatus {
  ACTIVE = 'ACTIVE',
  PAST_DUE = 'PAST_DUE',
  CANCELLED = 'CANCELLED',
  EXPIRED = 'EXPIRED',
}

export interface Subscription {
  id: string;
  userId: string;
  plan: SubscriptionPlan;
  planName?: string;
  amount?: number;
  status: SubscriptionStatus;
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  credits: {
    email: number;
    sms: number;
    ai: number;
  };
  features: string[];
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

export interface Invoice {
  id: string;
  subscriptionId: string;
  amount: number;
  currency: string;
  status: 'draft' | 'open' | 'paid' | 'void' | 'uncollectible';
  stripeInvoiceId?: string;
  invoiceUrl?: string;
  paidAt?: string;
  dueDate?: string;
  tenantId: string;
  createdAt: string;
}

// ============================================
// Analytics/Reporting Types
// ============================================

export interface DashboardMetrics {
  totalCustomers: number;
  activeCustomers: number;
  totalCampaigns: number;
  activeCampaigns: number;
  emailsSent: number;
  smsSent: number;
  avgOpenRate?: number;
  avgClickRate?: number;
  openRate: number;
  clickRate: number;
  revenue: number;
  totalRevenue?: number;
  avgEngagementRate?: number;
  activeSubscriptions?: number;
  churnRate?: number;
  conversationCount: number;
  averageResponseTime: number;
}

export interface AnalyticsMetrics extends DashboardMetrics {
  // Additional analytics-specific metrics
}

export interface ExportReportResponse {
  downloadUrl: string;
  fileName: string;
  format: string;
  reportType: string;
  expiresIn: number;
}

export interface CampaignPerformance {
  id: string;
  name: string;
  type: CampaignType;
  sent: number;
  delivered: number;
  opened: number;
  clicked: number;
  openRate: number;
  clickRate: number;
  revenue?: number;
}

export interface ChartData {
  label: string;
  value: number;
  date?: string;
}

export interface Report {
  id: string;
  name: string;
  type: 'campaign' | 'customer' | 'revenue' | 'engagement';
  format: 'pdf' | 'csv' | 'xlsx';
  filters: Record<string, any>;
  generatedAt: string;
  url: string;
  tenantId: string;
}

// ============================================
// Integration Types
// ============================================

export enum IntegrationType {
  SHOPIFY = 'SHOPIFY',
  WOOCOMMERCE = 'WOOCOMMERCE',
  CUSTOM = 'CUSTOM',
}

export interface Integration {
  id: string;
  type: IntegrationType;
  name: string;
  config: Record<string, any>;
  isActive: boolean;
  lastSyncAt?: string;
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

// ============================================
// AI Types
// ============================================

export enum AIProvider {
  OPENAI = 'OPENAI',
  BEDROCK = 'BEDROCK',
  LEX = 'LEX',
}

export interface AIGenerationRequest {
  prompt: string;
  type: 'email' | 'sms' | 'subject' | 'general';
  context?: Record<string, any>;
  maxTokens?: number;
}

export interface AIGenerationResponse {
  content: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  cost: number;
}

// ============================================
// API Response Types
// ============================================

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface PaginationParams {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  [key: string]: any; // Allow additional filter parameters
}

// ============================================
// API Key Types
// ============================================

export interface APIKey {
  id: string;
  name: string;
  key?: string;
  status: 'ACTIVE' | 'REVOKED';
  permissions?: string[];
  lastUsed?: string;
  createdAt: string;
  tenantId: string;
}

// ============================================
// Form Types
// ============================================

export interface CampaignFormData {
  name: string;
  type: CampaignType;
  subject?: string;
  content: string;
  htmlContent?: string;
  segments: string[];
  scheduledAt?: string;
}

export interface CustomerFormData {
  email: string;
  phoneNumber?: string;
  firstName?: string;
  lastName?: string;
  company?: string;
  tags?: string[];
  customFields?: Record<string, any>;
}
