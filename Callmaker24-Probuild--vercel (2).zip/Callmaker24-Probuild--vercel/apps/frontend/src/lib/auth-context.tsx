'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { Amplify } from 'aws-amplify';
import {
  signIn,
  signOut,
  signUp,
  getCurrentUser,
  fetchAuthSession,
  fetchUserAttributes
} from 'aws-amplify/auth';
import type { User, AuthSession } from '@/types';

// Configure Amplify
if (typeof window !== 'undefined') {
  Amplify.configure({
    Auth: {
      Cognito: {
        userPoolId: process.env.NEXT_PUBLIC_COGNITO_USER_POOL_ID || '',
        userPoolClientId: process.env.NEXT_PUBLIC_COGNITO_CLIENT_ID || '',
      },
    },
  });
}

interface AuthContextType {
  user: User | null;
  session: AuthSession | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (data: SignupData) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  updateUser: (data: Partial<User>) => void;
}

interface SignupData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<AuthSession | null>(null);
  const [loading, setLoading] = useState(true);

  // Initialize auth state
  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      await getCurrentUser();
      const session = await fetchAuthSession();

      const accessToken = session.tokens?.accessToken?.toString() || '';
      const idToken = session.tokens?.idToken?.toString() || '';

      // Store tokens
      localStorage.setItem('accessToken', accessToken);
      localStorage.setItem('idToken', idToken);

      // Fetch user data from API
      await refreshUser();
    } catch (error) {
      console.log('Not authenticated', error);
      setUser(null);
      setSession(null);
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    try {
      const { nextStep } = await signIn({
        username: email,
        password: password,
      });

      // Handle MFA if enabled
      if (nextStep.signInStep === 'CONFIRM_SIGN_IN_WITH_TOTP_CODE') {
        throw new Error('MFA_REQUIRED');
      }

      const session = await fetchAuthSession();
      const accessToken = session.tokens?.accessToken?.toString() || '';
      const idToken = session.tokens?.idToken?.toString() || '';

      localStorage.setItem('accessToken', accessToken);
      localStorage.setItem('idToken', idToken);

      // Fetch user data
      await refreshUser();
    } catch (error: any) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const signup = async (data: SignupData) => {
    try {
      await signUp({
        username: data.email,
        password: data.password,
        options: {
          userAttributes: {
            email: data.email,
            given_name: data.firstName,
            family_name: data.lastName,
          },
        },
      });

      // Automatically log in after signup
      // Note: In production, you might want to verify email first
      // await login(data.email, data.password);
    } catch (error: any) {
      console.error('Signup error:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await signOut();
      localStorage.removeItem('accessToken');
      localStorage.removeItem('idToken');
      localStorage.removeItem('tenantId');
      setUser(null);
      setSession(null);
    } catch (error) {
      console.error('Logout error:', error);
      throw error;
    }
  };

  const refreshUser = async () => {
    try {
      // In a real implementation, fetch user data from your API
      // const response = await apiClient.get('/auth/me');

      // For now, create a mock user from Cognito data
      const currentUser = await getCurrentUser();
      const attributes = await fetchUserAttributes();

      const mockUser: User = {
        id: currentUser.userId,
        email: attributes.email || '',
        firstName: attributes.given_name || '',
        lastName: attributes.family_name || '',
        role: 'ADMIN' as any, // In production, fetch from your database
        permissions: [],
        tenantId: 'default',
        mfaEnabled: false,
        emailVerified: attributes.email_verified === 'true',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      setUser(mockUser);

      const session = await fetchAuthSession();
      const mockSession: AuthSession = {
        user: mockUser,
        accessToken: session.tokens?.accessToken?.toString() || '',
        refreshToken: session.tokens?.idToken?.toString() || '',
        expiresAt: (session.tokens?.accessToken?.payload.exp as number || 0) * 1000,
      };

      setSession(mockSession);

      // Store tenant ID
      localStorage.setItem('tenantId', mockUser.tenantId);
    } catch (error) {
      console.error('Error refreshing user:', error);
      throw error;
    }
  };

  const updateUser = (data: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...data });
    }
  };

  const value = {
    user,
    session,
    loading,
    login,
    signup,
    logout,
    refreshUser,
    updateUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

// Protected route HOC
export function withAuth<P extends object>(
  Component: React.ComponentType<P>,
  requiredRole?: string
) {
  return function AuthenticatedComponent(props: P) {
    const { user, loading } = useAuth();
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
      setMounted(true);
    }, []);

    if (!mounted || loading) {
      return (
        <div className="flex h-screen items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary-600 border-t-transparent" />
        </div>
      );
    }

    if (!user) {
      if (typeof window !== 'undefined') {
        window.location.href = '/login';
      }
      return null;
    }

    if (requiredRole && user.role !== requiredRole) {
      return (
        <div className="flex h-screen items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Access Denied</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">
              You don't have permission to access this page.
            </p>
          </div>
        </div>
      );
    }

    return <Component {...props} />;
  };
}
