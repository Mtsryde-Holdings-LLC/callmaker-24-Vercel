/**
 * API Client for communicating with the backend
 */

import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import type { ApiResponse, PaginationParams } from '@/types';

class ApiClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000/api',
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Request interceptor
    this.client.interceptors.request.use(
      (config) => {
        // Add auth token
        const token = this.getToken();
        console.log('API Client - Token from localStorage:', token ? 'Present' : 'Missing');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
          console.log('API Client - Authorization header set');
        }

        // Add tenant ID
        const tenantId = this.getTenantId();
        console.log('API Client - Tenant ID:', tenantId);
        if (tenantId) {
          config.headers['X-Tenant-ID'] = tenantId;
        }

        console.log('API Client - Final headers:', config.headers);
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor
    this.client.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;

        // Handle 401 errors (unauthorized)
        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true;

          try {
            const newToken = await this.refreshToken();
            if (newToken) {
              originalRequest.headers.Authorization = `Bearer ${newToken}`;
              return this.client(originalRequest);
            }
          } catch (refreshError) {
            // Redirect to login
            if (typeof window !== 'undefined') {
              window.location.href = '/login';
            }
            return Promise.reject(refreshError);
          }
        }

        return Promise.reject(error);
      }
    );
  }

  private getToken(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem('idToken');
  }

  private getTenantId(): string | null {
    if (typeof window === 'undefined') return 'default';
    return localStorage.getItem('tenantId') || 'default';
  }

  private async refreshToken(): Promise<string | null> {
    const refreshToken = localStorage.getItem('refreshToken');
    if (!refreshToken) return null;

    try {
      const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/auth/refresh`, {
        refreshToken,
      });

      const { accessToken } = response.data.data;
      localStorage.setItem('accessToken', accessToken);
      return accessToken;
    } catch (error) {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      return null;
    }
  }

  // Generic request method
  async request<T>(config: AxiosRequestConfig): Promise<ApiResponse<T>> {
    try {
      const response: AxiosResponse<ApiResponse<T>> = await this.client.request(config);
      return response.data;
    } catch (error: any) {
      if (error.response?.data) {
        return error.response.data;
      }

      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error.message || 'An unexpected error occurred',
        },
      };
    }
  }

  // GET request
  async get<T>(url: string, params?: any): Promise<ApiResponse<T>> {
    return this.request<T>({ method: 'GET', url, params });
  }

  // POST request
  async post<T>(url: string, data?: any): Promise<ApiResponse<T>> {
    return this.request<T>({ method: 'POST', url, data });
  }

  // PUT request
  async put<T>(url: string, data?: any): Promise<ApiResponse<T>> {
    return this.request<T>({ method: 'PUT', url, data });
  }

  // PATCH request
  async patch<T>(url: string, data?: any): Promise<ApiResponse<T>> {
    return this.request<T>({ method: 'PATCH', url, data });
  }

  // DELETE request
  async delete<T>(url: string): Promise<ApiResponse<T>> {
    return this.request<T>({ method: 'DELETE', url });
  }

  // File upload
  async upload<T>(url: string, file: File, onProgress?: (progress: number) => void): Promise<ApiResponse<T>> {
    const formData = new FormData();
    formData.append('file', file);

    return this.request<T>({
      method: 'POST',
      url,
      data: formData,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: (progressEvent) => {
        if (onProgress && progressEvent.total) {
          const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          onProgress(progress);
        }
      },
    });
  }
}

// Create singleton instance
const apiClient = new ApiClient();

export default apiClient;

// ============================================
// API Service Functions
// ============================================

// Authentication
export const authApi = {
  login: (email: string, password: string) =>
    apiClient.post('/auth/login', { email, password }),

  signup: (data: { email: string; password: string; firstName: string; lastName: string }) =>
    apiClient.post('/auth/signup', data),

  logout: () => apiClient.post('/auth/logout'),

  verifyEmail: (token: string) => apiClient.post('/auth/verify-email', { token }),

  forgotPassword: (email: string) => apiClient.post('/auth/forgot-password', { email }),

  resetPassword: (token: string, password: string) =>
    apiClient.post('/auth/reset-password', { token, password }),

  enableMFA: () => apiClient.post('/auth/mfa/enable'),

  verifyMFA: (code: string) => apiClient.post('/auth/mfa/verify', { code }),
};

// Customers
export const customersApi = {
  list: (params?: PaginationParams & { search?: string; status?: string }) =>
    apiClient.get('/customers', params),

  get: (id: string) => apiClient.get(`/customers/${id}`),

  create: (data: any) => apiClient.post('/customers', data),

  update: (id: string, data: any) => apiClient.put(`/customers/${id}`, data),

  delete: (id: string) => apiClient.delete(`/customers/${id}`),

  bulkImport: (file: File, onProgress?: (progress: number) => void) =>
    apiClient.upload('/customers/bulk-import', file, onProgress),

  export: (params?: any) => apiClient.post('/customers/export', params),
};

// Campaigns
export const campaignsApi = {
  list: (params?: PaginationParams & { type?: string; status?: string }) =>
    apiClient.get('/campaigns', params),

  get: (id: string) => apiClient.get(`/campaigns/${id}`),

  create: (data: any) => apiClient.post('/campaigns', data),

  update: (id: string, data: any) => apiClient.put(`/campaigns/${id}`, data),

  delete: (id: string) => apiClient.delete(`/campaigns/${id}`),

  send: (id: string) => apiClient.post(`/campaigns/${id}/send`),

  schedule: (id: string, scheduledAt: string) =>
    apiClient.post(`/campaigns/${id}/schedule`, { scheduledAt }),

  pause: (id: string) => apiClient.post(`/campaigns/${id}/pause`),

  resume: (id: string) => apiClient.post(`/campaigns/${id}/resume`),

  analytics: (id: string) => apiClient.get(`/campaigns/${id}/analytics`),

  sendTest: (id: string, emails: string[]) =>
    apiClient.post(`/campaigns/${id}/test`, { emails }),
};

// Segments
export const segmentsApi = {
  list: (params?: PaginationParams) => apiClient.get('/segments', params),

  get: (id: string) => apiClient.get(`/segments/${id}`),

  create: (data: any) => apiClient.post('/segments', data),

  update: (id: string, data: any) => apiClient.put(`/segments/${id}`, data),

  delete: (id: string) => apiClient.delete(`/segments/${id}`),

  preview: (filters: any) => apiClient.post('/segments/preview', { filters }),
};

// Conversations
export const conversationsApi = {
  list: (params?: PaginationParams & { status?: string }) =>
    apiClient.get('/conversations', params),

  get: (id: string) => apiClient.get(`/conversations/${id}`),

  sendMessage: (id: string, content: string) =>
    apiClient.post(`/conversations/${id}/messages`, { content }),

  assign: (id: string, agentId: string) =>
    apiClient.post(`/conversations/${id}/assign`, { agentId }),

  resolve: (id: string) => apiClient.post(`/conversations/${id}/resolve`),

  close: (id: string) => apiClient.post(`/conversations/${id}/close`),
};

// AI
export const aiApi = {
  generate: (data: { prompt: string; type: string; context?: any }) =>
    apiClient.post('/ai/generate', data),

  chat: (conversationId: string, message: string) =>
    apiClient.post('/ai/chat', { conversationId, message }),
};

// Calls
export const callsApi = {
  list: (params?: PaginationParams) => apiClient.get('/calls', params),

  get: (id: string) => apiClient.get(`/calls/${id}`),

  initiate: (data: { toNumber: string; customerId?: string }) =>
    apiClient.post('/calls/initiate', data),
};

// Subscriptions
export const subscriptionsApi = {
  get: () => apiClient.get('/subscription'),

  upgrade: (plan: string) => apiClient.post('/subscription/upgrade', { plan }),

  cancel: () => apiClient.post('/subscription/cancel'),

  updatePayment: (paymentMethodId: string) =>
    apiClient.post('/subscription/payment-method', { paymentMethodId }),
};

// Billing
export const billingApi = {
  get: () => apiClient.get('/billing/subscription'),

  upgrade: (plan: string) => apiClient.post('/billing/upgrade', { plan }),

  cancel: () => apiClient.post('/billing/cancel'),

  reactivate: () => apiClient.post('/billing/reactivate'),

  updatePayment: (paymentMethodId: string) =>
    apiClient.post('/billing/payment-method', { paymentMethodId }),

  getInvoices: () => apiClient.get('/billing/invoices'),

  downloadInvoice: (invoiceId: string) =>
    apiClient.get(`/billing/invoices/${invoiceId}/download`),
};

// Messages
export const messagesApi = {
  list: (params?: PaginationParams) => apiClient.get('/messages', params),

  get: (id: string) => apiClient.get(`/messages/${id}`),

  send: (data: any) => apiClient.post('/messages', data),

  delete: (id: string) => apiClient.delete(`/messages/${id}`),
};

// Settings
export const settingsApi = {
  get: () => apiClient.get('/settings'),

  update: (data: any) => apiClient.put('/settings', data),

  updateProfile: (data: any) => apiClient.put('/settings/profile', data),

  updateNotifications: (data: any) => apiClient.put('/settings/notifications', data),
};

// Team
export const teamApi = {
  list: (params?: PaginationParams) => apiClient.get('/team', params),

  get: (id: string) => apiClient.get(`/team/${id}`),

  invite: (data: { email: string; role: string }) =>
    apiClient.post('/team/invite', data),

  remove: (id: string) => apiClient.delete(`/team/${id}`),

  updateRole: (id: string, role: string) =>
    apiClient.put(`/team/${id}/role`, { role }),
};

// API Keys
export const apiKeysApi = {
  list: () => apiClient.get('/api-keys'),

  create: (data: { name: string; permissions?: string[] }) =>
    apiClient.post('/api-keys', data),

  delete: (id: string) => apiClient.delete(`/api-keys/${id}`),

  revoke: (id: string) => apiClient.post(`/api-keys/${id}/revoke`),

  rotate: (id: string) => apiClient.post(`/api-keys/${id}/rotate`),
};

// Analytics
export const analyticsApi = {
  dashboard: (params?: { startDate?: string; endDate?: string }) =>
    apiClient.get('/analytics/dashboard', params),

  getDashboardMetrics: (params?: { timeRange?: string }) =>
    apiClient.get('/analytics/dashboard/metrics', params),

  getCampaignPerformance: (params?: any) =>
    apiClient.get('/analytics/campaigns/performance', params),

  campaigns: (params?: any) => apiClient.get('/analytics/campaigns', params),

  customers: (params?: any) => apiClient.get('/analytics/customers', params),

  generateReport: (data: { type: string; filters: any; format: string }) =>
    apiClient.post('/analytics/reports', data),

  getReport: (id: string) => apiClient.get(`/analytics/reports/${id}`),

  exportReport: (data: { timeRange: string; format: string; reportType: string }) =>
    apiClient.post('/analytics/export', data),
};

// Integrations
export const integrationsApi = {
  list: () => apiClient.get('/integrations'),

  get: (id: string) => apiClient.get(`/integrations/${id}`),

  create: (data: any) => apiClient.post('/integrations', data),

  update: (id: string, data: any) => apiClient.put(`/integrations/${id}`, data),

  delete: (id: string) => apiClient.delete(`/integrations/${id}`),

  connect: (type: string, data: any) =>
    apiClient.post(`/integrations/connect`, { type, ...data }),

  disconnect: (id: string) => apiClient.post(`/integrations/${id}/disconnect`),

  sync: (id: string) => apiClient.post(`/integrations/${id}/sync`),
};

// Users
export const usersApi = {
  list: (params?: PaginationParams) => apiClient.get('/users', params),

  get: (id: string) => apiClient.get(`/users/${id}`),

  create: (data: any) => apiClient.post('/users', data),

  update: (id: string, data: any) => apiClient.put(`/users/${id}`, data),

  delete: (id: string) => apiClient.delete(`/users/${id}`),

  updatePermissions: (id: string, permissions: string[]) =>
    apiClient.put(`/users/${id}/permissions`, { permissions }),
};
