import axios from 'axios';

// Configure base URL for API calls
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || '/api';

export interface GenerateContentParams {
  topic: string;
  businessType: string;
  targetAudience: string;
  platform: 'twitter' | 'facebook' | 'instagram' | 'linkedin' | 'tiktok';
  tone?: 'professional' | 'casual' | 'friendly' | 'informative' | 'humorous';
  contentType?: 'post' | 'story' | 'tweet' | 'article' | 'caption';
  maxLength?: number;
  includeHashtags?: boolean;
  includeEmojis?: boolean;
  includeCallToAction?: boolean;
  brandVoice?: string;
  keywords?: string[];
  generateVariations?: boolean;
  variationCount?: number;
}

export interface GeneratedContent {
  mainContent: string;
  variations?: Array<{
    content: string;
    hashtags: string[];
    estimatedReach?: string;
    sentiment?: 'positive' | 'neutral' | 'negative';
  }>;
  hashtags: string[];
  suggestedImages?: string[];
  bestTimeToPost?: string;
  estimatedEngagement?: string;
}

export interface SchedulePostParams {
  businessId: string;
  platform: string;
  content: string;
  scheduledAt: string;
  mediaUrls?: string[];
  hashtags?: string[];
}

export interface PublishPostParams {
  businessId: string;
  platforms: string[];
  content: string;
  mediaUrl?: string;
  link?: string;
}

export interface AnalyzeWebsiteParams {
  url: string;
  analyzeBrand?: boolean;
}

/**
 * Social Content API Client
 */
export const socialContentApi = {
  /**
   * Generate AI-powered content
   */
  async generateContent(params: GenerateContentParams): Promise<GeneratedContent> {
    try {
      const response = await axios.post(`${API_BASE_URL}/generate-content`, params);
      return response.data.data;
    } catch (error: any) {
      console.error('Error generating content:', error);
      throw new Error(error.response?.data?.error || 'Failed to generate content');
    }
  },

  /**
   * Generate hashtags for content
   */
  async generateHashtags(content: string, platform: string, count: number = 10): Promise<string[]> {
    try {
      const response = await axios.post(`${API_BASE_URL}/generate-hashtags`, {
        content,
        platform,
        count,
      });
      return response.data.data.hashtags;
    } catch (error: any) {
      console.error('Error generating hashtags:', error);
      throw new Error(error.response?.data?.error || 'Failed to generate hashtags');
    }
  },

  /**
   * Generate image prompt
   */
  async generateImagePrompt(content: string): Promise<string> {
    try {
      const response = await axios.post(`${API_BASE_URL}/generate-image-prompt`, {
        content,
      });
      return response.data.data.imagePrompt;
    } catch (error: any) {
      console.error('Error generating image prompt:', error);
      throw new Error(error.response?.data?.error || 'Failed to generate image prompt');
    }
  },

  /**
   * Analyze website for brand voice
   */
  async analyzeWebsite(params: AnalyzeWebsiteParams): Promise<{
    websiteData: any;
    brandAnalysis?: any;
  }> {
    try {
      const response = await axios.post(`${API_BASE_URL}/analyze-website`, params);
      return response.data.data;
    } catch (error: any) {
      console.error('Error analyzing website:', error);
      throw new Error(error.response?.data?.error || 'Failed to analyze website');
    }
  },

  /**
   * Parse RSS feed
   */
  async parseRSS(feedUrl: string): Promise<any[]> {
    try {
      const response = await axios.post(`${API_BASE_URL}/parse-rss`, {
        feedUrl,
      });
      return response.data.data.items;
    } catch (error: any) {
      console.error('Error parsing RSS feed:', error);
      throw new Error(error.response?.data?.error || 'Failed to parse RSS feed');
    }
  },

  /**
   * Schedule a post
   */
  async schedulePost(params: SchedulePostParams): Promise<any> {
    try {
      const response = await axios.post(`${API_BASE_URL}/schedule-post`, params);
      return response.data.data;
    } catch (error: any) {
      console.error('Error scheduling post:', error);
      throw new Error(error.response?.data?.error || 'Failed to schedule post');
    }
  },

  /**
   * Get scheduled posts
   */
  async getScheduledPosts(businessId: string): Promise<any[]> {
    try {
      const response = await axios.get(`${API_BASE_URL}/scheduled-posts`, {
        params: { businessId },
      });
      return response.data.data;
    } catch (error: any) {
      console.error('Error getting scheduled posts:', error);
      throw new Error(error.response?.data?.error || 'Failed to get scheduled posts');
    }
  },

  /**
   * Delete scheduled post
   */
  async deleteScheduledPost(postId: string): Promise<void> {
    try {
      await axios.delete(`${API_BASE_URL}/schedule-post/${postId}`);
    } catch (error: any) {
      console.error('Error deleting scheduled post:', error);
      throw new Error(error.response?.data?.error || 'Failed to delete scheduled post');
    }
  },

  /**
   * Publish post immediately
   */
  async publishPost(params: PublishPostParams): Promise<any> {
    try {
      const response = await axios.post(`${API_BASE_URL}/publish-post`, params);
      return response.data.data;
    } catch (error: any) {
      console.error('Error publishing post:', error);
      throw new Error(error.response?.data?.error || 'Failed to publish post');
    }
  },

  /**
   * Analyze content performance
   */
  async analyzePerformance(posts: any[]): Promise<any> {
    try {
      const response = await axios.post(`${API_BASE_URL}/analyze-performance`, {
        posts,
      });
      return response.data.data;
    } catch (error: any) {
      console.error('Error analyzing performance:', error);
      throw new Error(error.response?.data?.error || 'Failed to analyze performance');
    }
  },
};

export default socialContentApi;
