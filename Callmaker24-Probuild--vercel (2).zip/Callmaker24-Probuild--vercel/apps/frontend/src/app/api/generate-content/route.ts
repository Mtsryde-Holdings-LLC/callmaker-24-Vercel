import { NextRequest, NextResponse } from 'next/server';

/**
 * POST /api/generate-content
 * Generate AI-powered social media content
 *
 * NOTE: This is a Next.js API route that proxies to the Lambda function
 * In production, configure OPENAI_API_KEY in environment variables
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const {
      topic,
      businessType,
      targetAudience,
      platform,
      tone = 'professional',
      includeHashtags = true,
      includeEmojis = true,
      generateVariations = false,
    } = body;

    // Validate required fields
    if (!topic || !businessType || !targetAudience || !platform) {
      return NextResponse.json(
        {
          success: false,
          error: 'Missing required fields: topic, businessType, targetAudience, platform',
        },
        { status: 400 }
      );
    }

    // TODO: Replace with actual OpenAI API call
    // For now, return mock data for testing
    const mockContent = {
      mainContent: generateMockContent(topic, platform, tone, includeEmojis),
      hashtags: includeHashtags
        ? generateMockHashtags(topic, platform)
        : [],
      suggestedImages: [
        'Professional workspace with laptop and coffee',
        'Team collaboration in modern office',
        'Product showcase with clean background',
      ],
      bestTimeToPost: getBestPostingTime(platform),
      estimatedEngagement: 'Medium-High (3-5% engagement rate)',
    };

    if (generateVariations) {
      const variations = [
        {
          content: generateMockContent(topic, platform, 'casual', includeEmojis),
          hashtags: generateMockHashtags(topic, platform).slice(0, 3),
          sentiment: 'positive' as const,
        },
        {
          content: generateMockContent(topic, platform, 'friendly', includeEmojis),
          hashtags: generateMockHashtags(topic, platform).slice(2, 5),
          sentiment: 'positive' as const,
        },
        {
          content: generateMockContent(topic, platform, 'informative', includeEmojis),
          hashtags: generateMockHashtags(topic, platform).slice(1, 4),
          sentiment: 'neutral' as const,
        },
      ];

      return NextResponse.json({
        success: true,
        data: { variations },
      });
    }

    return NextResponse.json({
      success: true,
      data: mockContent,
    });
  } catch (error: any) {
    console.error('Error generating content:', error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || 'Failed to generate content',
      },
      { status: 500 }
    );
  }
}

// Helper functions for mock data
function generateMockContent(
  topic: string,
  platform: string,
  tone: string,
  includeEmojis: boolean
): string {
  const emojis = includeEmojis ? ['🚀', '✨', '💡', '🎉', '👏', '🔥'] : [];
  const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)] || '';

  const templates = {
    professional: `Exciting news about ${topic}! ${randomEmoji}\n\nWe're thrilled to share this development with our community. This represents a significant step forward in our commitment to excellence.\n\nLearn more and join the conversation.`,
    casual: `Hey everyone! ${randomEmoji} Big news about ${topic}!\n\nWe've been working on something special and can't wait to share it with you. This is going to be game-changing!\n\nCheck it out and let us know what you think!`,
    friendly: `Hi friends! ${randomEmoji}\n\nWe have some amazing news about ${topic} to share with you today! We've put our hearts into this and we think you're going to love it.\n\nTake a look and share your thoughts!`,
    informative: `Update: ${topic} ${randomEmoji}\n\nHere's what you need to know:\n• Key feature updates\n• Enhanced performance\n• Improved user experience\n\nFull details available now.`,
    humorous: `Plot twist: ${topic} just got a whole lot more interesting! ${randomEmoji}\n\nWe promise this isn't clickbait (okay, maybe a little). But seriously, you'll want to see this.\n\nPrepare to be amazed!`,
  };

  let content = templates[tone as keyof typeof templates] || templates.professional;

  // Platform-specific adjustments
  if (platform === 'twitter') {
    content = content.substring(0, 250) + '...'; // Shorten for Twitter
  }

  return content;
}

function generateMockHashtags(topic: string, platform: string): string[] {
  const topicWords = topic.toLowerCase().split(' ');
  const baseHashtags = [
    '#Innovation',
    '#Business',
    '#Technology',
    '#Growth',
    '#Success',
    '#Marketing',
    '#Digital',
    '#Trending',
  ];

  // Generate topic-specific hashtags
  const topicHashtags = topicWords
    .map((word) => `#${word.charAt(0).toUpperCase() + word.slice(1)}`)
    .filter((tag) => tag.length > 2);

  // Platform-specific popular hashtags
  const platformHashtags: { [key: string]: string[] } = {
    instagram: ['#InstaGood', '#PhotoOfTheDay', '#Inspo'],
    linkedin: ['#Leadership', '#Professional', '#BusinessGrowth'],
    twitter: ['#Tech', '#News', '#Breaking'],
    facebook: ['#Community', '#Family', '#Friends'],
    tiktok: ['#FYP', '#Viral', '#Trending'],
  };

  return [
    ...topicHashtags.slice(0, 2),
    ...baseHashtags.slice(0, 3),
    ...(platformHashtags[platform] || []).slice(0, 2),
  ].slice(0, 7);
}

function getBestPostingTime(platform: string): string {
  const times: { [key: string]: string } = {
    twitter: 'Tuesday-Thursday, 9 AM - 12 PM EST',
    linkedin: 'Tuesday-Wednesday, 10 AM - 12 PM EST',
    facebook: 'Wednesday-Friday, 1 PM - 3 PM EST',
    instagram: 'Monday-Friday, 11 AM - 1 PM EST',
    tiktok: 'Tuesday-Thursday, 6 PM - 10 PM EST',
  };

  return times[platform] || 'Tuesday-Thursday, 10 AM - 2 PM EST';
}
