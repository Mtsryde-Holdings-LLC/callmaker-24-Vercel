import { NextRequest, NextResponse } from 'next/server';

/**
 * POST /api/schedule-post
 * Schedule a social media post
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { businessId, platform, content, scheduledAt, mediaUrls, hashtags } = body;

    if (!businessId || !platform || !content || !scheduledAt) {
      return NextResponse.json(
        {
          success: false,
          error: 'Missing required fields: businessId, platform, content, scheduledAt',
        },
        { status: 400 }
      );
    }

    const scheduledTime = new Date(scheduledAt);
    const now = new Date();

    if (scheduledTime <= now) {
      return NextResponse.json(
        {
          success: false,
          error: 'Scheduled time must be in the future',
        },
        { status: 400 }
      );
    }

    // TODO: Save to database
    // For now, return mock success response
    const mockPostId = `post_${Date.now()}`;

    return NextResponse.json({
      success: true,
      data: {
        id: mockPostId,
        message: 'Post scheduled successfully',
        scheduledAt,
        platform,
        content,
        mediaUrls,
        hashtags,
      },
    });
  } catch (error: any) {
    console.error('Error scheduling post:', error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || 'Failed to schedule post',
      },
      { status: 500 }
    );
  }
}
