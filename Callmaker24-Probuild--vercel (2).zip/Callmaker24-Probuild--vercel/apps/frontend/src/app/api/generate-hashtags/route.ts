import { NextRequest, NextResponse } from 'next/server';

/**
 * POST /api/generate-hashtags
 * Generate relevant hashtags for content
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { content, platform, count = 10 } = body;

    if (!content || !platform) {
      return NextResponse.json(
        {
          success: false,
          error: 'Missing required fields: content, platform',
        },
        { status: 400 }
      );
    }

    // Extract keywords from content
    const words: string[] = content.toLowerCase().match(/\b[a-z]{4,}\b/g) || [];
    const uniqueWords: string[] = [...new Set<string>(words)];

    // Generate hashtags
    const hashtags = uniqueWords
      .slice(0, count / 2)
      .map((word) => `#${word.charAt(0).toUpperCase() + word.slice(1)}`)
      .concat([
        '#Marketing',
        '#Business',
        '#Growth',
        '#Innovation',
        '#Success',
        '#Digital',
        '#Social',
        '#Content',
      ])
      .slice(0, count);

    return NextResponse.json({
      success: true,
      data: { hashtags },
    });
  } catch (error: any) {
    console.error('Error generating hashtags:', error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || 'Failed to generate hashtags',
      },
      { status: 500 }
    );
  }
}
