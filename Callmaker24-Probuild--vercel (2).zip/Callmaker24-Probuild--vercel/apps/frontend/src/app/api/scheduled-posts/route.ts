import { NextRequest, NextResponse } from 'next/server';

/**
 * GET /api/scheduled-posts
 * Get scheduled posts for a business
 */
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const businessId = searchParams.get('businessId');

    if (!businessId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Missing required parameter: businessId',
        },
        { status: 400 }
      );
    }

    // TODO: Get from database
    // For now, return mock data
    const mockScheduledPosts = [
      {
        id: 'post_1',
        businessId,
        platform: 'TWITTER',
        content: 'Exciting product update coming next week! 🚀',
        scheduledAt: new Date(Date.now() + 86400000 * 2).toISOString(), // 2 days from now
        status: 'SCHEDULED',
        hashtags: ['#ProductUpdate', '#Tech', '#Innovation'],
        mediaUrls: [],
        createdAt: new Date().toISOString(),
      },
      {
        id: 'post_2',
        businessId,
        platform: 'LINKEDIN',
        content: 'Check out our latest blog post on industry trends...',
        scheduledAt: new Date(Date.now() + 86400000 * 5).toISOString(), // 5 days from now
        status: 'SCHEDULED',
        hashtags: ['#Business', '#Growth', '#Leadership'],
        mediaUrls: [],
        createdAt: new Date().toISOString(),
      },
    ];

    return NextResponse.json({
      success: true,
      data: mockScheduledPosts,
    });
  } catch (error: any) {
    console.error('Error getting scheduled posts:', error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || 'Failed to get scheduled posts',
      },
      { status: 500 }
    );
  }
}
