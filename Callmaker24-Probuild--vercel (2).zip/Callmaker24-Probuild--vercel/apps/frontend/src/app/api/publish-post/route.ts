import { NextRequest, NextResponse } from 'next/server';

/**
 * POST /api/publish-post
 * Publish a post immediately to social media platforms
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { businessId, platforms, content, mediaUrl, link } = body;

    if (!businessId || !platforms || !content) {
      return NextResponse.json(
        {
          success: false,
          error: 'Missing required fields: businessId, platforms, content',
        },
        { status: 400 }
      );
    }

    if (!Array.isArray(platforms) || platforms.length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'platforms must be a non-empty array',
        },
        { status: 400 }
      );
    }

    // TODO: Actually publish to social media platforms
    // For now, return mock success responses
    const results = platforms.map((platform) => ({
      platform,
      success: true,
      postId: `${platform}_${Date.now()}`,
      message: `Successfully posted to ${platform}`,
    }));

    return NextResponse.json({
      success: true,
      data: {
        results,
        content,
        mediaUrl,
        link,
        publishedAt: new Date().toISOString(),
      },
    });
  } catch (error: any) {
    console.error('Error publishing post:', error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || 'Failed to publish post',
      },
      { status: 500 }
    );
  }
}
