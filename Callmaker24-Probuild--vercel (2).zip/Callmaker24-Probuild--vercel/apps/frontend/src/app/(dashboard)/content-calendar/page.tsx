'use client';

import { useState } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths } from 'date-fns';
import { ChevronLeftIcon, ChevronRightIcon, PlusIcon } from '@heroicons/react/24/outline';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface ScheduledPost {
  id: string;
  platform: 'twitter' | 'facebook' | 'instagram' | 'linkedin';
  content: string;
  scheduledAt: Date;
  status: 'scheduled' | 'published' | 'failed';
}

const platformColors = {
  twitter: 'bg-blue-500',
  facebook: 'bg-blue-700',
  instagram: 'bg-pink-500',
  linkedin: 'bg-blue-600',
};

const platformIcons = {
  twitter: '𝕏',
  facebook: 'f',
  instagram: '📷',
  linkedin: 'in',
};

export default function ContentCalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [scheduledPosts, setScheduledPosts] = useState<ScheduledPost[]>([
    {
      id: '1',
      platform: 'twitter',
      content: 'Check out our latest product update! 🚀 #innovation',
      scheduledAt: new Date(2025, 10, 5, 10, 0),
      status: 'scheduled',
    },
    {
      id: '2',
      platform: 'linkedin',
      content: 'Excited to share our Q4 results...',
      scheduledAt: new Date(2025, 10, 5, 14, 0),
      status: 'scheduled',
    },
    {
      id: '3',
      platform: 'instagram',
      content: 'New product launch! 🎉',
      scheduledAt: new Date(2025, 10, 8, 12, 0),
      status: 'scheduled',
    },
  ]);

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const previousMonth = () => setCurrentDate(subMonths(currentDate, 1));
  const nextMonth = () => setCurrentDate(addMonths(currentDate, 1));

  const getPostsForDate = (date: Date) => {
    return scheduledPosts.filter((post) =>
      isSameDay(new Date(post.scheduledAt), date)
    );
  };

  const handleDragStart = (e: React.DragEvent, postId: string) => {
    e.dataTransfer.setData('postId', postId);
  };

  const handleDrop = (e: React.DragEvent, date: Date) => {
    e.preventDefault();
    const postId = e.dataTransfer.getData('postId');

    setScheduledPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const newDate = new Date(date);
          newDate.setHours(new Date(post.scheduledAt).getHours());
          newDate.setMinutes(new Date(post.scheduledAt).getMinutes());
          return { ...post, scheduledAt: newDate };
        }
        return post;
      })
    );
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Content Calendar</h1>
          <p className="mt-1 text-sm text-gray-600">
            Schedule and manage your social media posts
          </p>
        </div>
        <Button className="flex items-center gap-2">
          <PlusIcon className="h-5 w-5" />
          Schedule New Post
        </Button>
      </div>

      {/* Calendar Controls */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-900">
          {format(currentDate, 'MMMM yyyy')}
        </h2>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={previousMonth}>
            <ChevronLeftIcon className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => setCurrentDate(new Date())}>
            Today
          </Button>
          <Button variant="outline" size="sm" onClick={nextMonth}>
            <ChevronRightIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex gap-4">
        {Object.entries(platformColors).map(([platform, color]) => (
          <div key={platform} className="flex items-center gap-2">
            <div className={`h-3 w-3 rounded-full ${color}`}></div>
            <span className="text-sm capitalize text-gray-700">{platform}</span>
          </div>
        ))}
      </div>

      {/* Calendar Grid */}
      <Card className="p-4">
        {/* Day Headers */}
        <div className="mb-2 grid grid-cols-7 gap-px">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <div
              key={day}
              className="py-2 text-center text-sm font-medium text-gray-700"
            >
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        <div className="grid grid-cols-7 gap-px bg-gray-200">
          {/* Fill in days from previous month */}
          {Array.from({ length: monthStart.getDay() }).map((_, index) => (
            <div
              key={`empty-${index}`}
              className="min-h-[120px] bg-gray-50 p-2"
            />
          ))}

          {/* Days of current month */}
          {daysInMonth.map((date) => {
            const posts = getPostsForDate(date);
            const isToday = isSameDay(date, new Date());
            const isSelected = selectedDate && isSameDay(date, selectedDate);

            return (
              <div
                key={date.toString()}
                className={`min-h-[120px] bg-white p-2 transition-colors ${
                  isSelected ? 'ring-2 ring-blue-500' : ''
                } ${isToday ? 'bg-blue-50' : ''} hover:bg-gray-50`}
                onClick={() => setSelectedDate(date)}
                onDrop={(e) => handleDrop(e, date)}
                onDragOver={handleDragOver}
              >
                <div
                  className={`mb-1 text-sm ${
                    isToday
                      ? 'font-bold text-blue-600'
                      : isSameMonth(date, currentDate)
                      ? 'text-gray-900'
                      : 'text-gray-400'
                  }`}
                >
                  {format(date, 'd')}
                </div>

                {/* Posts for this day */}
                <div className="space-y-1">
                  {posts.map((post) => (
                    <div
                      key={post.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, post.id)}
                      className={`cursor-move rounded px-2 py-1 text-xs text-white ${
                        platformColors[post.platform]
                      } hover:opacity-80`}
                      title={post.content}
                    >
                      <div className="flex items-center gap-1">
                        <span>{platformIcons[post.platform]}</span>
                        <span className="truncate">
                          {format(new Date(post.scheduledAt), 'HH:mm')}
                        </span>
                      </div>
                      <div className="truncate">{post.content}</div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Selected Date Details */}
      {selectedDate && (
        <Card className="p-6">
          <h3 className="mb-4 text-lg font-semibold">
            {format(selectedDate, 'EEEE, MMMM d, yyyy')}
          </h3>

          {getPostsForDate(selectedDate).length === 0 ? (
            <p className="text-gray-600">No posts scheduled for this day</p>
          ) : (
            <div className="space-y-3">
              {getPostsForDate(selectedDate).map((post) => (
                <div
                  key={post.id}
                  className="rounded-lg border border-gray-200 p-4"
                >
                  <div className="mb-2 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div
                        className={`h-3 w-3 rounded-full ${
                          platformColors[post.platform]
                        }`}
                      ></div>
                      <span className="font-medium capitalize">
                        {post.platform}
                      </span>
                      <span className="text-sm text-gray-500">
                        {format(new Date(post.scheduledAt), 'h:mm a')}
                      </span>
                    </div>
                    <span
                      className={`rounded-full px-2 py-1 text-xs ${
                        post.status === 'scheduled'
                          ? 'bg-yellow-100 text-yellow-800'
                          : post.status === 'published'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {post.status}
                    </span>
                  </div>
                  <p className="text-gray-700">{post.content}</p>
                  <div className="mt-3 flex gap-2">
                    <Button variant="outline" size="sm">
                      Edit
                    </Button>
                    <Button variant="outline" size="sm">
                      Delete
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
