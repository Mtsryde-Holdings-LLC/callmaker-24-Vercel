'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select } from '@/components/ui/select';
import { Loading } from '@/components/ui/loading';
import { analyticsApi } from '@/lib/api-client';
import { formatNumber, formatPercentage, formatCurrency } from '@/lib/utils';
import type { AnalyticsMetrics, CampaignPerformance, ExportReportResponse } from '@/types';
import {
  ArrowDownTrayIcon,
  ChartBarIcon,
  UsersIcon,
  CurrencyDollarIcon,
  CheckCircleIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

type TimeRange = '7d' | '30d' | '90d' | '1y';

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState<TimeRange>('30d');
  const [exportLoading, setExportLoading] = useState(false);

  const { data: metricsData, isLoading: metricsLoading } = useQuery({
    queryKey: ['analytics', 'dashboard', timeRange],
    queryFn: () => analyticsApi.getDashboardMetrics({ timeRange }),
  });

  const { data: campaignData, isLoading: campaignLoading } = useQuery({
    queryKey: ['analytics', 'campaigns', timeRange],
    queryFn: () => analyticsApi.getCampaignPerformance({ timeRange }),
  });

  const metrics = (metricsData?.data as AnalyticsMetrics) || {
    totalCampaigns: 0,
    totalCustomers: 0,
    totalRevenue: 0,
    avgEngagementRate: 0,
    emailsSent: 0,
    smsSent: 0,
    avgOpenRate: 0,
    avgClickRate: 0,
    activeSubscriptions: 0,
    churnRate: 0,
    openRate: 0,
    clickRate: 0,
    revenue: 0,
    activeCustomers: 0,
    activeCampaigns: 0,
    conversationCount: 0,
    averageResponseTime: 0,
  };

  const campaignPerformance = (campaignData?.data as CampaignPerformance[]) || [];

  const handleExport = async (format: 'csv' | 'pdf') => {
    setExportLoading(true);
    try {
      const response = await analyticsApi.exportReport({
        timeRange,
        format,
        reportType: 'dashboard',
      });

      const exportData = response.data as ExportReportResponse;
      if (response.success && exportData?.downloadUrl) {
        window.open(exportData.downloadUrl, '_blank');
        toast.success(`Report exported as ${format.toUpperCase()}`);
      } else {
        toast.error('Export failed');
      }
    } catch (error) {
      toast.error('Failed to export report');
    } finally {
      setExportLoading(false);
    }
  };

  const timeRangeOptions = [
    { value: '7d', label: 'Last 7 Days' },
    { value: '30d', label: 'Last 30 Days' },
    { value: '90d', label: 'Last 90 Days' },
    { value: '1y', label: 'Last Year' },
  ];

  const isLoading = metricsLoading || campaignLoading;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Analytics</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">
              Track your marketing performance and customer engagement
            </p>
          </div>

          <div className="flex gap-3">
            <Select
              value={timeRange}
              onChange={(e) => setTimeRange((e.target as HTMLSelectElement).value as TimeRange)}
              options={timeRangeOptions}
              className="w-40"
            />
            <Button
              variant="outline"
              onClick={() => handleExport('csv')}
              loading={exportLoading}
            >
              <ArrowDownTrayIcon className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
            <Button variant="outline" onClick={() => handleExport('pdf')} loading={exportLoading}>
              <ArrowDownTrayIcon className="mr-2 h-4 w-4" />
              Export PDF
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex h-96 items-center justify-center">
            <Loading size="lg" />
          </div>
        ) : (
          <>
            {/* Overview Metrics */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
                        Total Campaigns
                      </div>
                      <div className="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
                        {formatNumber(metrics.totalCampaigns)}
                      </div>
                    </div>
                    <div className="rounded-full bg-blue-100 p-3 dark:bg-blue-900/20">
                      <ChartBarIcon className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
                        Total Customers
                      </div>
                      <div className="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
                        {formatNumber(metrics.totalCustomers)}
                      </div>
                    </div>
                    <div className="rounded-full bg-green-100 p-3 dark:bg-green-900/20">
                      <UsersIcon className="h-6 w-6 text-green-600 dark:text-green-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
                        Total Revenue
                      </div>
                      <div className="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
                        {formatCurrency(metrics.totalRevenue)}
                      </div>
                    </div>
                    <div className="rounded-full bg-purple-100 p-3 dark:bg-purple-900/20">
                      <CurrencyDollarIcon className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
                        Avg Engagement
                      </div>
                      <div className="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
                        {formatPercentage(metrics.avgEngagementRate)}
                      </div>
                    </div>
                    <div className="rounded-full bg-orange-100 p-3 dark:bg-orange-900/20">
                      <CheckCircleIcon className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Email & SMS Performance */}
            <div className="grid gap-4 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Email Performance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Emails Sent</span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      {formatNumber(metrics.emailsSent)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Avg Open Rate</span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      {formatPercentage(metrics.avgOpenRate)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      Avg Click Rate
                    </span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      {formatPercentage(metrics.avgClickRate)}
                    </span>
                  </div>
                  <div className="mt-4 rounded-lg bg-blue-50 p-4 dark:bg-blue-900/20">
                    <div className="text-sm font-medium text-blue-900 dark:text-blue-200">
                      Open Rate Trend
                    </div>
                    <div className="mt-2 h-24 rounded bg-blue-100 dark:bg-blue-900/40">
                      {/* Placeholder for chart - would use recharts or similar */}
                      <div className="flex h-full items-center justify-center text-sm text-blue-700 dark:text-blue-300">
                        Chart visualization
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>SMS Performance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">SMS Sent</span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      {formatNumber(metrics.smsSent)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Delivery Rate</span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      98.5%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Response Rate</span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      12.3%
                    </span>
                  </div>
                  <div className="mt-4 rounded-lg bg-green-50 p-4 dark:bg-green-900/20">
                    <div className="text-sm font-medium text-green-900 dark:text-green-200">
                      Delivery Trend
                    </div>
                    <div className="mt-2 h-24 rounded bg-green-100 dark:bg-green-900/40">
                      <div className="flex h-full items-center justify-center text-sm text-green-700 dark:text-green-300">
                        Chart visualization
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Campaign Performance Table */}
            <Card>
              <CardHeader>
                <CardTitle>Top Performing Campaigns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200 dark:border-gray-700">
                        <th className="pb-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">
                          Campaign
                        </th>
                        <th className="pb-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">
                          Type
                        </th>
                        <th className="pb-3 text-right text-sm font-medium text-gray-600 dark:text-gray-400">
                          Sent
                        </th>
                        <th className="pb-3 text-right text-sm font-medium text-gray-600 dark:text-gray-400">
                          Open Rate
                        </th>
                        <th className="pb-3 text-right text-sm font-medium text-gray-600 dark:text-gray-400">
                          Click Rate
                        </th>
                        <th className="pb-3 text-right text-sm font-medium text-gray-600 dark:text-gray-400">
                          Conversions
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {campaignPerformance.length > 0 ? (
                        campaignPerformance.slice(0, 10).map((campaign: any) => (
                          <tr
                            key={campaign.id}
                            className="border-b border-gray-100 dark:border-gray-800"
                          >
                            <td className="py-3 text-sm font-medium text-gray-900 dark:text-white">
                              {campaign.name}
                            </td>
                            <td className="py-3 text-sm text-gray-600 dark:text-gray-400">
                              {campaign.type}
                            </td>
                            <td className="py-3 text-right text-sm text-gray-900 dark:text-white">
                              {formatNumber(campaign.sent)}
                            </td>
                            <td className="py-3 text-right text-sm text-gray-900 dark:text-white">
                              {formatPercentage(campaign.openRate)}
                            </td>
                            <td className="py-3 text-right text-sm text-gray-900 dark:text-white">
                              {formatPercentage(campaign.clickRate)}
                            </td>
                            <td className="py-3 text-right text-sm text-gray-900 dark:text-white">
                              {formatNumber(campaign.conversions || 0)}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-gray-500">
                            No campaign data available for this period
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Subscription Metrics */}
            <div className="grid gap-4 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Subscription Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      Active Subscriptions
                    </span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      {formatNumber(metrics.activeSubscriptions)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Churn Rate</span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      {formatPercentage(metrics.churnRate)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">MRR</span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      {formatCurrency((metrics.totalRevenue ?? 0) / 12)}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Customer Engagement</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Email Opt-in</span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      87.2%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">SMS Opt-in</span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      64.8%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      Avg Lifetime Value
                    </span>
                    <span className="text-lg font-semibold text-gray-900 dark:text-white">
                      {formatCurrency(1240)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
