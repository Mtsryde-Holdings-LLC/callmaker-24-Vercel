'use client';

import { useQuery } from '@tanstack/react-query';
import {
  UsersIcon,
  EnvelopeIcon,
  ChatBubbleLeftRightIcon,
  CurrencyDollarIcon,
} from '@heroicons/react/24/outline';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { analyticsApi } from '@/lib/api-client';
import { Loading } from '@/components/ui/loading';
import { formatNumber, formatCurrency, formatPercentage } from '@/lib/utils';
import type { DashboardMetrics } from '@/types';

export default function DashboardPage() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ['dashboard-metrics'],
    queryFn: () => analyticsApi.dashboard(),
  });

  const dashboardData = metrics?.data as DashboardMetrics | undefined;

  const stats = [
    {
      name: 'Total Customers',
      value: dashboardData?.totalCustomers || 0,
      icon: UsersIcon,
      change: '+12%',
      changeType: 'positive',
    },
    {
      name: 'Campaigns Sent',
      value: dashboardData?.totalCampaigns || 0,
      icon: EnvelopeIcon,
      change: '+8%',
      changeType: 'positive',
    },
    {
      name: 'Open Rate',
      value: formatPercentage(dashboardData?.openRate || 0),
      icon: ChatBubbleLeftRightIcon,
      change: '+2.5%',
      changeType: 'positive',
    },
    {
      name: 'Revenue',
      value: formatCurrency(dashboardData?.revenue || 0),
      icon: CurrencyDollarIcon,
      change: '+15%',
      changeType: 'positive',
    },
  ];

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex h-96 items-center justify-center">
          <Loading size="lg" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Welcome back! Here's what's happening with your campaigns.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.name}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {stat.name}
                    </p>
                    <p className="mt-2 text-3xl font-bold text-gray-900 dark:text-white">
                      {typeof stat.value === 'number' ? formatNumber(stat.value) : stat.value}
                    </p>
                    <p className="mt-2 text-sm text-success-600">
                      <span className="font-medium">{stat.change}</span> from last month
                    </p>
                  </div>
                  <div className="rounded-full bg-primary-50 p-3 dark:bg-primary-900/50">
                    <stat.icon className="h-6 w-6 text-primary-600 dark:text-primary-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recent Activity & Charts */}
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Recent Campaigns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center justify-between border-b border-gray-200 pb-4 last:border-0 dark:border-gray-800">
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        Campaign #{i}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Sent to {formatNumber(1000 * i)} customers
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-success-600">
                        {formatPercentage(20 + i * 5)} open rate
                      </p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">
                        2 hours ago
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Top Performing Segments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {['VIP Customers', 'Newsletter Subscribers', 'Trial Users'].map((segment, i) => (
                  <div key={segment} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium text-gray-900 dark:text-white">{segment}</span>
                      <span className="text-gray-600 dark:text-gray-400">
                        {formatPercentage(90 - i * 10)}
                      </span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-gray-200 dark:bg-gray-800">
                      <div
                        className="h-full rounded-full bg-primary-600"
                        style={{ width: `${90 - i * 10}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
