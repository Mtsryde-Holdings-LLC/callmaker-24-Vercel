'use client';

import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar } from '@/components/ui/avatar';
import { Loading } from '@/components/ui/loading';
import { EmptyState } from '@/components/ui/empty-state';
import { conversationsApi, messagesApi } from '@/lib/api-client';
import { formatDate } from '@/lib/utils';
import { useAuth } from '@/lib/auth-context';
import type { Conversation, Message } from '@/types';
import toast from 'react-hot-toast';
import {
  ChatBubbleLeftRightIcon,
  PaperAirplaneIcon,
  UserIcon,
  CheckCircleIcon,
  ClockIcon,
  XMarkIcon,
} from '@heroicons/react/24/outline';

export default function ChatPage() {
  const { user } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messageText, setMessageText] = useState('');
  const [filter, setFilter] = useState<'all' | 'open' | 'assigned' | 'closed'>('open');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: conversationsData, isLoading: conversationsLoading, refetch: refetchConversations } = useQuery({
    queryKey: ['conversations', filter],
    queryFn: () => conversationsApi.list({ status: filter === 'all' ? undefined : filter }),
    refetchInterval: 5000, // Poll every 5 seconds
  });

  const { data: messagesData, isLoading: messagesLoading, refetch: refetchMessages } = useQuery({
    queryKey: ['messages', selectedConversation],
    queryFn: () => messagesApi.list({ conversationId: selectedConversation! }),
    enabled: !!selectedConversation,
    refetchInterval: 2000, // Poll every 2 seconds
  });

  const conversations = (conversationsData?.data as Conversation[]) || [];
  const messages = (messagesData?.data as Message[]) || [];
  const currentConversation = conversations.find((c) => c.id === selectedConversation);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!messageText.trim() || !selectedConversation) return;

    try {
      const response = await messagesApi.send({
        conversationId: selectedConversation,
        content: messageText,
        type: 'TEXT',
        sender: 'AGENT',
      });

      if (response.success) {
        setMessageText('');
        refetchMessages();
        refetchConversations();
      } else {
        toast.error('Failed to send message');
      }
    } catch (error) {
      toast.error('Failed to send message');
    }
  };

  const handleAssignToMe = async () => {
    if (!selectedConversation || !user) return;

    try {
      const response = await conversationsApi.assign(selectedConversation, user.id);

      if (response.success) {
        toast.success('Conversation assigned to you');
        refetchConversations();
      } else {
        toast.error('Failed to assign conversation');
      }
    } catch (error) {
      toast.error('Failed to assign conversation');
    }
  };

  const handleCloseConversation = async () => {
    if (!selectedConversation) return;

    try {
      const response = await conversationsApi.close(selectedConversation);
      if (response.success) {
        toast.success('Conversation closed');
        refetchConversations();
        setSelectedConversation(null);
      } else {
        toast.error('Failed to close conversation');
      }
    } catch (error) {
      toast.error('Failed to close conversation');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPEN':
        return 'success';
      case 'PENDING':
        return 'warning';
      case 'CLOSED':
        return 'gray';
      default:
        return 'gray';
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Customer Support</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">
              Manage customer conversations and support tickets
            </p>
          </div>

          <div className="flex gap-2">
            <Button
              variant={filter === 'all' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setFilter('all')}
            >
              All
            </Button>
            <Button
              variant={filter === 'open' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setFilter('open')}
            >
              Open
            </Button>
            <Button
              variant={filter === 'assigned' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setFilter('assigned')}
            >
              Assigned to Me
            </Button>
            <Button
              variant={filter === 'closed' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setFilter('closed')}
            >
              Closed
            </Button>
          </div>
        </div>

        <div className="grid h-[calc(100vh-16rem)] grid-cols-12 gap-6">
          {/* Conversations List */}
          <Card className="col-span-4 overflow-hidden">
            <CardHeader className="border-b border-gray-200 dark:border-gray-700">
              <CardTitle>Conversations</CardTitle>
            </CardHeader>
            <CardContent className="h-full overflow-y-auto p-0">
              {conversationsLoading ? (
                <div className="flex h-96 items-center justify-center">
                  <Loading />
                </div>
              ) : conversations.length === 0 ? (
                <div className="p-8">
                  <EmptyState
                    icon={<ChatBubbleLeftRightIcon className="h-12 w-12" />}
                    title="No conversations"
                    description="No conversations match your current filter"
                  />
                </div>
              ) : (
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  {conversations.map((conversation) => (
                    <div
                      key={conversation.id}
                      onClick={() => setSelectedConversation(conversation.id)}
                      className={`cursor-pointer p-4 transition-colors hover:bg-gray-50 dark:hover:bg-gray-800 ${
                        selectedConversation === conversation.id
                          ? 'bg-primary-50 dark:bg-primary-900/20'
                          : ''
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <Avatar
                          firstName={conversation.customer?.firstName}
                          lastName={conversation.customer?.lastName}
                          size="sm"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <div className="font-medium text-gray-900 dark:text-white truncate">
                              {conversation.customer?.firstName} {conversation.customer?.lastName}
                            </div>
                            <Badge variant={getStatusColor(conversation.status) as any} size="sm">
                              {conversation.status}
                            </Badge>
                          </div>
                          <div className="mt-1 text-sm text-gray-600 dark:text-gray-400 truncate">
                            {conversation.lastMessage || 'No messages yet'}
                          </div>
                          <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
                            <ClockIcon className="h-3 w-3" />
                            {formatDate(conversation.updatedAt, 'relative')}
                            {(conversation.unreadCount ?? 0) > 0 && (
                              <Badge variant="primary" size="sm">
                                {conversation.unreadCount}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Messages Panel */}
          <Card className="col-span-8 flex flex-col overflow-hidden">
            {selectedConversation ? (
              <>
                {/* Header */}
                <CardHeader className="border-b border-gray-200 dark:border-gray-700">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar
                        firstName={currentConversation?.customer?.firstName}
                        lastName={currentConversation?.customer?.lastName}
                        size="md"
                      />
                      <div>
                        <div className="font-medium text-gray-900 dark:text-white">
                          {currentConversation?.customer?.firstName}{' '}
                          {currentConversation?.customer?.lastName}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          {currentConversation?.customer?.email}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {currentConversation?.status === 'OPEN' &&
                        !currentConversation?.assignedTo && (
                          <Button size="sm" variant="outline" onClick={handleAssignToMe}>
                            <UserIcon className="mr-2 h-4 w-4" />
                            Assign to Me
                          </Button>
                        )}
                      {currentConversation?.status === 'OPEN' && (
                        <Button size="sm" variant="outline" onClick={handleCloseConversation}>
                          <CheckCircleIcon className="mr-2 h-4 w-4" />
                          Close
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setSelectedConversation(null)}
                      >
                        <XMarkIcon className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {/* Messages */}
                <CardContent className="flex-1 overflow-y-auto p-6">
                  {messagesLoading ? (
                    <div className="flex h-full items-center justify-center">
                      <Loading />
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${
                            message.sender === 'AGENT' ? 'justify-end' : 'justify-start'
                          }`}
                        >
                          <div
                            className={`max-w-[70%] rounded-lg p-3 ${
                              message.sender === 'AGENT'
                                ? 'bg-primary-600 text-white'
                                : 'bg-gray-100 text-gray-900 dark:bg-gray-800 dark:text-white'
                            }`}
                          >
                            <div className="whitespace-pre-wrap break-words">
                              {message.content}
                            </div>
                            <div
                              className={`mt-1 text-xs ${
                                message.sender === 'AGENT'
                                  ? 'text-primary-100'
                                  : 'text-gray-500 dark:text-gray-400'
                              }`}
                            >
                              {formatDate(message.createdAt, 'time')}
                            </div>
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </div>
                  )}
                </CardContent>

                {/* Message Input */}
                {currentConversation?.status !== 'CLOSED' && (
                  <div className="border-t border-gray-200 p-4 dark:border-gray-700">
                    <div className="flex gap-2">
                      <Textarea
                        value={messageText}
                        onChange={(e) => setMessageText(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                          }
                        }}
                        placeholder="Type your message..."
                        rows={2}
                        className="flex-1"
                      />
                      <Button onClick={handleSendMessage} disabled={!messageText.trim()}>
                        <PaperAirplaneIcon className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="flex h-full items-center justify-center">
                <EmptyState
                  icon={<ChatBubbleLeftRightIcon className="h-16 w-16" />}
                  title="Select a conversation"
                  description="Choose a conversation from the list to view messages"
                />
              </div>
            )}
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
