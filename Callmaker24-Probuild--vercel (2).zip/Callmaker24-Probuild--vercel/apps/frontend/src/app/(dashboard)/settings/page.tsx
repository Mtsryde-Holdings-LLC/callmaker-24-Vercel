'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { Tabs } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Loading } from '@/components/ui/loading';
import { settingsApi, teamApi, apiKeysApi, integrationsApi } from '@/lib/api-client';
import { useAuth } from '@/lib/auth-context';
import type { User, Integration, APIKey } from '@/types';
import toast from 'react-hot-toast';
import {
  UserIcon,
  UsersIcon,
  KeyIcon,
  PuzzlePieceIcon,
  TrashIcon,
  PlusIcon,
  ClipboardDocumentIcon,
} from '@heroicons/react/24/outline';

export default function SettingsPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Settings</h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Manage your account, team, and integrations
          </p>
        </div>

        <Tabs
          tabs={[
            {
              label: 'Profile',
              icon: <UserIcon className="h-4 w-4" />,
              content: <ProfileSettings />,
            },
            {
              label: 'Team',
              icon: <UsersIcon className="h-4 w-4" />,
              content: <TeamSettings />,
            },
            {
              label: 'API Keys',
              icon: <KeyIcon className="h-4 w-4" />,
              content: <ApiKeysSettings />,
            },
            {
              label: 'Integrations',
              icon: <PuzzlePieceIcon className="h-4 w-4" />,
              content: <IntegrationsSettings />,
            },
          ]}
        />
      </div>
    </DashboardLayout>
  );
}

function ProfileSettings() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    company: user?.company || '',
    phoneNumber: user?.phoneNumber || '',
    timezone: user?.timezone || 'UTC',
  });

  const handleSave = async () => {
    setLoading(true);
    try {
      const response = await settingsApi.updateProfile(formData);
      if (response.success) {
        toast.success('Profile updated successfully');
      } else {
        toast.error('Failed to update profile');
      }
    } catch (error) {
      toast.error('Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const timezones = [
    { value: 'UTC', label: 'UTC' },
    { value: 'America/New_York', label: 'Eastern Time' },
    { value: 'America/Chicago', label: 'Central Time' },
    { value: 'America/Denver', label: 'Mountain Time' },
    { value: 'America/Los_Angeles', label: 'Pacific Time' },
    { value: 'Europe/London', label: 'London' },
    { value: 'Europe/Paris', label: 'Paris' },
    { value: 'Asia/Tokyo', label: 'Tokyo' },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Personal Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="First Name"
              value={formData.firstName}
              onChange={(e) => setFormData((prev) => ({ ...prev, firstName: e.target.value }))}
            />
            <Input
              label="Last Name"
              value={formData.lastName}
              onChange={(e) => setFormData((prev) => ({ ...prev, lastName: e.target.value }))}
            />
          </div>

          <Input
            label="Email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
          />

          <Input
            label="Phone Number"
            value={formData.phoneNumber}
            onChange={(e) => setFormData((prev) => ({ ...prev, phoneNumber: e.target.value }))}
          />

          <Input
            label="Company"
            value={formData.company}
            onChange={(e) => setFormData((prev) => ({ ...prev, company: e.target.value }))}
          />

          <Select
            label="Timezone"
            value={formData.timezone}
            onChange={(e) => setFormData((prev) => ({ ...prev, timezone: e.target.value }))}
            options={timezones}
          />

          <div className="flex justify-end">
            <Button onClick={handleSave} loading={loading}>
              Save Changes
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Password</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input label="Current Password" type="password" />
          <Input label="New Password" type="password" />
          <Input label="Confirm New Password" type="password" />

          <div className="flex justify-end">
            <Button>Update Password</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-red-600">Danger Zone</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border border-red-200 bg-red-50 p-4 dark:border-red-900/50 dark:bg-red-900/20">
            <h4 className="font-medium text-red-900 dark:text-red-200">Delete Account</h4>
            <p className="mt-2 text-sm text-red-700 dark:text-red-300">
              Once you delete your account, there is no going back. All your data will be
              permanently deleted.
            </p>
            <Button variant="outline" className="mt-4 border-red-600 text-red-600">
              Delete Account
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function TeamSettings() {
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('AGENT');
  const [loading, setLoading] = useState(false);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['team', 'members'],
    queryFn: () => teamApi.list(),
  });

  const members = (data?.data as User[]) || [];

  const handleInvite = async () => {
    if (!inviteEmail) {
      toast.error('Email is required');
      return;
    }

    setLoading(true);
    try {
      const response = await teamApi.invite({
        email: inviteEmail,
        role: inviteRole,
      });

      if (response.success) {
        toast.success('Invitation sent!');
        setInviteEmail('');
        refetch();
      } else {
        toast.error('Failed to send invitation');
      }
    } catch (error) {
      toast.error('Failed to send invitation');
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (memberId: string) => {
    if (!confirm('Are you sure you want to remove this team member?')) return;

    try {
      const response = await teamApi.remove(memberId);
      if (response.success) {
        toast.success('Team member removed');
        refetch();
      } else {
        toast.error('Failed to remove team member');
      }
    } catch (error) {
      toast.error('Failed to remove team member');
    }
  };

  const roleOptions = [
    { value: 'ADMIN', label: 'Admin' },
    { value: 'SUB_ADMIN', label: 'Sub Admin' },
    { value: 'AGENT', label: 'Agent' },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Invite Team Member</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="col-span-2">
              <Input
                label="Email Address"
                type="email"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                placeholder="colleague@example.com"
              />
            </div>
            <Select
              label="Role"
              value={inviteRole}
              onChange={(e) => setInviteRole(e.target.value)}
              options={roleOptions}
            />
          </div>

          <Button onClick={handleInvite} loading={loading}>
            <PlusIcon className="mr-2 h-4 w-4" />
            Send Invitation
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Team Members</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <Loading />
            </div>
          ) : members.length === 0 ? (
            <div className="py-8 text-center text-gray-500">No team members yet</div>
          ) : (
            <div className="space-y-3">
              {members.map((member: any) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between rounded-lg border border-gray-200 p-4 dark:border-gray-700"
                >
                  <div className="flex items-center gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-100 text-sm font-medium text-primary-700 dark:bg-primary-900/20 dark:text-primary-300">
                      {member.firstName?.[0]}
                      {member.lastName?.[0]}
                    </div>
                    <div>
                      <div className="font-medium text-gray-900 dark:text-white">
                        {member.firstName} {member.lastName}
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {member.email}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Badge variant="gray">{member.role}</Badge>
                    {member.status === 'PENDING' && <Badge variant="warning">Pending</Badge>}
                    {member.status === 'ACTIVE' && <Badge variant="success">Active</Badge>}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleRemove(member.id)}
                    >
                      <TrashIcon className="h-4 w-4 text-red-600" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ApiKeysSettings() {
  const [keyName, setKeyName] = useState('');
  const [loading, setLoading] = useState(false);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['api-keys'],
    queryFn: () => apiKeysApi.list(),
  });

  const apiKeys = (data?.data as APIKey[]) || [];

  const handleCreate = async () => {
    if (!keyName) {
      toast.error('Key name is required');
      return;
    }

    setLoading(true);
    try {
      const response = await apiKeysApi.create({ name: keyName });
      const apiKeyData = response.data as APIKey | undefined;
      if (response.success) {
        toast.success('API key created!');
        setKeyName('');
        refetch();

        // Show the key once
        if (apiKeyData?.key) {
          alert(`Your API Key: ${apiKeyData.key}\n\nMake sure to copy it now. You won't be able to see it again!`);
        }
      } else {
        toast.error('Failed to create API key');
      }
    } catch (error) {
      toast.error('Failed to create API key');
    } finally {
      setLoading(false);
    }
  };

  const handleRevoke = async (keyId: string) => {
    if (!confirm('Are you sure you want to revoke this API key?')) return;

    try {
      const response = await apiKeysApi.revoke(keyId);
      if (response.success) {
        toast.success('API key revoked');
        refetch();
      } else {
        toast.error('Failed to revoke API key');
      }
    } catch (error) {
      toast.error('Failed to revoke API key');
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Create API Key</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input
            label="Key Name"
            value={keyName}
            onChange={(e) => setKeyName(e.target.value)}
            placeholder="e.g., Production API Key"
          />

          <Button onClick={handleCreate} loading={loading}>
            <PlusIcon className="mr-2 h-4 w-4" />
            Create API Key
          </Button>

          <div className="rounded-lg bg-yellow-50 p-4 dark:bg-yellow-900/20">
            <p className="text-sm text-yellow-800 dark:text-yellow-200">
              API keys are only shown once upon creation. Make sure to copy and store them
              securely.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Your API Keys</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <Loading />
            </div>
          ) : apiKeys.length === 0 ? (
            <div className="py-8 text-center text-gray-500">No API keys yet</div>
          ) : (
            <div className="space-y-3">
              {apiKeys.map((key: any) => (
                <div
                  key={key.id}
                  className="flex items-center justify-between rounded-lg border border-gray-200 p-4 dark:border-gray-700"
                >
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">{key.name}</div>
                    <div className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                      Created {new Date(key.createdAt).toLocaleDateString()} • Last used{' '}
                      {key.lastUsed ? new Date(key.lastUsed).toLocaleDateString() : 'Never'}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Badge variant={key.status === 'ACTIVE' ? 'success' : 'gray'}>
                      {key.status}
                    </Badge>
                    <Button size="sm" variant="ghost" onClick={() => handleRevoke(key.id)}>
                      <TrashIcon className="h-4 w-4 text-red-600" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>API Documentation</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Use our RESTful API to integrate with your applications. Include your API key in the
            Authorization header.
          </p>
          <div className="mt-4 rounded-lg bg-gray-100 p-4 font-mono text-sm dark:bg-gray-800">
            <div className="text-gray-600 dark:text-gray-400">curl -X GET \</div>
            <div className="text-gray-600 dark:text-gray-400">
              {' '}
              https://api.yourdomain.com/v1/campaigns \
            </div>
            <div className="text-gray-600 dark:text-gray-400">
              {' '}
              -H "Authorization: Bearer YOUR_API_KEY"
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function IntegrationsSettings() {
  const [loading, setLoading] = useState(false);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['integrations'],
    queryFn: () => integrationsApi.list(),
  });

  const integrations = (data?.data as Integration[]) || [];

  const handleConnect = async (integrationType: string) => {
    setLoading(true);
    try {
      const response = await integrationsApi.connect(integrationType, {});
      if (response.success) {
        toast.success(`${integrationType} connected!`);
        refetch();
      } else {
        toast.error(`Failed to connect ${integrationType}`);
      }
    } catch (error) {
      toast.error('Failed to connect integration');
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = async (integrationId: string) => {
    if (!confirm('Are you sure you want to disconnect this integration?')) return;

    try {
      const response = await integrationsApi.disconnect(integrationId);
      if (response.success) {
        toast.success('Integration disconnected');
        refetch();
      } else {
        toast.error('Failed to disconnect integration');
      }
    } catch (error) {
      toast.error('Failed to disconnect integration');
    }
  };

  const availableIntegrations = [
    {
      id: 'shopify',
      name: 'Shopify',
      description: 'Sync customers and orders from your Shopify store',
      icon: '🛍️',
      connected: integrations.some((i: any) => i.type === 'SHOPIFY' && i.status === 'ACTIVE'),
    },
    {
      id: 'woocommerce',
      name: 'WooCommerce',
      description: 'Sync customers and orders from WooCommerce',
      icon: '🛒',
      connected: integrations.some(
        (i: any) => i.type === 'WOOCOMMERCE' && i.status === 'ACTIVE'
      ),
    },
    {
      id: 'stripe',
      name: 'Stripe',
      description: 'Manage payments and subscriptions',
      icon: '💳',
      connected: integrations.some((i: any) => i.type === 'STRIPE' && i.status === 'ACTIVE'),
    },
    {
      id: 'mailchimp',
      name: 'Mailchimp',
      description: 'Import contacts from Mailchimp',
      icon: '📧',
      connected: integrations.some((i: any) => i.type === 'MAILCHIMP' && i.status === 'ACTIVE'),
    },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Available Integrations</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <Loading />
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {availableIntegrations.map((integration) => (
                <div
                  key={integration.id}
                  className="rounded-lg border border-gray-200 p-4 dark:border-gray-700"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="text-3xl">{integration.icon}</div>
                      <div>
                        <h4 className="font-medium text-gray-900 dark:text-white">
                          {integration.name}
                        </h4>
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                          {integration.description}
                        </p>
                      </div>
                    </div>
                    {integration.connected && (
                      <Badge variant="success">Connected</Badge>
                    )}
                  </div>

                  <div className="mt-4">
                    {integration.connected ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const connectedIntegration = integrations.find(
                            (i: any) =>
                              i.type === integration.id.toUpperCase() && i.status === 'ACTIVE'
                          );
                          if (connectedIntegration) {
                            handleDisconnect(connectedIntegration.id);
                          }
                        }}
                      >
                        Disconnect
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        onClick={() => handleConnect(integration.id.toUpperCase())}
                        loading={loading}
                      >
                        Connect
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Webhook URL</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Configure your integrations to send webhooks to this URL
          </p>

          <div className="flex items-center gap-2">
            <Input
              value={`${process.env.NEXT_PUBLIC_API_URL}/webhooks`}
              readOnly
              className="flex-1"
            />
            <Button
              variant="outline"
              onClick={() => {
                navigator.clipboard.writeText(`${process.env.NEXT_PUBLIC_API_URL}/webhooks`);
                toast.success('Webhook URL copied!');
              }}
            >
              <ClipboardDocumentIcon className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
