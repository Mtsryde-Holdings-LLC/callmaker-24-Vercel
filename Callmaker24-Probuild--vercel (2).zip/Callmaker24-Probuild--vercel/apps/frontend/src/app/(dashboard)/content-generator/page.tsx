'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { SparklesIcon, ClockIcon, CalendarIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

interface GeneratedContent {
  mainContent: string;
  hashtags: string[];
  suggestedImages?: string[];
  bestTimeToPost?: string;
  estimatedEngagement?: string;
}

export default function ContentGeneratorPage() {
  const [formData, setFormData] = useState({
    topic: '',
    businessType: '',
    targetAudience: '',
    platform: 'twitter' as 'twitter' | 'facebook' | 'instagram' | 'linkedin' | 'tiktok',
    tone: 'professional' as 'professional' | 'casual' | 'friendly' | 'informative' | 'humorous',
    contentType: 'post' as 'post' | 'story' | 'tweet' | 'article' | 'caption',
    includeHashtags: true,
    includeEmojis: true,
    includeCallToAction: true,
    keywords: '',
  });

  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [variations, setVariations] = useState<Array<{ content: string; hashtags: string[] }>>([]);

  const handleGenerate = async () => {
    if (!formData.topic || !formData.businessType || !formData.targetAudience) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsGenerating(true);

    try {
      const response = await fetch('/api/generate-content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          keywords: formData.keywords ? formData.keywords.split(',').map(k => k.trim()).filter(k => k) : [],
        }),
      });

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to generate content');
      }

      setGeneratedContent(data.data);
      toast.success('Content generated successfully!');
    } catch (error: any) {
      console.error('Error generating content:', error);
      toast.error(error.message || 'Failed to generate content');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateVariations = async () => {
    if (!formData.topic || !formData.businessType || !formData.targetAudience) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsGenerating(true);

    try {
      const response = await fetch('/api/generate-content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          keywords: formData.keywords ? formData.keywords.split(',').map(k => k.trim()).filter(k => k) : [],
          generateVariations: true,
          variationCount: 3,
        }),
      });

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to generate variations');
      }

      setVariations(data.data.variations || []);
      toast.success('Variations generated successfully!');
    } catch (error: any) {
      console.error('Error generating variations:', error);
      toast.error(error.message || 'Failed to generate variations');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">AI Content Generator</h1>
        <p className="mt-1 text-sm text-gray-600">
          Generate engaging social media content powered by AI
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Input Form */}
        <Card className="p-6">
          <h2 className="mb-4 text-lg font-semibold">Content Parameters</h2>

          <div className="space-y-4">
            {/* Topic */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">
                Topic *
              </label>
              <input
                type="text"
                value={formData.topic}
                onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                className="w-full rounded-md border border-gray-300 px-3 py-2"
                placeholder="e.g., New Product Launch"
              />
            </div>

            {/* Business Type */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">
                Business Type *
              </label>
              <input
                type="text"
                value={formData.businessType}
                onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                className="w-full rounded-md border border-gray-300 px-3 py-2"
                placeholder="e.g., SaaS, E-commerce, Agency"
              />
            </div>

            {/* Target Audience */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">
                Target Audience *
              </label>
              <input
                type="text"
                value={formData.targetAudience}
                onChange={(e) => setFormData({ ...formData, targetAudience: e.target.value })}
                className="w-full rounded-md border border-gray-300 px-3 py-2"
                placeholder="e.g., Small business owners, Developers"
              />
            </div>

            {/* Platform */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">
                Platform
              </label>
              <select
                value={formData.platform}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    platform: e.target.value as any,
                  })
                }
                className="w-full rounded-md border border-gray-300 px-3 py-2"
              >
                <option value="twitter">Twitter/X</option>
                <option value="linkedin">LinkedIn</option>
                <option value="facebook">Facebook</option>
                <option value="instagram">Instagram</option>
                <option value="tiktok">TikTok</option>
              </select>
            </div>

            {/* Tone */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">
                Tone
              </label>
              <select
                value={formData.tone}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    tone: e.target.value as any,
                  })
                }
                className="w-full rounded-md border border-gray-300 px-3 py-2"
              >
                <option value="professional">Professional</option>
                <option value="casual">Casual</option>
                <option value="friendly">Friendly</option>
                <option value="informative">Informative</option>
                <option value="humorous">Humorous</option>
              </select>
            </div>

            {/* Content Type */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">
                Content Type
              </label>
              <select
                value={formData.contentType}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    contentType: e.target.value as any,
                  })
                }
                className="w-full rounded-md border border-gray-300 px-3 py-2"
              >
                <option value="post">Post</option>
                <option value="story">Story</option>
                <option value="tweet">Tweet</option>
                <option value="article">Article</option>
                <option value="caption">Caption</option>
              </select>
            </div>

            {/* Keywords */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">
                Keywords (comma-separated)
              </label>
              <input
                type="text"
                value={formData.keywords}
                onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
                className="w-full rounded-md border border-gray-300 px-3 py-2"
                placeholder="e.g., innovation, growth, success"
              />
            </div>

            {/* Options */}
            <div className="space-y-2">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.includeHashtags}
                  onChange={(e) =>
                    setFormData({ ...formData, includeHashtags: e.target.checked })
                  }
                  className="rounded"
                />
                <span className="text-sm text-gray-700">Include hashtags</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.includeEmojis}
                  onChange={(e) =>
                    setFormData({ ...formData, includeEmojis: e.target.checked })
                  }
                  className="rounded"
                />
                <span className="text-sm text-gray-700">Include emojis</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.includeCallToAction}
                  onChange={(e) =>
                    setFormData({ ...formData, includeCallToAction: e.target.checked })
                  }
                  className="rounded"
                />
                <span className="text-sm text-gray-700">Include call-to-action</span>
              </label>
            </div>

            {/* Generate Buttons */}
            <div className="flex gap-2">
              <Button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="flex-1"
              >
                {isGenerating ? (
                  'Generating...'
                ) : (
                  <>
                    <SparklesIcon className="mr-2 h-5 w-5" />
                    Generate Content
                  </>
                )}
              </Button>
            </div>

            <Button
              onClick={handleGenerateVariations}
              disabled={isGenerating}
              variant="outline"
              className="w-full"
            >
              Generate A/B Test Variations
            </Button>
          </div>
        </Card>

        {/* Generated Content Preview */}
        <div className="space-y-6">
          {generatedContent && (
            <Card className="p-6">
              <h2 className="mb-4 text-lg font-semibold">Generated Content</h2>

              {/* Main Content */}
              <div className="mb-4">
                <div className="mb-2 flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-700">Content</label>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(generatedContent.mainContent)}
                  >
                    Copy
                  </Button>
                </div>
                <div className="rounded-lg border border-gray-200 bg-gray-50 p-4">
                  <p className="whitespace-pre-wrap text-gray-800">
                    {generatedContent.mainContent}
                  </p>
                </div>
              </div>

              {/* Hashtags */}
              {generatedContent.hashtags && generatedContent.hashtags.length > 0 && (
                <div className="mb-4">
                  <label className="mb-2 block text-sm font-medium text-gray-700">
                    Hashtags
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {generatedContent.hashtags.map((tag, index) => (
                      <span
                        key={index}
                        className="rounded-full bg-blue-100 px-3 py-1 text-sm text-blue-700"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Best Time to Post */}
              {generatedContent.bestTimeToPost && (
                <div className="mb-4 flex items-start gap-2 rounded-lg bg-blue-50 p-3">
                  <ClockIcon className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="text-sm font-medium text-blue-900">Best Time to Post</p>
                    <p className="text-sm text-blue-700">{generatedContent.bestTimeToPost}</p>
                  </div>
                </div>
              )}

              {/* Estimated Engagement */}
              {generatedContent.estimatedEngagement && (
                <div className="mb-4 flex items-start gap-2 rounded-lg bg-green-50 p-3">
                  <SparklesIcon className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-sm font-medium text-green-900">Estimated Engagement</p>
                    <p className="text-sm text-green-700">
                      {generatedContent.estimatedEngagement}
                    </p>
                  </div>
                </div>
              )}

              {/* Image Suggestions */}
              {generatedContent.suggestedImages && generatedContent.suggestedImages.length > 0 && (
                <div>
                  <label className="mb-2 block text-sm font-medium text-gray-700">
                    Image Suggestions
                  </label>
                  <ul className="list-inside list-disc space-y-1 text-sm text-gray-600">
                    {generatedContent.suggestedImages.map((suggestion, index) => (
                      <li key={index}>{suggestion}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Action Buttons */}
              <div className="mt-6 flex gap-2">
                <Button className="flex-1">
                  <CalendarIcon className="mr-2 h-5 w-5" />
                  Schedule Post
                </Button>
                <Button variant="outline" className="flex-1">
                  Post Now
                </Button>
              </div>
            </Card>
          )}

          {/* Variations */}
          {variations.length > 0 && (
            <Card className="p-6">
              <h2 className="mb-4 text-lg font-semibold">Content Variations</h2>

              <div className="space-y-4">
                {variations.map((variation, index) => (
                  <div
                    key={index}
                    className="rounded-lg border border-gray-200 p-4"
                  >
                    <div className="mb-2 flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">
                        Variation {index + 1}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(variation.content)}
                      >
                        Copy
                      </Button>
                    </div>
                    <p className="mb-2 text-gray-800">{variation.content}</p>
                    <div className="flex flex-wrap gap-1">
                      {variation.hashtags.map((tag, tagIndex) => (
                        <span
                          key={tagIndex}
                          className="rounded bg-gray-100 px-2 py-0.5 text-xs text-gray-600"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
