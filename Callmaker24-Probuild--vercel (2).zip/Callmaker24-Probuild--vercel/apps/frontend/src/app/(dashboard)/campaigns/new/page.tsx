'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Tabs } from '@/components/ui/tabs';
import { campaignsApi, aiApi } from '@/lib/api-client';
import type { AIGenerationResponse } from '@/types';
import toast from 'react-hot-toast';
import { SparklesIcon } from '@heroicons/react/24/outline';

export default function NewCampaignPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    type: 'EMAIL',
    subject: '',
    content: '',
    htmlContent: '',
    fromEmail: process.env.NEXT_PUBLIC_SES_FROM_EMAIL || '',
    fromName: 'Marketing Platform Pro',
    replyToEmail: '',
    segments: [] as string[],
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name) newErrors.name = 'Campaign name is required';
    if (formData.type === 'EMAIL' && !formData.subject) newErrors.subject = 'Subject is required';
    if (!formData.content) newErrors.content = 'Content is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleGenerateContent = async (contentType: 'subject' | 'email' | 'sms') => {
    const prompt = window.prompt(
      `Describe what you want to generate (e.g., "promotional email for new product launch")`
    );

    if (!prompt) return;

    setAiLoading(true);
    try {
      const response = await aiApi.generate({
        prompt,
        type: contentType === 'subject' ? 'subject' : contentType,
      });

      const aiData = response.data as AIGenerationResponse;
      if (response.success && aiData) {
        if (contentType === 'subject') {
          setFormData((prev) => ({ ...prev, subject: aiData.content }));
        } else {
          setFormData((prev) => ({
            ...prev,
            content: aiData.content,
            htmlContent: `<div style="font-family: Arial, sans-serif;">${aiData.content.replace(/\n/g, '<br>')}</div>`,
          }));
        }
        toast.success('Content generated successfully!');
      } else {
        toast.error('Failed to generate content');
      }
    } catch (error) {
      toast.error('AI generation failed');
    } finally {
      setAiLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) {
      toast.error('Please fix the errors');
      return;
    }

    setLoading(true);
    try {
      const response = await campaignsApi.create(formData);

      if (response.success) {
        toast.success('Campaign created successfully!');
        router.push('/campaigns');
      } else {
        toast.error(response.error?.message || 'Failed to create campaign');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to create campaign');
    } finally {
      setLoading(false);
    }
  };

  const campaignTypes = [
    { value: 'EMAIL', label: 'Email Campaign' },
    { value: 'SMS', label: 'SMS Campaign' },
  ];

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-4xl space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Create Campaign</h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Build and send your marketing campaign
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                label="Campaign Name"
                value={formData.name}
                onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                placeholder="e.g., Summer Sale 2024"
                error={errors.name}
              />

              <Select
                label="Campaign Type"
                value={formData.type}
                onChange={(e) => setFormData((prev) => ({ ...prev, type: e.target.value }))}
                options={campaignTypes}
              />

              {formData.type === 'EMAIL' && (
                <>
                  <div>
                    <div className="mb-2 flex items-center justify-between">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Subject Line
                      </label>
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={() => handleGenerateContent('subject')}
                        loading={aiLoading}
                      >
                        <SparklesIcon className="mr-2 h-4 w-4" />
                        AI Generate
                      </Button>
                    </div>
                    <Input
                      value={formData.subject}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, subject: e.target.value }))
                      }
                      placeholder="Enter subject line..."
                      error={errors.subject}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      label="From Email"
                      type="email"
                      value={formData.fromEmail}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, fromEmail: e.target.value }))
                      }
                      placeholder="noreply@yourdomain.com"
                    />

                    <Input
                      label="From Name"
                      value={formData.fromName}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, fromName: e.target.value }))
                      }
                      placeholder="Your Company"
                    />
                  </div>

                  <Input
                    label="Reply-To Email (optional)"
                    type="email"
                    value={formData.replyToEmail}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, replyToEmail: e.target.value }))
                    }
                    placeholder="support@yourdomain.com"
                  />
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Content</CardTitle>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => handleGenerateContent(formData.type === 'EMAIL' ? 'email' : 'sms')}
                  loading={aiLoading}
                >
                  <SparklesIcon className="mr-2 h-4 w-4" />
                  AI Generate
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs
                tabs={[
                  {
                    label: 'Plain Text',
                    content: (
                      <Textarea
                        value={formData.content}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, content: e.target.value }))
                        }
                        placeholder={
                          formData.type === 'EMAIL'
                            ? 'Enter your email content...\n\nYou can use {{firstName}}, {{lastName}}, {{email}} for personalization.'
                            : 'Enter your SMS message (max 160 characters)...'
                        }
                        rows={10}
                        error={errors.content}
                      />
                    ),
                  },
                  ...(formData.type === 'EMAIL'
                    ? [
                        {
                          label: 'HTML',
                          content: (
                            <Textarea
                              value={formData.htmlContent}
                              onChange={(e) =>
                                setFormData((prev) => ({ ...prev, htmlContent: e.target.value }))
                              }
                              placeholder="<html>...</html>"
                              rows={10}
                            />
                          ),
                        },
                      ]
                    : []),
                ]}
              />

              <div className="rounded-lg bg-blue-50 p-4 dark:bg-blue-900/20">
                <h4 className="mb-2 text-sm font-medium text-blue-900 dark:text-blue-200">
                  Personalization Tokens
                </h4>
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  Use these tokens in your content: <code>{'{{firstName}}'}</code>,{' '}
                  <code>{'{{lastName}}'}</code>, <code>{'{{email}}'}</code>,{' '}
                  <code>{'{{company}}'}</code>
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => router.push('/campaigns')}>
              Cancel
            </Button>
            <Button type="submit" loading={loading}>
              Create Campaign
            </Button>
          </div>
        </form>
      </div>
    </DashboardLayout>
  );
}
