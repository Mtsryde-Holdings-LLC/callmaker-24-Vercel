'use client';

import { useParams, useRouter } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs } from '@/components/ui/tabs';
import { Loading } from '@/components/ui/loading';
import { campaignsApi } from '@/lib/api-client';
import { formatDate, formatNumber, formatPercentage, getStatusColor } from '@/lib/utils';
import type { Campaign } from '@/types';
import toast from 'react-hot-toast';
import {
  PaperAirplaneIcon,
  PencilIcon,
  TrashIcon,
  PauseIcon,
} from '@heroicons/react/24/outline';

export default function CampaignDetailPage() {
  const params = useParams();
  const router = useRouter();
  const campaignId = params?.id as string;

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['campaign', campaignId],
    queryFn: () => campaignsApi.get(campaignId),
  });

  const campaign = data?.data as Campaign;

  const handleSend = async () => {
    if (!confirm('Are you sure you want to send this campaign?')) return;

    try {
      const response = await campaignsApi.send(campaignId);
      if (response.success) {
        toast.success('Campaign is being sent!');
        refetch();
      } else {
        toast.error('Failed to send campaign');
      }
    } catch (error) {
      toast.error('Failed to send campaign');
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this campaign?')) return;

    try {
      const response = await campaignsApi.delete(campaignId);
      if (response.success) {
        toast.success('Campaign deleted');
        router.push('/campaigns');
      } else {
        toast.error('Failed to delete campaign');
      }
    } catch (error) {
      toast.error('Failed to delete campaign');
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex h-96 items-center justify-center">
          <Loading size="lg" />
        </div>
      </DashboardLayout>
    );
  }

  if (!campaign) {
    return (
      <DashboardLayout>
        <div className="text-center">
          <h1 className="text-2xl font-bold">Campaign not found</h1>
        </div>
      </DashboardLayout>
    );
  }

  const analytics = campaign.analytics || {
    sent: 0,
    delivered: 0,
    opened: 0,
    clicked: 0,
    bounced: 0,
    unsubscribed: 0,
    deliveryRate: 0,
    openRate: 0,
    clickRate: 0,
    unsubscribeRate: 0,
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                {campaign.name}
              </h1>
              <Badge variant={getStatusColor(campaign.status) as any}>{campaign.status}</Badge>
            </div>
            <p className="mt-2 text-gray-600 dark:text-gray-400">
              Created {formatDate(campaign.createdAt, 'relative')}
              {campaign.sentAt && ` • Sent ${formatDate(campaign.sentAt, 'relative')}`}
            </p>
          </div>

          <div className="flex gap-2">
            {campaign.status === 'DRAFT' && (
              <>
                <Button variant="outline" onClick={() => router.push(`/campaigns/${campaignId}/edit`)}>
                  <PencilIcon className="mr-2 h-4 w-4" />
                  Edit
                </Button>
                <Button onClick={handleSend}>
                  <PaperAirplaneIcon className="mr-2 h-4 w-4" />
                  Send Now
                </Button>
              </>
            )}
            {campaign.status === 'SENDING' && (
              <Button variant="outline" onClick={() => toast('Pause feature coming soon', { icon: 'ℹ️' })}>
                <PauseIcon className="mr-2 h-4 w-4" />
                Pause
              </Button>
            )}
            <Button variant="outline" onClick={handleDelete}>
              <TrashIcon className="mr-2 h-4 w-4" />
              Delete
            </Button>
          </div>
        </div>

        {/* Stats */}
        {campaign.status !== 'DRAFT' && (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardContent className="p-6">
                <div className="text-2xl font-bold">{formatNumber(analytics.sent)}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Sent</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-2xl font-bold">{formatPercentage(analytics.deliveryRate)}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Delivery Rate</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-2xl font-bold">{formatPercentage(analytics.openRate)}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Open Rate</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-2xl font-bold">{formatPercentage(analytics.clickRate)}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Click Rate</div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Content */}
        <Card>
          <CardHeader>
            <CardTitle>Campaign Details</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs
              tabs={[
                {
                  label: 'Content',
                  content: (
                    <div className="space-y-4">
                      {campaign.type === 'EMAIL' && campaign.subject && (
                        <div>
                          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            Subject
                          </label>
                          <div className="mt-1 rounded-lg border border-gray-200 bg-gray-50 p-3 dark:border-gray-700 dark:bg-gray-800">
                            {campaign.subject}
                          </div>
                        </div>
                      )}
                      <div>
                        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          Content
                        </label>
                        <div className="mt-1 rounded-lg border border-gray-200 bg-gray-50 p-3 dark:border-gray-700 dark:bg-gray-800">
                          <pre className="whitespace-pre-wrap font-sans text-sm">
                            {campaign.content}
                          </pre>
                        </div>
                      </div>
                    </div>
                  ),
                },
                {
                  label: 'Settings',
                  content: (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            Type
                          </label>
                          <div className="mt-1">{campaign.type}</div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            Recipients
                          </label>
                          <div className="mt-1">{formatNumber(campaign.recipients)}</div>
                        </div>
                        {campaign.fromEmail && (
                          <div>
                            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                              From Email
                            </label>
                            <div className="mt-1">{campaign.fromEmail}</div>
                          </div>
                        )}
                        {campaign.fromName && (
                          <div>
                            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                              From Name
                            </label>
                            <div className="mt-1">{campaign.fromName}</div>
                          </div>
                        )}
                      </div>
                      {campaign.tags && campaign.tags.length > 0 && (
                        <div>
                          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            Tags
                          </label>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {campaign.tags.map((tag) => (
                              <Badge key={tag} variant="gray">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ),
                },
              ]}
            />
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
