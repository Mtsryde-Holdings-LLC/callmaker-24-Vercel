'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { PlusIcon, EnvelopeIcon, DevicePhoneMobileIcon } from '@heroicons/react/24/outline';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loading } from '@/components/ui/loading';
import { EmptyState } from '@/components/ui/empty-state';
import { campaignsApi } from '@/lib/api-client';
import { formatDate, formatNumber, getStatusColor } from '@/lib/utils';
import type { Campaign } from '@/types';

export default function CampaignsPage() {
  const [page] = useState(1); // TODO: Add pagination controls

  const { data, isLoading } = useQuery({
    queryKey: ['campaigns', page],
    queryFn: () => campaignsApi.list({ page, limit: 20 }),
  });

  const campaigns = (data?.data as Campaign[]) || [];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Campaigns</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">
              Manage your email and SMS marketing campaigns
            </p>
          </div>
          <Button onClick={() => (window.location.href = '/campaigns/new')}>
            <PlusIcon className="mr-2 h-5 w-5" />
            New Campaign
          </Button>
        </div>

        <Card>
          {isLoading ? (
            <div className="flex h-96 items-center justify-center">
              <Loading size="lg" />
            </div>
          ) : campaigns.length === 0 ? (
            <EmptyState
              icon={<EnvelopeIcon className="h-12 w-12" />}
              title="No campaigns yet"
              description="Create your first campaign to start reaching your customers"
              action={{
                label: 'Create Campaign',
                onClick: () => (window.location.href = '/campaigns/new'),
              }}
            />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Campaign</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Recipients</TableHead>
                  <TableHead>Sent</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {campaigns.map((campaign) => (
                  <TableRow key={campaign.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium text-gray-900 dark:text-white">
                          {campaign.name}
                        </div>
                        {campaign.subject && (
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {campaign.subject}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {campaign.type === 'EMAIL' ? (
                          <EnvelopeIcon className="h-5 w-5 text-gray-400" />
                        ) : (
                          <DevicePhoneMobileIcon className="h-5 w-5 text-gray-400" />
                        )}
                        {campaign.type}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(campaign.status) as any}>
                        {campaign.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{formatNumber(campaign.recipients)}</TableCell>
                    <TableCell>
                      {campaign.sentAt ? formatDate(campaign.sentAt, 'relative') : '-'}
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() =>
                          (window.location.href = `/campaigns/${campaign.id}`)
                        }
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
}
