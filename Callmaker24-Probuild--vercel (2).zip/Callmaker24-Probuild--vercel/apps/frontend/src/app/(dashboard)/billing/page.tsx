'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loading } from '@/components/ui/loading';
import { subscriptionsApi, billingApi } from '@/lib/api-client';
import { formatCurrency, formatDate } from '@/lib/utils';
import type { Subscription, Invoice } from '@/types';
import toast from 'react-hot-toast';
import {
  CreditCardIcon,
  CheckCircleIcon,
  ArrowDownTrayIcon,
} from '@heroicons/react/24/outline';

export default function BillingPage() {
  const [loading, setLoading] = useState(false);

  const { data: subscriptionData, isLoading: subscriptionLoading, refetch } = useQuery({
    queryKey: ['subscription'],
    queryFn: () => subscriptionsApi.get(),
  });

  const { data: invoicesData, isLoading: invoicesLoading } = useQuery({
    queryKey: ['invoices'],
    queryFn: () => billingApi.getInvoices(),
  });

  const subscription = subscriptionData?.data as Subscription | undefined;
  const invoices = (invoicesData?.data as Invoice[]) || [];

  const handleCancelSubscription = async () => {
    if (!confirm('Are you sure you want to cancel your subscription?')) return;

    setLoading(true);
    try {
      const response = await billingApi.cancel();

      if (response.success) {
        toast.success('Subscription will be canceled at the end of the billing period');
        refetch();
      } else {
        toast.error('Failed to cancel subscription');
      }
    } catch (error) {
      toast.error('Failed to cancel subscription');
    } finally {
      setLoading(false);
    }
  };

  const handleReactivate = async () => {
    setLoading(true);
    try {
      const response = await billingApi.reactivate();
      if (response.success) {
        toast.success('Subscription reactivated');
        refetch();
      } else {
        toast.error('Failed to reactivate subscription');
      }
    } catch (error) {
      toast.error('Failed to reactivate subscription');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadInvoice = async (invoiceId: string) => {
    try {
      const response = await billingApi.downloadInvoice(invoiceId);
      const downloadData = response.data as { downloadUrl?: string };
      if (downloadData?.downloadUrl) {
        window.open(downloadData.downloadUrl, '_blank');
      } else {
        toast.error('Failed to download invoice');
      }
    } catch (error) {
      toast.error('Failed to download invoice');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'success';
      case 'trialing':
        return 'primary';
      case 'canceled':
      case 'incomplete':
        return 'gray';
      case 'past_due':
        return 'danger';
      default:
        return 'gray';
    }
  };

  const plans = [
    {
      name: 'Starter',
      price: 49,
      priceId: 'price_starter',
      features: [
        '5,000 emails/month',
        '1,000 SMS/month',
        '1,000 customers',
        'Basic analytics',
        'Email support',
      ],
    },
    {
      name: 'Professional',
      price: 99,
      priceId: 'price_professional',
      features: [
        '25,000 emails/month',
        '5,000 SMS/month',
        '10,000 customers',
        'Advanced analytics',
        'AI chatbot',
        'Priority support',
      ],
      recommended: true,
    },
    {
      name: 'Enterprise',
      price: 299,
      priceId: 'price_enterprise',
      features: [
        'Unlimited emails',
        'Unlimited SMS',
        'Unlimited customers',
        'Custom analytics',
        'AI chatbot + IVR',
        'Dedicated support',
        'Custom integrations',
      ],
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Billing & Subscription</h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Manage your subscription and billing information
          </p>
        </div>

        {/* Current Subscription */}
        {subscriptionLoading ? (
          <div className="flex h-48 items-center justify-center">
            <Loading />
          </div>
        ) : subscription ? (
          <Card>
            <CardHeader>
              <CardTitle>Current Subscription</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-gray-900 dark:text-white">
                    {subscription.planName || 'Professional Plan'}
                  </div>
                  <div className="mt-1 text-gray-600 dark:text-gray-400">
                    {formatCurrency((subscription.amount ?? 0) / 100)}/month
                  </div>
                </div>
                <Badge variant={getStatusColor(subscription.status) as any}>
                  {subscription.status}
                </Badge>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Current Period</div>
                  <div className="mt-1 font-medium text-gray-900 dark:text-white">
                    {formatDate(subscription.currentPeriodStart)} -{' '}
                    {formatDate(subscription.currentPeriodEnd)}
                  </div>
                </div>

                <div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Next Billing Date</div>
                  <div className="mt-1 font-medium text-gray-900 dark:text-white">
                    {formatDate(subscription.currentPeriodEnd)}
                  </div>
                </div>
              </div>

              {subscription.cancelAtPeriodEnd && (
                <div className="rounded-lg bg-red-50 p-4 dark:bg-red-900/20">
                  <div className="text-sm font-medium text-red-900 dark:text-red-200">
                    Your subscription will be canceled on {formatDate(subscription.currentPeriodEnd)}
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleReactivate}
                    loading={loading}
                    className="mt-2"
                  >
                    Reactivate Subscription
                  </Button>
                </div>
              )}

              {!subscription.cancelAtPeriodEnd && subscription.status === 'ACTIVE' && (
                <div className="flex justify-end">
                  <Button
                    variant="outline"
                    onClick={handleCancelSubscription}
                    loading={loading}
                  >
                    Cancel Subscription
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Choose a Plan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                {plans.map((plan) => (
                  <div
                    key={plan.priceId}
                    className={`rounded-lg border-2 p-6 ${
                      plan.recommended
                        ? 'border-primary-600 bg-primary-50 dark:bg-primary-900/20'
                        : 'border-gray-200 dark:border-gray-700'
                    }`}
                  >
                    {plan.recommended && (
                      <Badge variant="primary" className="mb-4">
                        Recommended
                      </Badge>
                    )}
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">
                      {plan.name}
                    </div>
                    <div className="mt-2">
                      <span className="text-4xl font-bold text-gray-900 dark:text-white">
                        ${plan.price}
                      </span>
                      <span className="text-gray-600 dark:text-gray-400">/month</span>
                    </div>

                    <ul className="mt-6 space-y-3">
                      {plan.features.map((feature) => (
                        <li key={feature} className="flex items-start gap-2">
                          <CheckCircleIcon className="h-5 w-5 flex-shrink-0 text-primary-600" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">
                            {feature}
                          </span>
                        </li>
                      ))}
                    </ul>

                    <Button className="mt-6 w-full" variant={plan.recommended ? 'primary' : 'outline'}>
                      Get Started
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Payment Method */}
        <Card>
          <CardHeader>
            <CardTitle>Payment Method</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between rounded-lg border border-gray-200 p-4 dark:border-gray-700">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-800">
                  <CreditCardIcon className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                </div>
                <div>
                  <div className="font-medium text-gray-900 dark:text-white">
                    •••• •••• •••• 4242
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Expires 12/2025</div>
                </div>
              </div>
              <Button variant="outline" size="sm">
                Update
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Invoices */}
        <Card>
          <CardHeader>
            <CardTitle>Billing History</CardTitle>
          </CardHeader>
          <CardContent>
            {invoicesLoading ? (
              <div className="flex h-48 items-center justify-center">
                <Loading />
              </div>
            ) : invoices.length === 0 ? (
              <div className="py-8 text-center text-gray-500">No invoices yet</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-700">
                      <th className="pb-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">
                        Date
                      </th>
                      <th className="pb-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">
                        Description
                      </th>
                      <th className="pb-3 text-right text-sm font-medium text-gray-600 dark:text-gray-400">
                        Amount
                      </th>
                      <th className="pb-3 text-right text-sm font-medium text-gray-600 dark:text-gray-400">
                        Status
                      </th>
                      <th className="pb-3 text-right text-sm font-medium text-gray-600 dark:text-gray-400">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoices.map((invoice: any) => (
                      <tr
                        key={invoice.id}
                        className="border-b border-gray-100 dark:border-gray-800"
                      >
                        <td className="py-3 text-sm text-gray-900 dark:text-white">
                          {formatDate(invoice.date)}
                        </td>
                        <td className="py-3 text-sm text-gray-600 dark:text-gray-400">
                          {invoice.description}
                        </td>
                        <td className="py-3 text-right text-sm text-gray-900 dark:text-white">
                          {formatCurrency(invoice.amount / 100)}
                        </td>
                        <td className="py-3 text-right">
                          <Badge
                            variant={invoice.status === 'paid' ? 'success' : 'warning'}
                            size="sm"
                          >
                            {invoice.status}
                          </Badge>
                        </td>
                        <td className="py-3 text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDownloadInvoice(invoice.id)}
                          >
                            <ArrowDownTrayIcon className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
