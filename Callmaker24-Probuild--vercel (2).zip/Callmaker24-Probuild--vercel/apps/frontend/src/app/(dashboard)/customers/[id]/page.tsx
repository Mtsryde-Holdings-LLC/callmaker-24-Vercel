'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar } from '@/components/ui/avatar';
import { Tabs } from '@/components/ui/tabs';
import { Loading } from '@/components/ui/loading';
import { Input } from '@/components/ui/input';
import { customersApi } from '@/lib/api-client';
import { formatDate, getStatusColor } from '@/lib/utils';
import type { Customer } from '@/types';
import toast from 'react-hot-toast';
import { PencilIcon, TrashIcon, EnvelopeIcon, DevicePhoneMobileIcon } from '@heroicons/react/24/outline';

export default function CustomerDetailPage() {
  const params = useParams();
  const router = useRouter();
  const customerId = params?.id as string;
  const [editing, setEditing] = useState(false);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['customer', customerId],
    queryFn: () => customersApi.get(customerId),
  });

  const customer = data?.data as Customer;

  const [formData, setFormData] = useState<Partial<Customer>>({});

  useEffect(() => {
    if (customer) {
      setFormData(customer);
    }
  }, [customer]);

  const handleSave = async () => {
    try {
      const response = await customersApi.update(customerId, formData);
      if (response.success) {
        toast.success('Customer updated successfully');
        setEditing(false);
        refetch();
      } else {
        toast.error('Failed to update customer');
      }
    } catch (error) {
      toast.error('Failed to update customer');
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this customer?')) return;

    try {
      const response = await customersApi.delete(customerId);
      if (response.success) {
        toast.success('Customer deleted');
        router.push('/customers');
      } else {
        toast.error('Failed to delete customer');
      }
    } catch (error) {
      toast.error('Failed to delete customer');
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex h-96 items-center justify-center">
          <Loading size="lg" />
        </div>
      </DashboardLayout>
    );
  }

  if (!customer) {
    return (
      <DashboardLayout>
        <div className="text-center">
          <h1 className="text-2xl font-bold">Customer not found</h1>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <Avatar
              firstName={customer.firstName}
              lastName={customer.lastName}
              size="xl"
            />
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                {customer.firstName} {customer.lastName}
              </h1>
              <p className="mt-1 text-gray-600 dark:text-gray-400">{customer.email}</p>
              <div className="mt-2 flex items-center gap-2">
                <Badge variant={getStatusColor(customer.status) as any}>{customer.status}</Badge>
                {customer.emailOptIn && (
                  <Badge variant="success">
                    <EnvelopeIcon className="mr-1 h-3 w-3" />
                    Email Opt-in
                  </Badge>
                )}
                {customer.smsOptIn && (
                  <Badge variant="success">
                    <DevicePhoneMobileIcon className="mr-1 h-3 w-3" />
                    SMS Opt-in
                  </Badge>
                )}
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            {!editing ? (
              <>
                <Button variant="outline" onClick={() => setEditing(true)}>
                  <PencilIcon className="mr-2 h-4 w-4" />
                  Edit
                </Button>
                <Button variant="outline" onClick={handleDelete}>
                  <TrashIcon className="mr-2 h-4 w-4" />
                  Delete
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => setEditing(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>Save Changes</Button>
              </>
            )}
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Customer Information</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs
              tabs={[
                {
                  label: 'Details',
                  content: editing ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <Input
                          label="First Name"
                          value={formData.firstName || ''}
                          onChange={(e) =>
                            setFormData((prev) => ({ ...prev, firstName: e.target.value }))
                          }
                        />
                        <Input
                          label="Last Name"
                          value={formData.lastName || ''}
                          onChange={(e) =>
                            setFormData((prev) => ({ ...prev, lastName: e.target.value }))
                          }
                        />
                      </div>
                      <Input
                        label="Email"
                        type="email"
                        value={formData.email || ''}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, email: e.target.value }))
                        }
                      />
                      <Input
                        label="Phone Number"
                        value={formData.phoneNumber || ''}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, phoneNumber: e.target.value }))
                        }
                      />
                      <Input
                        label="Company"
                        value={formData.company || ''}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, company: e.target.value }))
                        }
                      />
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-6">
                        <div>
                          <label className="text-sm font-medium text-gray-600 dark:text-gray-400">
                            Email
                          </label>
                          <div className="mt-1 text-gray-900 dark:text-white">
                            {customer.email}
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-600 dark:text-gray-400">
                            Phone
                          </label>
                          <div className="mt-1 text-gray-900 dark:text-white">
                            {customer.phoneNumber || '-'}
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-600 dark:text-gray-400">
                            Company
                          </label>
                          <div className="mt-1 text-gray-900 dark:text-white">
                            {customer.company || '-'}
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-600 dark:text-gray-400">
                            Created
                          </label>
                          <div className="mt-1 text-gray-900 dark:text-white">
                            {formatDate(customer.createdAt, 'long')}
                          </div>
                        </div>
                      </div>
                      {customer.tags && customer.tags.length > 0 && (
                        <div>
                          <label className="text-sm font-medium text-gray-600 dark:text-gray-400">
                            Tags
                          </label>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {customer.tags.map((tag) => (
                              <Badge key={tag} variant="primary">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ),
                },
                {
                  label: 'Activity',
                  content: (
                    <div className="space-y-4">
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Recent campaign interactions and engagement history will appear here.
                      </p>
                      <div className="rounded-lg border border-gray-200 p-8 text-center dark:border-gray-800">
                        <p className="text-gray-500">No activity yet</p>
                      </div>
                    </div>
                  ),
                },
              ]}
            />
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
