'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { PlusIcon, UsersIcon, ArrowUpTrayIcon } from '@heroicons/react/24/outline';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loading } from '@/components/ui/loading';
import { EmptyState } from '@/components/ui/empty-state';
import { Avatar } from '@/components/ui/avatar';
import { customersApi } from '@/lib/api-client';
import { formatDate, getStatusColor } from '@/lib/utils';
import type { Customer } from '@/types';

export default function CustomersPage() {
  const [search, setSearch] = useState('');
  const [page] = useState(1); // TODO: Add pagination controls

  const { data, isLoading } = useQuery({
    queryKey: ['customers', page, search],
    queryFn: () => customersApi.list({ page, limit: 20, search }),
  });

  const customers = (data?.data as Customer[]) || [];

  const handleImport = async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        try {
          await customersApi.bulkImport(file);
          alert('Import started! You will receive a notification when complete.');
        } catch (error) {
          alert('Import failed. Please try again.');
        }
      }
    };
    input.click();
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Customers</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">
              Manage your customer database and segments
            </p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={handleImport}>
              <ArrowUpTrayIcon className="mr-2 h-5 w-5" />
              Import CSV
            </Button>
            <Button onClick={() => (window.location.href = '/customers/new')}>
              <PlusIcon className="mr-2 h-5 w-5" />
              Add Customer
            </Button>
          </div>
        </div>

        <Card className="p-4">
          <Input
            placeholder="Search customers..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-md"
          />
        </Card>

        <Card>
          {isLoading ? (
            <div className="flex h-96 items-center justify-center">
              <Loading size="lg" />
            </div>
          ) : customers.length === 0 ? (
            <EmptyState
              icon={<UsersIcon className="h-12 w-12" />}
              title="No customers yet"
              description="Add your first customer or import a CSV file to get started"
              action={{
                label: 'Add Customer',
                onClick: () => (window.location.href = '/customers/new'),
              }}
            />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Customer</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {customers.map((customer) => (
                  <TableRow key={customer.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar
                          firstName={customer.firstName}
                          lastName={customer.lastName}
                          size="sm"
                        />
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">
                            {customer.firstName} {customer.lastName}
                          </div>
                          {customer.company && (
                            <div className="text-sm text-gray-600 dark:text-gray-400">
                              {customer.company}
                            </div>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-600 dark:text-gray-400">
                      {customer.email}
                    </TableCell>
                    <TableCell className="text-gray-600 dark:text-gray-400">
                      {customer.phoneNumber || '-'}
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(customer.status) as any}>
                        {customer.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {customer.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="gray">
                            {tag}
                          </Badge>
                        ))}
                        {customer.tags.length > 2 && (
                          <Badge variant="gray">+{customer.tags.length - 2}</Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-600 dark:text-gray-400">
                      {formatDate(customer.createdAt, 'relative')}
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() =>
                          (window.location.href = `/customers/${customer.id}`)
                        }
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
}
