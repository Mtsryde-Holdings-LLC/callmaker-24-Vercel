'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Line, Bar, Pie } from 'react-chartjs-2';
import {
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  UsersIcon,
  HeartIcon,
  ShareIcon,
  ChatBubbleLeftIcon,
} from '@heroicons/react/24/outline';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

interface PlatformStats {
  platform: string;
  followers: number;
  engagement: number;
  posts: number;
  reach: number;
  color: string;
}

export default function SocialAnalyticsPage() {
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');

  // Mock data - in production, fetch from API
  const platformStats: PlatformStats[] = [
    {
      platform: 'Twitter',
      followers: 12500,
      engagement: 4.8,
      posts: 45,
      reach: 85000,
      color: '#1DA1F2',
    },
    {
      platform: 'LinkedIn',
      followers: 8300,
      engagement: 6.2,
      posts: 28,
      reach: 52000,
      color: '#0A66C2',
    },
    {
      platform: 'Facebook',
      followers: 15800,
      engagement: 3.5,
      posts: 38,
      reach: 95000,
      color: '#1877F2',
    },
    {
      platform: 'Instagram',
      followers: 21000,
      engagement: 7.5,
      posts: 52,
      reach: 120000,
      color: '#E4405F',
    },
  ];

  // Engagement over time data
  const engagementData = {
    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
    datasets: platformStats.map((platform) => ({
      label: platform.platform,
      data: [
        Math.floor(Math.random() * 1000) + 500,
        Math.floor(Math.random() * 1000) + 500,
        Math.floor(Math.random() * 1000) + 500,
        Math.floor(Math.random() * 1000) + 500,
      ],
      borderColor: platform.color,
      backgroundColor: platform.color + '20',
      tension: 0.4,
    })),
  };

  // Post performance data
  const postPerformanceData = {
    labels: platformStats.map((p) => p.platform),
    datasets: [
      {
        label: 'Likes',
        data: platformStats.map(() => Math.floor(Math.random() * 500) + 100),
        backgroundColor: '#10B981',
      },
      {
        label: 'Shares',
        data: platformStats.map(() => Math.floor(Math.random() * 200) + 50),
        backgroundColor: '#3B82F6',
      },
      {
        label: 'Comments',
        data: platformStats.map(() => Math.floor(Math.random() * 150) + 30),
        backgroundColor: '#F59E0B',
      },
    ],
  };

  // Platform distribution
  const platformDistributionData = {
    labels: platformStats.map((p) => p.platform),
    datasets: [
      {
        data: platformStats.map((p) => p.reach),
        backgroundColor: platformStats.map((p) => p.color),
        borderWidth: 2,
        borderColor: '#fff',
      },
    ],
  };

  // Top performing posts
  const topPosts = [
    {
      id: '1',
      platform: 'Instagram',
      content: 'Check out our latest product launch! 🚀',
      likes: 1250,
      shares: 320,
      comments: 180,
      reach: 25000,
      date: '2025-10-28',
    },
    {
      id: '2',
      platform: 'LinkedIn',
      content: 'Excited to announce our Q4 results...',
      likes: 890,
      shares: 450,
      comments: 125,
      reach: 18500,
      date: '2025-10-25',
    },
    {
      id: '3',
      platform: 'Twitter',
      content: 'New feature alert! 🎉 Now you can...',
      likes: 650,
      shares: 280,
      comments: 95,
      reach: 15000,
      date: '2025-10-22',
    },
  ];

  const totalFollowers = platformStats.reduce((sum, p) => sum + p.followers, 0);
  const avgEngagement = (
    platformStats.reduce((sum, p) => sum + p.engagement, 0) / platformStats.length
  ).toFixed(1);
  const totalPosts = platformStats.reduce((sum, p) => sum + p.posts, 0);
  const totalReach = platformStats.reduce((sum, p) => sum + p.reach, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Social Media Analytics</h1>
          <p className="mt-1 text-sm text-gray-600">
            Track performance across all your social platforms
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={timeRange === '7d' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setTimeRange('7d')}
          >
            7 Days
          </Button>
          <Button
            variant={timeRange === '30d' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setTimeRange('30d')}
          >
            30 Days
          </Button>
          <Button
            variant={timeRange === '90d' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setTimeRange('90d')}
          >
            90 Days
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Followers</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">
                {totalFollowers.toLocaleString()}
              </p>
              <div className="mt-2 flex items-center gap-1 text-sm text-green-600">
                <ArrowTrendingUpIcon className="h-4 w-4" />
                <span>+12.5% from last month</span>
              </div>
            </div>
            <div className="rounded-full bg-blue-100 p-3">
              <UsersIcon className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Engagement</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">{avgEngagement}%</p>
              <div className="mt-2 flex items-center gap-1 text-sm text-green-600">
                <ArrowTrendingUpIcon className="h-4 w-4" />
                <span>+2.1% from last month</span>
              </div>
            </div>
            <div className="rounded-full bg-pink-100 p-3">
              <HeartIcon className="h-6 w-6 text-pink-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Posts</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">{totalPosts}</p>
              <div className="mt-2 flex items-center gap-1 text-sm text-red-600">
                <ArrowTrendingDownIcon className="h-4 w-4" />
                <span>-5.2% from last month</span>
              </div>
            </div>
            <div className="rounded-full bg-purple-100 p-3">
              <ChatBubbleLeftIcon className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Reach</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">
                {(totalReach / 1000).toFixed(1)}K
              </p>
              <div className="mt-2 flex items-center gap-1 text-sm text-green-600">
                <ArrowTrendingUpIcon className="h-4 w-4" />
                <span>+18.3% from last month</span>
              </div>
            </div>
            <div className="rounded-full bg-green-100 p-3">
              <ShareIcon className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Platform Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {platformStats.map((platform) => (
          <Card key={platform.platform} className="p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-semibold text-gray-900">{platform.platform}</h3>
              <div
                className="h-3 w-3 rounded-full"
                style={{ backgroundColor: platform.color }}
              ></div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Followers</span>
                <span className="font-medium">{platform.followers.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Engagement</span>
                <span className="font-medium">{platform.engagement}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Posts</span>
                <span className="font-medium">{platform.posts}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Reach</span>
                <span className="font-medium">{(platform.reach / 1000).toFixed(1)}K</span>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Engagement Over Time */}
        <Card className="p-6">
          <h3 className="mb-4 text-lg font-semibold">Engagement Over Time</h3>
          <Line
            data={engagementData}
            options={{
              responsive: true,
              plugins: {
                legend: {
                  position: 'bottom',
                },
              },
              scales: {
                y: {
                  beginAtZero: true,
                },
              },
            }}
          />
        </Card>

        {/* Platform Distribution */}
        <Card className="p-6">
          <h3 className="mb-4 text-lg font-semibold">Reach by Platform</h3>
          <div className="mx-auto max-w-xs">
            <Pie
              data={platformDistributionData}
              options={{
                responsive: true,
                plugins: {
                  legend: {
                    position: 'bottom',
                  },
                },
              }}
            />
          </div>
        </Card>

        {/* Post Performance */}
        <Card className="p-6 lg:col-span-2">
          <h3 className="mb-4 text-lg font-semibold">Post Performance by Platform</h3>
          <Bar
            data={postPerformanceData}
            options={{
              responsive: true,
              plugins: {
                legend: {
                  position: 'bottom',
                },
              },
              scales: {
                y: {
                  beginAtZero: true,
                },
              },
            }}
          />
        </Card>
      </div>

      {/* Top Performing Posts */}
      <Card className="p-6">
        <h3 className="mb-4 text-lg font-semibold">Top Performing Posts</h3>
        <div className="space-y-4">
          {topPosts.map((post, index) => (
            <div
              key={post.id}
              className="flex items-start justify-between rounded-lg border border-gray-200 p-4"
            >
              <div className="flex-1">
                <div className="mb-2 flex items-center gap-2">
                  <span className="font-semibold text-gray-900">#{index + 1}</span>
                  <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium">
                    {post.platform}
                  </span>
                  <span className="text-sm text-gray-500">{post.date}</span>
                </div>
                <p className="mb-3 text-gray-700">{post.content}</p>
                <div className="flex gap-4 text-sm">
                  <div className="flex items-center gap-1">
                    <HeartIcon className="h-4 w-4 text-red-500" />
                    <span>{post.likes.toLocaleString()} likes</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <ShareIcon className="h-4 w-4 text-blue-500" />
                    <span>{post.shares.toLocaleString()} shares</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <ChatBubbleLeftIcon className="h-4 w-4 text-green-500" />
                    <span>{post.comments.toLocaleString()} comments</span>
                  </div>
                </div>
              </div>
              <div className="ml-4 text-right">
                <p className="text-sm text-gray-600">Reach</p>
                <p className="text-xl font-bold text-gray-900">
                  {(post.reach / 1000).toFixed(1)}K
                </p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Export Options */}
      <div className="flex justify-end gap-2">
        <Button variant="outline">Export PDF</Button>
        <Button variant="outline">Export CSV</Button>
        <Button>Generate Report</Button>
      </div>
    </div>
  );
}
