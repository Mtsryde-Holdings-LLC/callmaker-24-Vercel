'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  CheckCircleIcon,
  SparklesIcon,
  ChartBarIcon,
  PhoneIcon,
  ChatBubbleLeftRightIcon,
  EnvelopeIcon,
  DevicePhoneMobileIcon,
  UserGroupIcon,
  CurrencyDollarIcon,
  ClockIcon,
  ShieldCheckIcon,
  RocketLaunchIcon,
} from '@heroicons/react/24/outline';

export default function LandingPage() {
  const [isAnnual, setIsAnnual] = useState(false);
  const [roiInputs, setRoiInputs] = useState({
    customers: 1000,
    avgDealSize: 500,
    conversionRate: 5,
  });

  // ROI Calculator
  const calculateROI = () => {
    const monthlyRevenue = (roiInputs.customers * roiInputs.avgDealSize * roiInputs.conversionRate) / 100;
    const platformCost = 79.99; // Professional tier
    const roi = ((monthlyRevenue - platformCost) / platformCost) * 100;
    const annualSavings = monthlyRevenue * 12;

    return {
      monthlyRevenue: monthlyRevenue.toFixed(2),
      roi: roi.toFixed(0),
      annualSavings: annualSavings.toFixed(2),
      paybackPeriod: (platformCost / monthlyRevenue).toFixed(1),
    };
  };

  const roiResults = calculateROI();

  // Pricing data with 4 tiers
  const pricingTiers = [
    {
      name: 'Free Trial',
      price: 0,
      period: '30 days',
      description: 'Perfect for testing the platform',
      features: [
        '500 customers',
        '1,000 emails/month',
        '100 SMS/month',
        'Basic analytics',
        'Email support',
        'AI content generation (50/month)',
      ],
      cta: 'Start Free Trial',
      highlighted: false,
      icon: RocketLaunchIcon,
    },
    {
      name: 'Starter',
      price: 49.99,
      annualPrice: 42.49, // 15% discount
      period: 'per month',
      description: 'For small businesses getting started',
      features: [
        '5,000 customers',
        '10,000 emails/month',
        '2,000 SMS/month',
        'Advanced analytics',
        'Email & chat support',
        'AI content generation (500/month)',
        'Social media scheduling',
        '5 team members',
      ],
      cta: 'Get Started',
      highlighted: false,
      icon: ChartBarIcon,
    },
    {
      name: 'Professional',
      price: 79.99,
      annualPrice: 67.99, // 15% discount
      period: 'per month',
      description: 'For growing businesses',
      features: [
        '25,000 customers',
        '50,000 emails/month',
        '10,000 SMS/month',
        'Voice/IVR campaigns (500 mins)',
        'Full analytics & reporting',
        'Priority support',
        'AI content generation (2,000/month)',
        'Social media automation',
        'Custom templates',
        '15 team members',
        'API access',
      ],
      cta: 'Start Professional',
      highlighted: true,
      icon: SparklesIcon,
    },
    {
      name: 'Enterprise',
      price: 199.99,
      annualPrice: 169.99, // 15% discount
      period: 'per month',
      description: 'For large organizations',
      features: [
        'Unlimited customers',
        'Unlimited emails',
        'Unlimited SMS',
        'Unlimited voice campaigns',
        'Advanced AI & automation',
        'Dedicated success manager',
        'White-label options',
        'Custom integrations',
        'SLA guarantee',
        'Unlimited team members',
        'Advanced security',
        'Custom training',
      ],
      cta: 'Contact Sales',
      highlighted: false,
      icon: ShieldCheckIcon,
    },
  ];

  const features = [
    {
      name: 'AI-Powered Content Generation',
      description: 'Generate engaging social media posts, emails, and SMS campaigns with GPT-4 powered AI.',
      icon: SparklesIcon,
      color: 'bg-purple-500',
    },
    {
      name: 'SMS Marketing',
      description: 'Send personalized bulk SMS, manage two-way conversations, and handle opt-ins/outs automatically.',
      icon: DevicePhoneMobileIcon,
      color: 'bg-blue-500',
    },
    {
      name: 'IVR/Voice Campaigns',
      description: 'Launch outbound voice campaigns with Amazon Connect. Build custom IVR flows with drag-and-drop.',
      icon: PhoneIcon,
      color: 'bg-green-500',
    },
    {
      name: 'Email Campaigns',
      description: 'Design beautiful emails, segment your audience, and track every open and click in real-time.',
      icon: EnvelopeIcon,
      color: 'bg-red-500',
    },
    {
      name: 'Social Media Automation',
      description: 'Schedule and publish to Twitter, LinkedIn, Facebook, and Instagram from one dashboard.',
      icon: ChatBubbleLeftRightIcon,
      color: 'bg-pink-500',
    },
    {
      name: 'Customer Management',
      description: 'Organize contacts, import/export data, create segments, and track customer journeys.',
      icon: UserGroupIcon,
      color: 'bg-indigo-500',
    },
    {
      name: 'Advanced Analytics',
      description: 'Real-time dashboards, campaign performance metrics, ROI tracking, and custom reports.',
      icon: ChartBarIcon,
      color: 'bg-yellow-500',
    },
    {
      name: 'AI Chatbot',
      description: 'Automated customer support with intelligent escalation to human agents when needed.',
      icon: ChatBubbleLeftRightIcon,
      color: 'bg-teal-500',
    },
  ];

  const stats = [
    { label: 'Active Users', value: '50,000+' },
    { label: 'Messages Sent', value: '10M+' },
    { label: 'Average ROI', value: '500%' },
    { label: 'Customer Satisfaction', value: '98%' },
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Marketing Director',
      company: 'TechCorp Inc',
      content: 'Callmaker24 transformed our marketing operations. We saw a 300% increase in customer engagement within 3 months.',
    },
    {
      name: 'Michael Chen',
      role: 'CEO',
      company: 'Growth Solutions',
      content: 'The AI content generation alone saved us 20 hours per week. The ROI calculator was spot on!',
    },
    {
      name: 'Emily Rodriguez',
      role: 'Sales Manager',
      company: 'Retail Plus',
      content: 'The voice campaigns and SMS automation helped us reach 10x more customers with the same team size.',
    },
  ];

  return (
    <div className="bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/90 backdrop-blur-md z-50 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/" className="text-2xl font-bold text-indigo-600">
                Callmaker24
              </Link>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-700 hover:text-indigo-600">Features</a>
              <a href="#pricing" className="text-gray-700 hover:text-indigo-600">Pricing</a>
              <a href="#roi" className="text-gray-700 hover:text-indigo-600">ROI Calculator</a>
              <Link href="/login" className="text-gray-700 hover:text-indigo-600">
                Sign In
              </Link>
              <Link
                href="/signup"
                className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"
              >
                Start Free Trial
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-indigo-50 via-white to-purple-50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 mb-6">
              All-in-One Marketing
              <span className="text-indigo-600"> Automation Platform</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
              SMS, Voice, Email, Social Media & AI - Everything you need to scale your marketing in one powerful platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link
                href="/signup"
                className="bg-indigo-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition inline-flex items-center justify-center"
              >
                Start Free 30-Day Trial
                <RocketLaunchIcon className="ml-2 h-5 w-5" />
              </Link>
              <a
                href="#roi"
                className="bg-white text-indigo-600 border-2 border-indigo-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-indigo-50 transition inline-flex items-center justify-center"
              >
                Calculate Your ROI
                <CurrencyDollarIcon className="ml-2 h-5 w-5" />
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-4xl font-bold text-indigo-600">{stat.value}</div>
                  <div className="text-gray-600 mt-2">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Everything You Need to <span className="text-indigo-600">Succeed</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Powerful features designed to help you engage customers across every channel
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-xl border border-gray-200 hover:shadow-xl transition-shadow"
              >
                <div className={`${feature.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.name}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ROI Calculator Section */}
      <section id="roi" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-indigo-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Calculate Your ROI
            </h2>
            <p className="text-xl text-indigo-100">
              See how much you can save and earn with Callmaker24
            </p>
          </motion.div>

          <div className="bg-white rounded-2xl shadow-2xl p-8 text-gray-900 max-w-5xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Inputs */}
              <div className="space-y-6">
                <h3 className="text-2xl font-bold mb-6">Your Business Info</h3>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Number of Customers
                  </label>
                  <input
                    type="number"
                    value={roiInputs.customers}
                    onChange={(e) => setRoiInputs({ ...roiInputs, customers: parseInt(e.target.value) || 0 })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Average Deal Size ($)
                  </label>
                  <input
                    type="number"
                    value={roiInputs.avgDealSize}
                    onChange={(e) => setRoiInputs({ ...roiInputs, avgDealSize: parseInt(e.target.value) || 0 })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Expected Conversion Rate (%)
                  </label>
                  <input
                    type="number"
                    value={roiInputs.conversionRate}
                    onChange={(e) => setRoiInputs({ ...roiInputs, conversionRate: parseInt(e.target.value) || 0 })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Results */}
              <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-8 rounded-xl">
                <h3 className="text-2xl font-bold mb-6">Your Potential Results</h3>

                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-lg">
                    <div className="text-sm text-gray-600">Monthly Revenue Increase</div>
                    <div className="text-3xl font-bold text-indigo-600">
                      ${roiResults.monthlyRevenue}
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg">
                    <div className="text-sm text-gray-600">Return on Investment</div>
                    <div className="text-3xl font-bold text-green-600">
                      {roiResults.roi}%
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg">
                    <div className="text-sm text-gray-600">Annual Savings</div>
                    <div className="text-3xl font-bold text-purple-600">
                      ${roiResults.annualSavings}
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg">
                    <div className="text-sm text-gray-600">Payback Period</div>
                    <div className="text-3xl font-bold text-orange-600">
                      {roiResults.paybackPeriod} months
                    </div>
                  </div>
                </div>

                <Link
                  href="/signup"
                  className="mt-6 w-full bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition inline-flex items-center justify-center"
                >
                  Start Your Free Trial
                  <RocketLaunchIcon className="ml-2 h-5 w-5" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Simple, Transparent <span className="text-indigo-600">Pricing</span>
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Choose the plan that fits your business needs
            </p>

            {/* Annual/Monthly Toggle */}
            <div className="flex items-center justify-center gap-4 mb-8">
              <span className={`text-lg font-medium ${!isAnnual ? 'text-indigo-600' : 'text-gray-500'}`}>
                Monthly
              </span>
              <button
                onClick={() => setIsAnnual(!isAnnual)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  isAnnual ? 'bg-indigo-600' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    isAnnual ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
              <span className={`text-lg font-medium ${isAnnual ? 'text-indigo-600' : 'text-gray-500'}`}>
                Annual
                <span className="ml-2 text-sm bg-green-100 text-green-800 px-2 py-1 rounded-full">
                  Save 15%
                </span>
              </span>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {pricingTiers.map((tier, index) => (
              <motion.div
                key={tier.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`bg-white rounded-2xl shadow-lg p-8 ${
                  tier.highlighted ? 'ring-4 ring-indigo-600 scale-105' : ''
                }`}
              >
                {tier.highlighted && (
                  <div className="bg-indigo-600 text-white text-sm font-semibold px-4 py-1 rounded-full inline-block mb-4">
                    Most Popular
                  </div>
                )}

                <div className={`${tier.highlighted ? 'bg-indigo-600' : 'bg-gray-100'} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                  <tier.icon className={`h-6 w-6 ${tier.highlighted ? 'text-white' : 'text-gray-600'}`} />
                </div>

                <h3 className="text-2xl font-bold text-gray-900 mb-2">{tier.name}</h3>
                <p className="text-gray-600 mb-6">{tier.description}</p>

                <div className="mb-6">
                  {tier.price === 0 ? (
                    <div className="text-4xl font-bold text-gray-900">Free</div>
                  ) : (
                    <>
                      <div className="text-4xl font-bold text-gray-900">
                        ${isAnnual ? tier.annualPrice : tier.price}
                        <span className="text-lg font-normal text-gray-600">/{tier.period}</span>
                      </div>
                      {isAnnual && tier.annualPrice && (
                        <div className="text-sm text-green-600 mt-1">
                          Save ${((tier.price - tier.annualPrice!) * 12).toFixed(2)}/year
                        </div>
                      )}
                    </>
                  )}
                </div>

                <Link
                  href={tier.name === 'Enterprise' ? '/contact' : '/signup'}
                  className={`w-full py-3 px-6 rounded-lg font-semibold transition mb-6 inline-block text-center ${
                    tier.highlighted
                      ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  }`}
                >
                  {tier.cta}
                </Link>

                <ul className="space-y-3">
                  {tier.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start">
                      <CheckCircleIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-600 mb-4">All plans include:</p>
            <div className="flex flex-wrap justify-center gap-6 text-sm text-gray-600">
              <div className="flex items-center">
                <ClockIcon className="h-5 w-5 text-indigo-600 mr-2" />
                24/7 Platform Access
              </div>
              <div className="flex items-center">
                <ShieldCheckIcon className="h-5 w-5 text-indigo-600 mr-2" />
                Bank-Level Security
              </div>
              <div className="flex items-center">
                <CheckCircleIcon className="h-5 w-5 text-indigo-600 mr-2" />
                99.9% Uptime SLA
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Loved by <span className="text-indigo-600">Marketers Worldwide</span>
            </h2>
            <p className="text-xl text-gray-600">
              See what our customers are saying about Callmaker24
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gray-50 rounded-xl p-8"
              >
                <p className="text-gray-600 mb-6 italic">&quot;{testimonial.content}&quot;</p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold text-lg">
                    {testimonial.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div className="ml-4">
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-600">
                      {testimonial.role} at {testimonial.company}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Ready to Transform Your Marketing?
            </h2>
            <p className="text-xl mb-8 text-indigo-100">
              Join 50,000+ businesses using Callmaker24 to scale their growth
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/signup"
                className="bg-white text-indigo-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition inline-flex items-center justify-center"
              >
                Start Free 30-Day Trial
                <RocketLaunchIcon className="ml-2 h-5 w-5" />
              </Link>
              <Link
                href="/contact"
                className="bg-indigo-500 text-white border-2 border-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-indigo-400 transition inline-flex items-center justify-center"
              >
                Schedule a Demo
              </Link>
            </div>
            <p className="mt-6 text-sm text-indigo-100">
              No credit card required • Cancel anytime • 24/7 support
            </p>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-white text-lg font-bold mb-4">Callmaker24</h3>
              <p className="text-sm">
                All-in-one marketing automation platform for modern businesses.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#features" className="hover:text-white">Features</a></li>
                <li><a href="#pricing" className="hover:text-white">Pricing</a></li>
                <li><a href="#roi" className="hover:text-white">ROI Calculator</a></li>
                <li><Link href="/signup" className="hover:text-white">Sign Up</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="/about" className="hover:text-white">About</a></li>
                <li><a href="/contact" className="hover:text-white">Contact</a></li>
                <li><a href="/careers" className="hover:text-white">Careers</a></li>
                <li><a href="/blog" className="hover:text-white">Blog</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="/privacy" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="/terms" className="hover:text-white">Terms of Service</a></li>
                <li><a href="/security" className="hover:text-white">Security</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm">
            <p>&copy; 2025 Callmaker24. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
