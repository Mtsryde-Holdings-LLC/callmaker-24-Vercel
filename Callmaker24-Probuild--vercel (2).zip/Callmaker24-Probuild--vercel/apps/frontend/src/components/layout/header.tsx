'use client';

import { BellIcon, MoonIcon, SunIcon } from '@heroicons/react/24/outline';
import { useTheme } from 'next-themes';
import { useAuth } from '@/lib/auth-context';
import { Avatar } from '@/components/ui/avatar';
import { Dropdown } from '@/components/ui/dropdown';
import { Button } from '@/components/ui/button';

export function Header() {
  const { theme, setTheme } = useTheme();
  const { user, logout } = useAuth();

  const userMenuItems = [
    {
      label: 'Profile',
      onClick: () => {
        window.location.href = '/settings/profile';
      },
    },
    {
      label: 'Settings',
      onClick: () => {
        window.location.href = '/settings';
      },
    },
    {
      label: 'Sign out',
      onClick: logout,
      danger: true,
    },
  ];

  return (
    <header className="fixed right-0 top-0 z-40 h-16 border-b border-gray-200 bg-white pl-64 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex h-full items-center justify-between px-6">
        <div className="flex-1">
          {/* Search bar or breadcrumbs can go here */}
        </div>

        <div className="flex items-center gap-4">
          {/* Theme toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          >
            {theme === 'dark' ? (
              <SunIcon className="h-5 w-5" />
            ) : (
              <MoonIcon className="h-5 w-5" />
            )}
          </Button>

          {/* Notifications */}
          <Button variant="ghost" size="icon">
            <BellIcon className="h-5 w-5" />
          </Button>

          {/* User menu */}
          {user && (
            <Dropdown
              trigger={
                <button className="flex items-center gap-3 rounded-lg p-1 hover:bg-gray-100 dark:hover:bg-gray-800">
                  <Avatar
                    firstName={user.firstName}
                    lastName={user.lastName}
                    src={user.avatar}
                    size="sm"
                  />
                </button>
              }
              items={userMenuItems}
              align="right"
            />
          )}
        </div>
      </div>
    </header>
  );
}
