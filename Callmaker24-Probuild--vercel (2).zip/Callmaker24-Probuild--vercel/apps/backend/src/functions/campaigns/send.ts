/**
 * Lambda function to send a campaign
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { campaignsTable, customersTable, messagesTable } from '../../lib/database';
import { sendEmail } from '../../lib/ses';
import { sendSMS } from '../../lib/sns';
import { v4 as uuidv4 } from 'uuid';

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const campaignId = event.pathParameters?.id;

    if (!campaignId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Campaign ID is required',
          },
        }),
      };
    }

    // Get tenant ID
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    // Get campaign
    const campaign = await campaignsTable.get({ id: campaignId, tenantId });

    if (!campaign) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Campaign not found',
          },
        }),
      };
    }

    // Get customers based on segments
    let customers: any[] = [];

    if (campaign.segments && campaign.segments.length > 0) {
      // Query customers by segments
      for (const _segmentId of campaign.segments) {
        const segmentCustomers = await customersTable.query(
          'tenantId = :tenantId',
          { ':tenantId': tenantId }
        );
        customers.push(...segmentCustomers);
      }
    } else {
      // Get all active customers
      customers = await customersTable.scan('status = :status', { ':status': 'ACTIVE' });
    }

    // Filter by opt-in status
    if (campaign.type === 'EMAIL') {
      customers = customers.filter((c) => c.emailOptIn);
    } else if (campaign.type === 'SMS') {
      customers = customers.filter((c) => c.smsOptIn && c.phoneNumber);
    }

    // Update campaign status
    await campaignsTable.update(
      { id: campaignId, tenantId },
      {
        status: 'SENDING',
        sentAt: new Date().toISOString(),
        recipients: customers.length,
        updatedAt: new Date().toISOString(),
      }
    );

    // Send messages
    const sendPromises = customers.map(async (customer) => {
      const messageId = uuidv4();

      try {
        if (campaign.type === 'EMAIL') {
          // Replace personalization tokens
          const personalizedContent = replaceTokens(campaign.htmlContent || campaign.content, customer);
          const personalizedSubject = replaceTokens(campaign.subject, customer);

          const result = await sendEmail({
            to: [customer.email],
            from: campaign.fromEmail || process.env.SES_FROM_EMAIL!,
            fromName: campaign.fromName || process.env.SES_FROM_NAME,
            subject: personalizedSubject,
            htmlBody: personalizedContent,
            replyTo: campaign.replyToEmail,
          });

          // Store message record
          await messagesTable.put({
            id: messageId,
            campaignId,
            customerId: customer.id,
            type: 'EMAIL',
            subject: personalizedSubject,
            content: personalizedContent,
            status: 'SENT',
            sentAt: new Date().toISOString(),
            metadata: {
              messageId: result.messageId,
            },
            tenantId,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
        } else if (campaign.type === 'SMS') {
          // Replace personalization tokens
          const personalizedContent = replaceTokens(campaign.content, customer);

          const result = await sendSMS({
            phoneNumber: customer.phoneNumber,
            message: personalizedContent,
          });

          // Store message record
          await messagesTable.put({
            id: messageId,
            campaignId,
            customerId: customer.id,
            type: 'SMS',
            content: personalizedContent,
            status: 'SENT',
            sentAt: new Date().toISOString(),
            metadata: {
              messageId: result.messageId,
            },
            tenantId,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
        }

        return { success: true, customerId: customer.id };
      } catch (error: any) {
        console.error(`Error sending to customer ${customer.id}:`, error);

        // Store failed message
        await messagesTable.put({
          id: messageId,
          campaignId,
          customerId: customer.id,
          type: campaign.type,
          content: campaign.content,
          status: 'FAILED',
          error: error.message,
          tenantId,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });

        return { success: false, customerId: customer.id, error: error.message };
      }
    });

    // Wait for all sends to complete
    const results = await Promise.allSettled(sendPromises);

    const successful = results.filter((r) => r.status === 'fulfilled' && r.value.success).length;
    const failed = results.length - successful;

    // Update campaign with final status
    await campaignsTable.update(
      { id: campaignId, tenantId },
      {
        status: 'SENT',
        updatedAt: new Date().toISOString(),
        analytics: {
          sent: successful,
          failed,
        },
      }
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          campaignId,
          sent: successful,
          failed,
          total: customers.length,
        },
      }),
    };
  } catch (error: any) {
    console.error('Error sending campaign:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: error.message || 'An error occurred while sending the campaign',
        },
      }),
    };
  }
};

function replaceTokens(content: string, customer: any): string {
  return content
    .replace(/\{\{firstName\}\}/g, customer.firstName || '')
    .replace(/\{\{lastName\}\}/g, customer.lastName || '')
    .replace(/\{\{email\}\}/g, customer.email || '')
    .replace(/\{\{company\}\}/g, customer.company || '');
}
