import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const campaignsTable = process.env.CAMPAIGNS_TABLE_NAME!;
const messagesTable = process.env.MESSAGES_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const campaignId = event.pathParameters?.id;

    if (!tenantId || !campaignId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Campaign ID are required',
          },
        }),
      };
    }

    // Get campaign
    const campaign = await dynamoDb.get({
      TableName: campaignsTable,
      Key: { id: campaignId, tenantId },
    });

    if (!campaign.Item) {
      return {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Campaign not found',
          },
        }),
      };
    }

    // Get all messages for this campaign
    const messagesResult = await dynamoDb.query({
      TableName: messagesTable,
      IndexName: 'CampaignIndex',
      KeyConditionExpression: '#campaignId = :campaignId',
      ExpressionAttributeNames: {
        '#campaignId': 'campaignId',
      },
      ExpressionAttributeValues: {
        ':campaignId': campaignId,
      },
    });

    const messages = messagesResult.Items || [];

    // Calculate analytics
    const totalSent = messages.length;
    const delivered = messages.filter((m) => m.status === 'DELIVERED').length;
    const opened = messages.filter((m) => m.openedAt).length;
    const clicked = messages.filter((m) => m.clickedAt).length;
    const bounced = messages.filter((m) => m.status === 'BOUNCED').length;
    const complained = messages.filter((m) => m.status === 'COMPLAINED').length;
    const unsubscribed = messages.filter((m) => m.unsubscribedAt).length;

    const deliveryRate = totalSent > 0 ? delivered / totalSent : 0;
    const openRate = delivered > 0 ? opened / delivered : 0;
    const clickRate = delivered > 0 ? clicked / delivered : 0;
    const bounceRate = totalSent > 0 ? bounced / totalSent : 0;
    const complaintRate = totalSent > 0 ? complained / totalSent : 0;
    const unsubscribeRate = delivered > 0 ? unsubscribed / delivered : 0;
    const clickThroughRate = opened > 0 ? clicked / opened : 0;

    // Calculate engagement over time (hourly buckets)
    const engagementTimeline: Record<string, { opens: number; clicks: number }> = {};

    messages.forEach((message) => {
      if (message.openedAt) {
        const hour = new Date(message.openedAt).toISOString().slice(0, 13);
        if (!engagementTimeline[hour]) {
          engagementTimeline[hour] = { opens: 0, clicks: 0 };
        }
        engagementTimeline[hour].opens++;
      }

      if (message.clickedAt) {
        const hour = new Date(message.clickedAt).toISOString().slice(0, 13);
        if (!engagementTimeline[hour]) {
          engagementTimeline[hour] = { opens: 0, clicks: 0 };
        }
        engagementTimeline[hour].clicks++;
      }
    });

    // Convert timeline to sorted array
    const timeline = Object.entries(engagementTimeline)
      .map(([timestamp, data]) => ({
        timestamp,
        opens: data.opens,
        clicks: data.clicks,
      }))
      .sort((a, b) => a.timestamp.localeCompare(b.timestamp));

    // Calculate click heatmap (which links were clicked)
    const linkClicks: Record<string, number> = {};
    messages.forEach((message) => {
      if (message.clickedLinks && Array.isArray(message.clickedLinks)) {
        message.clickedLinks.forEach((link: string) => {
          linkClicks[link] = (linkClicks[link] || 0) + 1;
        });
      }
    });

    const topLinks = Object.entries(linkClicks)
      .map(([url, clicks]) => ({ url, clicks }))
      .sort((a, b) => b.clicks - a.clicks)
      .slice(0, 10);

    // Calculate device/client breakdown
    const devices: Record<string, number> = {};
    const emailClients: Record<string, number> = {};

    messages.forEach((message) => {
      if (message.metadata?.device) {
        devices[message.metadata.device] = (devices[message.metadata.device] || 0) + 1;
      }
      if (message.metadata?.emailClient) {
        emailClients[message.metadata.emailClient] =
          (emailClients[message.metadata.emailClient] || 0) + 1;
      }
    });

    // Calculate geographic distribution
    const locations: Record<string, number> = {};
    messages.forEach((message) => {
      if (message.metadata?.country) {
        locations[message.metadata.country] = (locations[message.metadata.country] || 0) + 1;
      }
    });

    const analytics = {
      campaignId,
      campaignName: campaign.Item.name,
      campaignType: campaign.Item.type,
      sentAt: campaign.Item.sentAt,
      summary: {
        totalSent,
        delivered,
        opened,
        clicked,
        bounced,
        complained,
        unsubscribed,
      },
      rates: {
        deliveryRate,
        openRate,
        clickRate,
        bounceRate,
        complaintRate,
        unsubscribeRate,
        clickThroughRate,
      },
      timeline,
      topLinks,
      devices: Object.entries(devices).map(([name, count]) => ({ name, count })),
      emailClients: Object.entries(emailClients).map(([name, count]) => ({ name, count })),
      locations: Object.entries(locations)
        .map(([country, count]) => ({ country, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10),
    };

    // Update campaign analytics in DynamoDB
    await dynamoDb.update({
      TableName: campaignsTable,
      Key: { id: campaignId, tenantId },
      UpdateExpression: 'SET #analytics = :analytics, #updatedAt = :updatedAt',
      ExpressionAttributeNames: {
        '#analytics': 'analytics',
        '#updatedAt': 'updatedAt',
      },
      ExpressionAttributeValues: {
        ':analytics': analytics,
        ':updatedAt': new Date().toISOString(),
      },
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: analytics,
      }),
    };
  } catch (error) {
    console.error('Error calculating campaign analytics:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to calculate campaign analytics',
        },
      }),
    };
  }
};
