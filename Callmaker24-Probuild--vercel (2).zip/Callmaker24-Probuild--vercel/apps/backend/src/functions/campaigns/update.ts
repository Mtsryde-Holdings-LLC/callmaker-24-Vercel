import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const campaignsTable = process.env.CAMPAIGNS_TABLE_NAME!;

interface UpdateCampaignRequest {
  name?: string;
  subject?: string;
  content?: string;
  htmlContent?: string;
  fromEmail?: string;
  fromName?: string;
  segments?: string[];
  scheduledAt?: string;
  metadata?: Record<string, any>;
}

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const campaignId = event.pathParameters?.id;

    if (!tenantId || !campaignId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Campaign ID are required',
          },
        }),
      };
    }

    const body: UpdateCampaignRequest = JSON.parse(event.body || '{}');

    // Get existing campaign
    const existingCampaign = await dynamoDb.get({
      TableName: campaignsTable,
      Key: { id: campaignId, tenantId },
    });

    if (!existingCampaign.Item) {
      return {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Campaign not found',
          },
        }),
      };
    }

    // Can't update campaigns that are already sent
    if (['SENDING', 'SENT'].includes(existingCampaign.Item.status)) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_STATE',
            message: 'Cannot update a campaign that has been sent',
          },
        }),
      };
    }

    // Build update expression
    const updateExpressions: string[] = [];
    const expressionAttributeNames: Record<string, string> = {};
    const expressionAttributeValues: Record<string, any> = {};

    if (body.name !== undefined) {
      updateExpressions.push('#name = :name');
      expressionAttributeNames['#name'] = 'name';
      expressionAttributeValues[':name'] = body.name;
    }

    if (body.subject !== undefined) {
      updateExpressions.push('#subject = :subject');
      expressionAttributeNames['#subject'] = 'subject';
      expressionAttributeValues[':subject'] = body.subject;
    }

    if (body.content !== undefined) {
      updateExpressions.push('#content = :content');
      expressionAttributeNames['#content'] = 'content';
      expressionAttributeValues[':content'] = body.content;
    }

    if (body.htmlContent !== undefined) {
      updateExpressions.push('#htmlContent = :htmlContent');
      expressionAttributeNames['#htmlContent'] = 'htmlContent';
      expressionAttributeValues[':htmlContent'] = body.htmlContent;
    }

    if (body.fromEmail !== undefined) {
      updateExpressions.push('#fromEmail = :fromEmail');
      expressionAttributeNames['#fromEmail'] = 'fromEmail';
      expressionAttributeValues[':fromEmail'] = body.fromEmail;
    }

    if (body.fromName !== undefined) {
      updateExpressions.push('#fromName = :fromName');
      expressionAttributeNames['#fromName'] = 'fromName';
      expressionAttributeValues[':fromName'] = body.fromName;
    }

    if (body.segments !== undefined) {
      updateExpressions.push('#segments = :segments');
      expressionAttributeNames['#segments'] = 'segments';
      expressionAttributeValues[':segments'] = body.segments;
    }

    if (body.scheduledAt !== undefined) {
      updateExpressions.push('#scheduledAt = :scheduledAt');
      expressionAttributeNames['#scheduledAt'] = 'scheduledAt';
      expressionAttributeValues[':scheduledAt'] = body.scheduledAt;

      // Update status to SCHEDULED if scheduledAt is set
      updateExpressions.push('#status = :status');
      expressionAttributeNames['#status'] = 'status';
      expressionAttributeValues[':status'] = 'SCHEDULED';
    }

    if (body.metadata !== undefined) {
      updateExpressions.push('#metadata = :metadata');
      expressionAttributeNames['#metadata'] = 'metadata';
      expressionAttributeValues[':metadata'] = body.metadata;
    }

    // Always update updatedAt
    updateExpressions.push('#updatedAt = :updatedAt');
    expressionAttributeNames['#updatedAt'] = 'updatedAt';
    expressionAttributeValues[':updatedAt'] = new Date().toISOString();

    if (updateExpressions.length === 1) {
      // Only updatedAt would be updated, meaning no actual changes
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'No fields to update',
          },
        }),
      };
    }

    // Update campaign
    const result = await dynamoDb.update({
      TableName: campaignsTable,
      Key: { id: campaignId, tenantId },
      UpdateExpression: `SET ${updateExpressions.join(', ')}`,
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
      ReturnValues: 'ALL_NEW',
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: result.Attributes,
      }),
    };
  } catch (error) {
    console.error('Error updating campaign:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to update campaign',
        },
      }),
    };
  }
};
