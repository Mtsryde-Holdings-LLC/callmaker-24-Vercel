import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import { v4 as uuidv4 } from 'uuid';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const campaignsTable = process.env.CAMPAIGNS_TABLE_NAME!;

interface CreateCampaignRequest {
  name: string;
  type: 'EMAIL' | 'SMS';
  subject?: string;
  content: string;
  htmlContent?: string;
  fromEmail?: string;
  fromName?: string;
  segments?: string[];
  scheduledAt?: string;
  metadata?: Record<string, any>;
}

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const userId = event.requestContext.authorizer?.claims?.sub;

    if (!tenantId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'MISSING_TENANT_ID',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    const body: CreateCampaignRequest = JSON.parse(event.body || '{}');

    // Validation
    if (!body.name || !body.type || !body.content) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Name, type, and content are required',
          },
        }),
      };
    }

    if (body.type === 'EMAIL' && !body.subject) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Subject is required for email campaigns',
          },
        }),
      };
    }

    // Create campaign
    const campaignId = uuidv4();
    const now = new Date().toISOString();

    const campaign = {
      id: campaignId,
      tenantId,
      name: body.name,
      type: body.type,
      subject: body.subject,
      content: body.content,
      htmlContent: body.htmlContent,
      fromEmail: body.fromEmail || process.env.DEFAULT_FROM_EMAIL,
      fromName: body.fromName || process.env.DEFAULT_FROM_NAME,
      status: body.scheduledAt ? 'SCHEDULED' : 'DRAFT',
      segments: body.segments || [],
      scheduledAt: body.scheduledAt,
      metadata: body.metadata || {},
      createdBy: userId,
      createdAt: now,
      updatedAt: now,
    };

    await dynamoDb.put({
      TableName: campaignsTable,
      Item: campaign,
    });

    // If scheduled, create EventBridge rule
    if (body.scheduledAt) {
      // TODO: Create EventBridge rule to trigger campaign at scheduledAt
      console.log(`Campaign ${campaignId} scheduled for ${body.scheduledAt}`);
    }

    return {
      statusCode: 201,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: campaign,
      }),
    };
  } catch (error) {
    console.error('Error creating campaign:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to create campaign',
        },
      }),
    };
  }
};
