import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const campaignsTable = process.env.CAMPAIGNS_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const campaignId = event.pathParameters?.id;

    if (!tenantId || !campaignId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Campaign ID are required',
          },
        }),
      };
    }

    // Get existing campaign
    const existingCampaign = await dynamoDb.get({
      TableName: campaignsTable,
      Key: { id: campaignId, tenantId },
    });

    if (!existingCampaign.Item) {
      return {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Campaign not found',
          },
        }),
      };
    }

    // Can't delete campaigns that are currently sending
    if (existingCampaign.Item.status === 'SENDING') {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_STATE',
            message: 'Cannot delete a campaign that is currently sending',
          },
        }),
      };
    }

    // Soft delete by updating status
    await dynamoDb.update({
      TableName: campaignsTable,
      Key: { id: campaignId, tenantId },
      UpdateExpression: 'SET #status = :status, #deletedAt = :deletedAt, #updatedAt = :updatedAt',
      ExpressionAttributeNames: {
        '#status': 'status',
        '#deletedAt': 'deletedAt',
        '#updatedAt': 'updatedAt',
      },
      ExpressionAttributeValues: {
        ':status': 'DELETED',
        ':deletedAt': new Date().toISOString(),
        ':updatedAt': new Date().toISOString(),
      },
    });

    // Note: In production, you might want to:
    // 1. Delete associated messages (or mark them as deleted)
    // 2. Cancel any scheduled EventBridge rules
    // 3. Archive campaign data to S3 for compliance

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: {
          id: campaignId,
          message: 'Campaign deleted successfully',
        },
      }),
    };
  } catch (error) {
    console.error('Error deleting campaign:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to delete campaign',
        },
      }),
    };
  }
};
