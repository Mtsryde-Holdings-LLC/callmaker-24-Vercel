/**
 * Lambda function to list campaigns with pagination and filtering
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { campaignsTable } from '../../lib/database';

export const handler: APIGatewayProxyHandler = async (event) => {
  console.log('Campaign list function invoked');
  console.log('Headers:', JSON.stringify(event.headers, null, 2));
  
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    console.log('Extracted tenantId:', tenantId);

    if (!tenantId) {
      return {
        statusCode: 401,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    // Parse query parameters
    const params = event.queryStringParameters || {};
    const page = parseInt(params.page || '1');
    const limit = parseInt(params.limit || '20');
    const type = params.type;
    const status = params.status;

    // Build filter expression
    let filterExpression = 'tenantId = :tenantId';
    const expressionValues: Record<string, any> = { ':tenantId': tenantId };

    if (type) {
      filterExpression += ' AND #type = :type';
      expressionValues[':type'] = type;
    }

    if (status) {
      filterExpression += ' AND #status = :status';
      expressionValues[':status'] = status;
    }

    // Get campaigns
    let campaigns = await campaignsTable.scan(filterExpression, expressionValues);

    // Sort by created date (newest first)
    campaigns.sort((a: any, b: any) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    // Paginate
    const total = campaigns.length;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedCampaigns = campaigns.slice(startIndex, endIndex);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: paginatedCampaigns,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      }),
    };
  } catch (error: any) {
    console.error('Error listing campaigns:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: error.message || 'An error occurred while fetching campaigns',
        },
      }),
    };
  }
};
