import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import {
  EventBridgeClient,
  PutRuleCommand,
  PutTargetsCommand,
} from '@aws-sdk/client-eventbridge';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const eventBridge = new EventBridgeClient({});
const campaignsTable = process.env.CAMPAIGNS_TABLE_NAME!;
const sendCampaignLambdaArn = process.env.SEND_CAMPAIGN_LAMBDA_ARN!;

interface ScheduleCampaignRequest {
  scheduledAt: string;
  timezone?: string;
}

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const campaignId = event.pathParameters?.id;

    if (!tenantId || !campaignId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Campaign ID are required',
          },
        }),
      };
    }

    const body: ScheduleCampaignRequest = JSON.parse(event.body || '{}');

    if (!body.scheduledAt) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'scheduledAt is required',
          },
        }),
      };
    }

    // Validate scheduledAt is in the future
    const scheduledDate = new Date(body.scheduledAt);
    if (scheduledDate <= new Date()) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'scheduledAt must be in the future',
          },
        }),
      };
    }

    // Get existing campaign
    const existingCampaign = await dynamoDb.get({
      TableName: campaignsTable,
      Key: { id: campaignId, tenantId },
    });

    if (!existingCampaign.Item) {
      return {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Campaign not found',
          },
        }),
      };
    }

    // Can't schedule campaigns that have already been sent
    if (['SENDING', 'SENT'].includes(existingCampaign.Item.status)) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_STATE',
            message: 'Cannot schedule a campaign that has already been sent',
          },
        }),
      };
    }

    // Create EventBridge rule
    const ruleName = `campaign-${campaignId}`;
    const scheduleExpression = `at(${scheduledDate.toISOString().split('.')[0]})`;

    try {
      // Create the rule
      await eventBridge.send(
        new PutRuleCommand({
          Name: ruleName,
          Description: `Scheduled campaign: ${existingCampaign.Item.name}`,
          ScheduleExpression: scheduleExpression,
          State: 'ENABLED',
        })
      );

      // Add Lambda as target
      await eventBridge.send(
        new PutTargetsCommand({
          Rule: ruleName,
          Targets: [
            {
              Id: '1',
              Arn: sendCampaignLambdaArn,
              Input: JSON.stringify({
                pathParameters: { id: campaignId },
                headers: { 'X-Tenant-ID': tenantId },
              }),
            },
          ],
        })
      );
    } catch (eventBridgeError) {
      console.error('Error creating EventBridge rule:', eventBridgeError);
      return {
        statusCode: 500,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'SCHEDULING_ERROR',
            message: 'Failed to create schedule',
          },
        }),
      };
    }

    // Update campaign
    const result = await dynamoDb.update({
      TableName: campaignsTable,
      Key: { id: campaignId, tenantId },
      UpdateExpression:
        'SET #status = :status, #scheduledAt = :scheduledAt, #timezone = :timezone, #updatedAt = :updatedAt',
      ExpressionAttributeNames: {
        '#status': 'status',
        '#scheduledAt': 'scheduledAt',
        '#timezone': 'timezone',
        '#updatedAt': 'updatedAt',
      },
      ExpressionAttributeValues: {
        ':status': 'SCHEDULED',
        ':scheduledAt': body.scheduledAt,
        ':timezone': body.timezone || 'UTC',
        ':updatedAt': new Date().toISOString(),
      },
      ReturnValues: 'ALL_NEW',
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: result.Attributes,
      }),
    };
  } catch (error) {
    console.error('Error scheduling campaign:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          // Security: Generic error message to prevent information leakage
          // Detailed errors are logged for debugging purposes
          message: 'Failed to schedule campaign',
        },
      }),
    };
  }
};
