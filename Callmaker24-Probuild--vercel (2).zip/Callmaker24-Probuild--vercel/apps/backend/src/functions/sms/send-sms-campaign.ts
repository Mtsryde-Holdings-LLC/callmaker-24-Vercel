/**
 * Lambda function to send SMS campaigns
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { campaignsTable, customersTable, messagesTable } from '../../lib/database';
import { sendBulkSMS } from '../../lib/sns';
import { v4 as uuidv4 } from 'uuid';

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const campaignId = event.pathParameters?.id;

    if (!campaignId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Campaign ID is required',
          },
        }),
      };
    }

    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    // Get campaign
    const campaign = await campaignsTable.get({ id: campaignId, tenantId });

    if (!campaign) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Campaign not found',
          },
        }),
      };
    }

    if (campaign.type !== 'SMS') {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_CAMPAIGN_TYPE',
            message: 'Campaign must be of type SMS',
          },
        }),
      };
    }

    // Get recipients based on segments
    const customers = await customersTable.queryBySegments({
      tenantId,
      segments: campaign.segments,
      smsOptIn: true, // Only include customers who opted in for SMS
    });

    if (!customers || customers.length === 0) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NO_RECIPIENTS',
            message: 'No eligible recipients found for this campaign',
          },
        }),
      };
    }

    // Prepare SMS messages with personalization
    const messages = customers.map((customer) => {
      let personalizedContent = campaign.content;

      // Replace placeholders with customer data
      personalizedContent = personalizedContent
        .replace(/\{\{firstName\}\}/g, customer.firstName || '')
        .replace(/\{\{lastName\}\}/g, customer.lastName || '')
        .replace(/\{\{company\}\}/g, customer.company || '')
        .replace(/\{\{email\}\}/g, customer.email || '');

      // Add opt-out message if required
      personalizedContent += '\n\nReply STOP to unsubscribe';

      return {
        phoneNumber: customer.phoneNumber!,
        message: personalizedContent,
        customerId: customer.id,
      };
    });

    // Update campaign status
    await campaignsTable.update({
      id: campaignId,
      tenantId,
      status: 'SENDING',
      sentAt: new Date().toISOString(),
    });

    // Send SMS messages in bulk
    const smsRecipients = messages.map((msg) => ({
      phoneNumber: msg.phoneNumber,
      message: msg.message,
    }));

    const result = await sendBulkSMS(smsRecipients);

    // Save message records
    const messageRecords = result.results.map((res, index) => ({
      id: uuidv4(),
      campaignId,
      customerId: messages[index].customerId,
      type: 'SMS' as const,
      content: messages[index].message,
      status: res.error ? 'FAILED' : 'SENT',
      metadata: {
        messageId: res.messageId,
        phoneNumber: res.phoneNumber,
        error: res.error,
      },
      tenantId,
      sentAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }));

    await messagesTable.batchCreate(messageRecords);

    // Update campaign analytics
    const successCount = result.results.filter((r) => !r.error).length;
    const failedCount = result.results.filter((r) => r.error).length;

    await campaignsTable.update({
      id: campaignId,
      tenantId,
      status: 'SENT',
      analytics: {
        sent: successCount,
        delivered: 0, // Will be updated by delivery receipts
        failed: failedCount,
      },
    });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          campaignId,
          totalRecipients: messages.length,
          sent: successCount,
          failed: failedCount,
          results: result.results,
        },
      }),
    };
  } catch (error) {
    console.error('Error sending SMS campaign:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to send SMS campaign',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};
