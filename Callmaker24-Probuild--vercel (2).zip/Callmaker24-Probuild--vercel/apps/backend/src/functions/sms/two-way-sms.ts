/**
 * Lambda function to handle two-way SMS conversations
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand, QueryCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { sendSMS } from '../../lib/sns';
import { v4 as uuidv4 } from 'uuid';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);
const CONVERSATIONS_TABLE = process.env.SMS_CONVERSATIONS_TABLE || 'sms-conversations';
const MESSAGES_TABLE = process.env.SMS_MESSAGES_TABLE || 'sms-messages';

interface SMSConversation {
  id: string;
  customerId: string;
  phoneNumber: string;
  status: 'OPEN' | 'CLOSED';
  lastMessageAt: string;
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

interface SMSMessage {
  id: string;
  conversationId: string;
  from: string;
  to: string;
  content: string;
  direction: 'INBOUND' | 'OUTBOUND';
  status: 'SENT' | 'DELIVERED' | 'FAILED';
  tenantId: string;
  createdAt: string;
}

/**
 * Handle incoming SMS message
 */
export const handleIncoming: APIGatewayProxyHandler = async (event) => {
  try {
    // Security: Wrap JSON parsing in try-catch to handle malformed input
    let body;
    try {
      body = JSON.parse(event.body || '{}');
    } catch (parseError) {
      console.error('Invalid JSON in request body:', parseError);
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_JSON',
            message: 'Request body must be valid JSON',
          },
        }),
      };
    }
    
    const { from, to, message, messageId, tenantId } = body;

    if (!from || !to || !message || !tenantId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'From, to, message, and tenant ID are required',
          },
        }),
      };
    }
    
    // Security: Validate message content and length
    if (typeof message !== 'string') {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Message must be a string',
          },
        }),
      };
    }
    
    if (message.length > 1600) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Message exceeds maximum length of 1600 characters',
          },
        }),
      };
    }

    // Find or create conversation
    const conversationResult = await docClient.send(
      new QueryCommand({
        TableName: CONVERSATIONS_TABLE,
        IndexName: 'phoneNumber-tenantId-index',
        KeyConditionExpression: 'phoneNumber = :phoneNumber AND tenantId = :tenantId',
        ExpressionAttributeValues: {
          ':phoneNumber': from,
          ':tenantId': tenantId,
        },
        Limit: 1,
      })
    );

    let conversation: SMSConversation;

    if (conversationResult.Items && conversationResult.Items.length > 0) {
      // Update existing conversation
      conversation = conversationResult.Items[0] as SMSConversation;

      await docClient.send(
        new UpdateCommand({
          TableName: CONVERSATIONS_TABLE,
          Key: { id: conversation.id, tenantId },
          UpdateExpression: 'SET lastMessageAt = :lastMessageAt, updatedAt = :updatedAt',
          ExpressionAttributeValues: {
            ':lastMessageAt': new Date().toISOString(),
            ':updatedAt': new Date().toISOString(),
          },
        })
      );
    } else {
      // Create new conversation
      conversation = {
        id: uuidv4(),
        customerId: '', // Will be linked later if customer exists
        phoneNumber: from,
        status: 'OPEN',
        lastMessageAt: new Date().toISOString(),
        tenantId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await docClient.send(
        new PutCommand({
          TableName: CONVERSATIONS_TABLE,
          Item: conversation,
        })
      );
    }

    // Save incoming message
    const smsMessage: SMSMessage = {
      id: messageId || uuidv4(),
      conversationId: conversation.id,
      from,
      to,
      content: message,
      direction: 'INBOUND',
      status: 'DELIVERED',
      tenantId,
      createdAt: new Date().toISOString(),
    };

    await docClient.send(
      new PutCommand({
        TableName: MESSAGES_TABLE,
        Item: smsMessage,
      })
    );

    // TODO: Trigger bot response or notify agents
    // This could be integrated with the chatbot Lambda or notification system

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          conversationId: conversation.id,
          messageId: smsMessage.id,
          message: 'SMS received successfully',
        },
      }),
    };
  } catch (error) {
    console.error('Error handling incoming SMS:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          // Security: Generic error message to prevent information leakage
          // Detailed errors are logged for debugging purposes
          message: 'Failed to process incoming SMS',
        },
      }),
    };
  }
};

/**
 * Send SMS reply
 */
export const sendReply: APIGatewayProxyHandler = async (event) => {
  try {
    // Security: Wrap JSON parsing in try-catch to handle malformed input
    let body;
    try {
      body = JSON.parse(event.body || '{}');
    } catch (parseError) {
      console.error('Invalid JSON in request body:', parseError);
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_JSON',
            message: 'Request body must be valid JSON',
          },
        }),
      };
    }
    
    const { conversationId, message, tenantId } = body;

    if (!conversationId || !message || !tenantId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Conversation ID, message, and tenant ID are required',
          },
        }),
      };
    }
    
    // Security: Validate message content and length
    if (typeof message !== 'string') {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Message must be a string',
          },
        }),
      };
    }
    
    if (message.length === 0) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Message cannot be empty',
          },
        }),
      };
    }
    
    if (message.length > 1600) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Message exceeds maximum length of 1600 characters',
          },
        }),
      };
    }

    // Get conversation
    const conversationResult = await docClient.send(
      new QueryCommand({
        TableName: CONVERSATIONS_TABLE,
        KeyConditionExpression: 'id = :id AND tenantId = :tenantId',
        ExpressionAttributeValues: {
          ':id': conversationId,
          ':tenantId': tenantId,
        },
      })
    );

    if (!conversationResult.Items || conversationResult.Items.length === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Conversation not found',
          },
        }),
      };
    }

    const conversation = conversationResult.Items[0] as SMSConversation;

    // Send SMS
    const result = await sendSMS({
      phoneNumber: conversation.phoneNumber,
      message,
      smsType: 'Transactional',
    });

    // Save outbound message
    const smsMessage: SMSMessage = {
      id: uuidv4(),
      conversationId: conversation.id,
      from: process.env.SMS_SENDER_NUMBER || 'SYSTEM',
      to: conversation.phoneNumber,
      content: message,
      direction: 'OUTBOUND',
      status: 'SENT',
      tenantId,
      createdAt: new Date().toISOString(),
    };

    await docClient.send(
      new PutCommand({
        TableName: MESSAGES_TABLE,
        Item: smsMessage,
      })
    );

    // Update conversation
    await docClient.send(
      new UpdateCommand({
        TableName: CONVERSATIONS_TABLE,
        Key: { id: conversation.id, tenantId },
        UpdateExpression: 'SET lastMessageAt = :lastMessageAt, updatedAt = :updatedAt',
        ExpressionAttributeValues: {
          ':lastMessageAt': new Date().toISOString(),
          ':updatedAt': new Date().toISOString(),
        },
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          conversationId: conversation.id,
          messageId: smsMessage.id,
          snsMessageId: result.messageId,
          status: 'SENT',
        },
      }),
    };
  } catch (error) {
    console.error('Error sending SMS reply:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          // Security: Generic error message to prevent information leakage
          message: 'Failed to send SMS reply',
        },
      }),
    };
  }
};

/**
 * Get conversation history
 */
export const getConversation: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const conversationId = event.pathParameters?.id;

    if (!tenantId || !conversationId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Conversation ID are required',
          },
        }),
      };
    }

    // Get conversation
    const conversationResult = await docClient.send(
      new QueryCommand({
        TableName: CONVERSATIONS_TABLE,
        KeyConditionExpression: 'id = :id AND tenantId = :tenantId',
        ExpressionAttributeValues: {
          ':id': conversationId,
          ':tenantId': tenantId,
        },
      })
    );

    if (!conversationResult.Items || conversationResult.Items.length === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Conversation not found',
          },
        }),
      };
    }

    const conversation = conversationResult.Items[0];

    // Get messages
    const messagesResult = await docClient.send(
      new QueryCommand({
        TableName: MESSAGES_TABLE,
        IndexName: 'conversationId-index',
        KeyConditionExpression: 'conversationId = :conversationId',
        ExpressionAttributeValues: {
          ':conversationId': conversationId,
        },
        ScanIndexForward: true, // Sort by creation date ascending
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          conversation,
          messages: messagesResult.Items || [],
        },
      }),
    };
  } catch (error) {
    console.error('Error getting conversation:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          // Security: Generic error message to prevent information leakage
          message: 'Failed to get conversation',
        },
      }),
    };
  }
};

/**
 * List all conversations
 */
export const listConversations: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    const result = await docClient.send(
      new QueryCommand({
        TableName: CONVERSATIONS_TABLE,
        IndexName: 'tenantId-lastMessageAt-index',
        KeyConditionExpression: 'tenantId = :tenantId',
        ExpressionAttributeValues: {
          ':tenantId': tenantId,
        },
        ScanIndexForward: false, // Sort by last message descending
        Limit: 50,
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result.Items || [],
      }),
    };
  } catch (error) {
    console.error('Error listing conversations:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          // Security: Generic error message to prevent information leakage
          message: 'Failed to list conversations',
        },
      }),
    };
  }
};
