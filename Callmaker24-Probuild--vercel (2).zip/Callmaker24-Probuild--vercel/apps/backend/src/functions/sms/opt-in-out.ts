/**
 * Lambda function to handle SMS opt-in/opt-out
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { customersTable } from '../../lib/database';
import { sendSMS } from '../../lib/sns';

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const { phoneNumber, action, tenantId } = body;

    if (!phoneNumber || !action || !tenantId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Phone number, action, and tenant ID are required',
          },
        }),
      };
    }

    if (!['OPT_IN', 'OPT_OUT'].includes(action)) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_ACTION',
            message: 'Action must be either OPT_IN or OPT_OUT',
          },
        }),
      };
    }

    // Find customer by phone number
    const customer = await customersTable.findByPhoneNumber({
      tenantId,
      phoneNumber,
    });

    if (!customer) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'CUSTOMER_NOT_FOUND',
            message: 'Customer with this phone number not found',
          },
        }),
      };
    }

    // Update customer SMS opt-in status
    const smsOptIn = action === 'OPT_IN';
    await customersTable.update({
      id: customer.id,
      tenantId,
      smsOptIn,
      updatedAt: new Date().toISOString(),
    });

    // Send confirmation SMS
    const confirmationMessage =
      action === 'OPT_IN'
        ? 'You have successfully opted in to receive SMS messages. Reply STOP to unsubscribe at any time.'
        : 'You have been unsubscribed from SMS messages. Reply START to opt back in.';

    await sendSMS({
      phoneNumber,
      message: confirmationMessage,
      smsType: 'Transactional',
    });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          customerId: customer.id,
          phoneNumber,
          smsOptIn,
          message: 'SMS preference updated successfully',
        },
      }),
    };
  } catch (error) {
    console.error('Error handling SMS opt-in/out:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to process SMS opt-in/out request',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

/**
 * Lambda function to handle incoming SMS webhooks (for STOP/START replies)
 */
export const handleIncomingSMS: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const { from, message, tenantId } = body;

    if (!from || !message || !tenantId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'From, message, and tenant ID are required',
          },
        }),
      };
    }

    const normalizedMessage = message.trim().toUpperCase();
    const phoneNumber = from;

    // Find customer
    const customer = await customersTable.findByPhoneNumber({
      tenantId,
      phoneNumber,
    });

    if (!customer) {
      // Log unknown sender
      console.log('SMS received from unknown number:', phoneNumber);
      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          message: 'SMS received from unknown number',
        }),
      };
    }

    // Handle STOP keyword
    if (['STOP', 'STOPALL', 'UNSUBSCRIBE', 'CANCEL', 'END', 'QUIT'].includes(normalizedMessage)) {
      await customersTable.update({
        id: customer.id,
        tenantId,
        smsOptIn: false,
        status: 'UNSUBSCRIBED',
        updatedAt: new Date().toISOString(),
      });

      await sendSMS({
        phoneNumber,
        message: 'You have been unsubscribed from SMS messages. Reply START to opt back in.',
        smsType: 'Transactional',
      });

      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          data: {
            action: 'OPT_OUT',
            customerId: customer.id,
            phoneNumber,
          },
        }),
      };
    }

    // Handle START keyword
    if (['START', 'UNSTOP', 'YES', 'SUBSCRIBE'].includes(normalizedMessage)) {
      await customersTable.update({
        id: customer.id,
        tenantId,
        smsOptIn: true,
        status: 'ACTIVE',
        updatedAt: new Date().toISOString(),
      });

      await sendSMS({
        phoneNumber,
        message:
          'You have successfully re-subscribed to SMS messages. Reply STOP to unsubscribe at any time.',
        smsType: 'Transactional',
      });

      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          data: {
            action: 'OPT_IN',
            customerId: customer.id,
            phoneNumber,
          },
        }),
      };
    }

    // Handle HELP keyword
    if (['HELP', 'INFO', 'SUPPORT'].includes(normalizedMessage)) {
      await sendSMS({
        phoneNumber,
        message:
          'Reply STOP to unsubscribe. Reply START to resubscribe. For support, contact support@example.com',
        smsType: 'Transactional',
      });

      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          data: {
            action: 'HELP',
            customerId: customer.id,
            phoneNumber,
          },
        }),
      };
    }

    // Log other messages (could trigger two-way conversation)
    console.log('SMS message received:', {
      customerId: customer.id,
      phoneNumber,
      message,
    });

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        data: {
          action: 'MESSAGE_RECEIVED',
          customerId: customer.id,
          phoneNumber,
          message,
        },
      }),
    };
  } catch (error) {
    console.error('Error handling incoming SMS:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to process incoming SMS',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};
