/**
 * Lambda function to manage SMS templates
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, PutCommand, QueryCommand, DeleteCommand } from '@aws-sdk/lib-dynamodb';
import { v4 as uuidv4 } from 'uuid';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);
const TEMPLATES_TABLE = process.env.SMS_TEMPLATES_TABLE || 'sms-templates';

interface SMSTemplate {
  id: string;
  name: string;
  content: string;
  category?: string;
  variables: string[];
  isActive: boolean;
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

// CREATE Template
export const createTemplate: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: { code: 'UNAUTHORIZED', message: 'Tenant ID is required' },
        }),
      };
    }

    const body = JSON.parse(event.body || '{}');
    const { name, content, category } = body;

    if (!name || !content) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: { code: 'INVALID_REQUEST', message: 'Name and content are required' },
        }),
      };
    }

    // Extract variables from content (e.g., {{firstName}})
    const variableRegex = /\{\{(\w+)\}\}/g;
    const variables: string[] = [];
    let match;
    while ((match = variableRegex.exec(content)) !== null) {
      if (!variables.includes(match[1])) {
        variables.push(match[1]);
      }
    }

    const template: SMSTemplate = {
      id: uuidv4(),
      name,
      content,
      category: category || 'general',
      variables,
      isActive: true,
      tenantId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await docClient.send(
      new PutCommand({
        TableName: TEMPLATES_TABLE,
        Item: template,
      })
    );

    return {
      statusCode: 201,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: template,
      }),
    };
  } catch (error) {
    console.error('Error creating SMS template:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to create SMS template',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

// LIST Templates
export const listTemplates: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: { code: 'UNAUTHORIZED', message: 'Tenant ID is required' },
        }),
      };
    }

    const result = await docClient.send(
      new QueryCommand({
        TableName: TEMPLATES_TABLE,
        IndexName: 'tenantId-index',
        KeyConditionExpression: 'tenantId = :tenantId',
        ExpressionAttributeValues: {
          ':tenantId': tenantId,
        },
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result.Items || [],
      }),
    };
  } catch (error) {
    console.error('Error listing SMS templates:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to list SMS templates',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

// GET Template
export const getTemplate: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const templateId = event.pathParameters?.id;

    if (!tenantId || !templateId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: { code: 'INVALID_REQUEST', message: 'Tenant ID and Template ID are required' },
        }),
      };
    }

    const result = await docClient.send(
      new GetCommand({
        TableName: TEMPLATES_TABLE,
        Key: { id: templateId, tenantId },
      })
    );

    if (!result.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: { code: 'NOT_FOUND', message: 'Template not found' },
        }),
      };
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result.Item,
      }),
    };
  } catch (error) {
    console.error('Error getting SMS template:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to get SMS template',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

// UPDATE Template
export const updateTemplate: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const templateId = event.pathParameters?.id;

    if (!tenantId || !templateId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: { code: 'INVALID_REQUEST', message: 'Tenant ID and Template ID are required' },
        }),
      };
    }

    const body = JSON.parse(event.body || '{}');
    const { name, content, category, isActive } = body;

    // Extract variables from content if content is provided
    let variables: string[] = [];
    if (content) {
      const variableRegex = /\{\{(\w+)\}\}/g;
      let match;
      while ((match = variableRegex.exec(content)) !== null) {
        if (!variables.includes(match[1])) {
          variables.push(match[1]);
        }
      }
    }

    const updateData: any = {
      updatedAt: new Date().toISOString(),
    };

    if (name) updateData.name = name;
    if (content) {
      updateData.content = content;
      updateData.variables = variables;
    }
    if (category) updateData.category = category;
    if (typeof isActive === 'boolean') updateData.isActive = isActive;

    // Get existing template first
    const existing = await docClient.send(
      new GetCommand({
        TableName: TEMPLATES_TABLE,
        Key: { id: templateId, tenantId },
      })
    );

    if (!existing.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: { code: 'NOT_FOUND', message: 'Template not found' },
        }),
      };
    }

    const updated = { ...existing.Item, ...updateData };

    await docClient.send(
      new PutCommand({
        TableName: TEMPLATES_TABLE,
        Item: updated,
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: updated,
      }),
    };
  } catch (error) {
    console.error('Error updating SMS template:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to update SMS template',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

// DELETE Template
export const deleteTemplate: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const templateId = event.pathParameters?.id;

    if (!tenantId || !templateId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: { code: 'INVALID_REQUEST', message: 'Tenant ID and Template ID are required' },
        }),
      };
    }

    await docClient.send(
      new DeleteCommand({
        TableName: TEMPLATES_TABLE,
        Key: { id: templateId, tenantId },
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        message: 'Template deleted successfully',
      }),
    };
  } catch (error) {
    console.error('Error deleting SMS template:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to delete SMS template',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};
