/**
 * Lambda function to handle Stripe webhooks
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { handleWebhook } from '../../lib/stripe';

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const signature = event.headers['stripe-signature'] || event.headers['Stripe-Signature'];

    if (!signature) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Stripe signature is required',
          },
        }),
      };
    }

    const result = await handleWebhook(event.body!, signature);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(result),
    };
  } catch (error: any) {
    console.error('Webhook error:', error);

    return {
      statusCode: 400,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'WEBHOOK_ERROR',
          message: error.message || 'Invalid webhook signature',
        },
      }),
    };
  }
};
