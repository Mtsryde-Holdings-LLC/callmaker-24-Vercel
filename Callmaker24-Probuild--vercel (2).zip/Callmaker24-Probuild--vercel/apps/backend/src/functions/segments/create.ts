import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import { v4 as uuidv4 } from 'uuid';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const segmentsTable = process.env.SEGMENTS_TABLE_NAME!;

interface SegmentRule {
  field: string;
  operator: 'equals' | 'not_equals' | 'contains' | 'not_contains' | 'greater_than' | 'less_than' | 'in' | 'not_in';
  value: any;
}

interface CreateSegmentRequest {
  name: string;
  description?: string;
  rules: SegmentRule[];
  logic?: 'AND' | 'OR'; // How to combine rules
}

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const userId = event.requestContext.authorizer?.claims?.sub;

    if (!tenantId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'MISSING_TENANT_ID',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    const body: CreateSegmentRequest = JSON.parse(event.body || '{}');

    // Validation
    if (!body.name || !body.rules || body.rules.length === 0) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Name and at least one rule are required',
          },
        }),
      };
    }

    // Validate rules
    const validFields = [
      'status',
      'emailOptIn',
      'smsOptIn',
      'tags',
      'company',
      'createdAt',
      'updatedAt',
      'lastMessageAt',
      'totalSpent',
    ];
    const validOperators = [
      'equals',
      'not_equals',
      'contains',
      'not_contains',
      'greater_than',
      'less_than',
      'in',
      'not_in',
    ];

    for (const rule of body.rules) {
      if (!validFields.includes(rule.field)) {
        return {
          statusCode: 400,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            success: false,
            error: {
              code: 'INVALID_RULE',
              message: `Invalid field: ${rule.field}`,
            },
          }),
        };
      }

      if (!validOperators.includes(rule.operator)) {
        return {
          statusCode: 400,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            success: false,
            error: {
              code: 'INVALID_RULE',
              message: `Invalid operator: ${rule.operator}`,
            },
          }),
        };
      }
    }

    // Create segment
    const segmentId = uuidv4();
    const now = new Date().toISOString();

    const segment = {
      id: segmentId,
      tenantId,
      name: body.name,
      description: body.description,
      rules: body.rules,
      logic: body.logic || 'AND',
      createdBy: userId,
      createdAt: now,
      updatedAt: now,
    };

    await dynamoDb.put({
      TableName: segmentsTable,
      Item: segment,
    });

    return {
      statusCode: 201,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: segment,
      }),
    };
  } catch (error) {
    console.error('Error creating segment:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to create segment',
        },
      }),
    };
  }
};
