import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const segmentsTable = process.env.SEGMENTS_TABLE_NAME!;
const customersTable = process.env.CUSTOMERS_TABLE_NAME!;

interface SegmentRule {
  field: string;
  operator: string;
  value: any;
}

function evaluateRule(customer: any, rule: SegmentRule): boolean {
  const fieldValue = customer[rule.field];

  switch (rule.operator) {
    case 'equals':
      return fieldValue === rule.value;
    case 'not_equals':
      return fieldValue !== rule.value;
    case 'contains':
      return typeof fieldValue === 'string' && fieldValue.includes(rule.value);
    case 'not_contains':
      return typeof fieldValue === 'string' && !fieldValue.includes(rule.value);
    case 'greater_than':
      return fieldValue > rule.value;
    case 'less_than':
      return fieldValue < rule.value;
    case 'in':
      return Array.isArray(rule.value) && rule.value.includes(fieldValue);
    case 'not_in':
      return Array.isArray(rule.value) && !rule.value.includes(fieldValue);
    default:
      return false;
  }
}

function evaluateRules(customer: any, rules: SegmentRule[], logic: 'AND' | 'OR'): boolean {
  if (logic === 'AND') {
    return rules.every((rule) => evaluateRule(customer, rule));
  } else {
    return rules.some((rule) => evaluateRule(customer, rule));
  }
}

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const segmentId = event.pathParameters?.id;

    if (!tenantId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'MISSING_TENANT_ID',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    let segment: any;

    if (segmentId) {
      // Get existing segment
      const result = await dynamoDb.get({
        TableName: segmentsTable,
        Key: { id: segmentId, tenantId },
      });

      if (!result.Item) {
        return {
          statusCode: 404,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            success: false,
            error: {
              code: 'NOT_FOUND',
              message: 'Segment not found',
            },
          }),
        };
      }

      segment = result.Item;
    } else {
      // Preview mode - rules in request body
      const body = JSON.parse(event.body || '{}');
      segment = {
        rules: body.rules || [],
        logic: body.logic || 'AND',
      };

      if (segment.rules.length === 0) {
        return {
          statusCode: 400,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            success: false,
            error: {
              code: 'INVALID_REQUEST',
              message: 'At least one rule is required',
            },
          }),
        };
      }
    }

    // Get all customers for the tenant
    let customers: any[] = [];
    let lastEvaluatedKey: any = undefined;

    do {
      const result = await dynamoDb.query({
        TableName: customersTable,
        IndexName: 'TenantIndex',
        KeyConditionExpression: '#tenantId = :tenantId',
        FilterExpression: '#status = :status',
        ExpressionAttributeNames: {
          '#tenantId': 'tenantId',
          '#status': 'status',
        },
        ExpressionAttributeValues: {
          ':tenantId': tenantId,
          ':status': 'ACTIVE',
        },
        ExclusiveStartKey: lastEvaluatedKey,
      });

      customers = customers.concat(result.Items || []);
      lastEvaluatedKey = result.LastEvaluatedKey;
    } while (lastEvaluatedKey);

    // Filter customers based on segment rules
    const matchingCustomers = customers.filter((customer) =>
      evaluateRules(customer, segment.rules, segment.logic)
    );

    // Limit preview to 100 customers
    const previewCustomers = matchingCustomers.slice(0, 100);

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: {
          totalMatching: matchingCustomers.length,
          totalCustomers: customers.length,
          matchPercentage: customers.length > 0 ? (matchingCustomers.length / customers.length) * 100 : 0,
          preview: previewCustomers,
        },
      }),
    };
  } catch (error) {
    console.error('Error previewing segment:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to preview segment',
        },
      }),
    };
  }
};
