import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const connectionsTable = process.env.CONNECTIONS_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const connectionId = event.requestContext.connectionId!;
    const queryParams = event.queryStringParameters || {};
    const userId = queryParams.userId;
    const userType = queryParams.userType; // 'CUSTOMER' or 'AGENT'
    const tenantId = queryParams.tenantId;

    if (!userId || !userType || !tenantId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          message: 'userId, userType, and tenantId are required',
        }),
      };
    }

    // Store connection
    await dynamoDb.put({
      TableName: connectionsTable,
      Item: {
        connectionId,
        userId,
        userType,
        tenantId,
        connectedAt: new Date().toISOString(),
        ttl: Math.floor(Date.now() / 1000) + 86400, // 24 hours
      },
    });

    console.log(`WebSocket connected: ${connectionId} (${userType})`);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Connected',
      }),
    };
  } catch (error) {
    console.error('Error connecting WebSocket:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        message: 'Failed to connect',
      }),
    };
  }
};
