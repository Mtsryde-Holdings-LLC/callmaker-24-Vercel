import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const connectionsTable = process.env.CONNECTIONS_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const connectionId = event.requestContext.connectionId!;

    // Remove connection
    await dynamoDb.delete({
      TableName: connectionsTable,
      Key: { connectionId },
    });

    console.log(`WebSocket disconnected: ${connectionId}`);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Disconnected',
      }),
    };
  } catch (error) {
    console.error('Error disconnecting WebSocket:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        message: 'Failed to disconnect',
      }),
    };
  }
};
