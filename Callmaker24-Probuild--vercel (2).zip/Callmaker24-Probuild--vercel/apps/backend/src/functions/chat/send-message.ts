import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import {
  ApiGatewayManagementApiClient,
  PostToConnectionCommand,
} from '@aws-sdk/client-apigatewaymanagementapi';
import { v4 as uuidv4 } from 'uuid';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const messagesTable = process.env.MESSAGES_TABLE_NAME!;
const conversationsTable = process.env.CONVERSATIONS_TABLE_NAME!;
const connectionsTable = process.env.CONNECTIONS_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const connectionId = event.requestContext.connectionId!;
    const body = JSON.parse(event.body || '{}');

    const { conversationId, content, type = 'TEXT' } = body;

    if (!conversationId || !content) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          message: 'conversationId and content are required',
        }),
      };
    }

    // Get connection info
    const connectionResult = await dynamoDb.get({
      TableName: connectionsTable,
      Key: { connectionId },
    });

    if (!connectionResult.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          message: 'Connection not found',
        }),
      };
    }

    const connection = connectionResult.Item;

    // Get conversation
    const conversationResult = await dynamoDb.get({
      TableName: conversationsTable,
      Key: {
        id: conversationId,
        tenantId: connection.tenantId,
      },
    });

    if (!conversationResult.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          message: 'Conversation not found',
        }),
      };
    }

    const conversation = conversationResult.Item;

    // Create message
    const messageId = uuidv4();
    const now = new Date().toISOString();

    const message = {
      id: messageId,
      conversationId,
      tenantId: connection.tenantId,
      content,
      type,
      sender: connection.userType,
      senderId: connection.userId,
      status: 'SENT',
      createdAt: now,
      sentAt: now,
    };

    await dynamoDb.put({
      TableName: messagesTable,
      Item: message,
    });

    // Update conversation
    await dynamoDb.update({
      TableName: conversationsTable,
      Key: {
        id: conversationId,
        tenantId: connection.tenantId,
      },
      UpdateExpression:
        'SET #lastMessage = :lastMessage, #updatedAt = :updatedAt, #unreadCount = #unreadCount + :increment',
      ExpressionAttributeNames: {
        '#lastMessage': 'lastMessage',
        '#updatedAt': 'updatedAt',
        '#unreadCount': 'unreadCount',
      },
      ExpressionAttributeValues: {
        ':lastMessage': { content, sentAt: now },
        ':updatedAt': now,
        ':increment': 1,
      },
    });

    // Send message to all connections in this conversation
    const allConnectionsResult = await dynamoDb.scan({
      TableName: connectionsTable,
      FilterExpression: '#tenantId = :tenantId',
      ExpressionAttributeNames: {
        '#tenantId': 'tenantId',
      },
      ExpressionAttributeValues: {
        ':tenantId': connection.tenantId,
      },
    });

    const connections = allConnectionsResult.Items || [];

    // Filter connections that should receive this message
    // For customer messages, send to assigned agent
    // For agent messages, send to customer
    const recipientConnections = connections.filter((conn) => {
      if (connection.userType === 'CUSTOMER') {
        // Send to agents
        return conn.userType === 'AGENT';
      } else if (connection.userType === 'AGENT') {
        // Send to customer in this conversation
        return conn.userId === conversation.customerId;
      }
      return false;
    });

    // Initialize API Gateway Management API client
    const apiGatewayClient = new ApiGatewayManagementApiClient({
      endpoint: `https://${event.requestContext.domainName}/${event.requestContext.stage}`,
    });

    // Send to all recipient connections
    const sendPromises = recipientConnections.map(async (conn) => {
      try {
        await apiGatewayClient.send(
          new PostToConnectionCommand({
            ConnectionId: conn.connectionId,
            Data: Buffer.from(
              JSON.stringify({
                type: 'message',
                data: message,
              })
            ),
          })
        );
      } catch (error: any) {
        if (error.statusCode === 410) {
          // Connection is stale, remove it
          await dynamoDb.delete({
            TableName: connectionsTable,
            Key: { connectionId: conn.connectionId },
          });
        }
      }
    });

    await Promise.allSettled(sendPromises);

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        data: message,
      }),
    };
  } catch (error) {
    console.error('Error sending message:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        message: 'Failed to send message',
      }),
    };
  }
};
