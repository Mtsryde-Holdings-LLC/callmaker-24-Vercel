/**
 * Lambda function to send voice campaigns (mass outbound calling)
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { campaignsTable, customersTable } from '../../lib/database';
import { initiateOutboundCall, formatPhoneNumber, createContactAttributes } from '../../lib/connect';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand } from '@aws-sdk/lib-dynamodb';
import { v4 as uuidv4 } from 'uuid';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);
const CALLS_TABLE = process.env.CALLS_TABLE || 'calls';

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const campaignId = event.pathParameters?.id;

    if (!campaignId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Campaign ID is required',
          },
        }),
      };
    }

    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    const instanceId = process.env.CONNECT_INSTANCE_ID;
    if (!instanceId) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'CONFIGURATION_ERROR',
            message: 'Amazon Connect instance ID not configured',
          },
        }),
      };
    }

    // Get campaign
    const campaign = await campaignsTable.get({ id: campaignId, tenantId });

    if (!campaign) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Campaign not found',
          },
        }),
      };
    }

    if (campaign.type !== 'VOICE') {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_CAMPAIGN_TYPE',
            message: 'Campaign must be of type VOICE',
          },
        }),
      };
    }

    // Get recipients based on segments
    const customers = await customersTable.queryBySegments({
      tenantId,
      segments: campaign.segments,
    });

    if (!customers || customers.length === 0) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NO_RECIPIENTS',
            message: 'No eligible recipients found for this campaign',
          },
        }),
      };
    }

    // Filter customers with valid phone numbers
    const validCustomers = customers.filter((c) => c.phoneNumber);

    if (validCustomers.length === 0) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NO_VALID_RECIPIENTS',
            message: 'No customers with valid phone numbers found',
          },
        }),
      };
    }

    // Update campaign status
    await campaignsTable.update({
      id: campaignId,
      tenantId,
      status: 'SENDING',
      sentAt: new Date().toISOString(),
    });

    // Get contact flow ID from campaign metadata
    const contactFlowId = campaign.metadata?.contactFlowId;

    if (!contactFlowId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'MISSING_CONTACT_FLOW',
            message: 'Campaign must have a contact flow ID configured',
          },
        }),
      };
    }

    // Initiate calls (with rate limiting)
    const results = [];
    const maxConcurrent = parseInt(process.env.MAX_CONCURRENT_CALLS || '10');
    const batchSize = Math.min(maxConcurrent, validCustomers.length);

    for (let i = 0; i < validCustomers.length; i += batchSize) {
      const batch = validCustomers.slice(i, i + batchSize);

      const batchResults = await Promise.allSettled(
        batch.map(async (customer) => {
          try {
            const formattedPhoneNumber = formatPhoneNumber(customer.phoneNumber!);

            // Create contact attributes
            const attributes = createContactAttributes({
              campaignId,
              customerId: customer.id,
              customerName: `${customer.firstName || ''} ${customer.lastName || ''}`.trim(),
              tenantId,
              campaignMessage: campaign.content,
            });

            // Initiate call
            const callResult = await initiateOutboundCall({
              destinationPhoneNumber: formattedPhoneNumber,
              contactFlowId,
              instanceId,
              attributes,
            });

            // Create call record
            const callRecord = {
              id: uuidv4(),
              connectContactId: callResult.contactId,
              campaignId,
              customerId: customer.id,
              direction: 'OUTBOUND',
              status: 'INITIATED',
              fromNumber: process.env.CONNECT_PHONE_NUMBER || '',
              toNumber: formattedPhoneNumber,
              contactFlowId,
              metadata: {
                attributes,
                campaignName: campaign.name,
              },
              tenantId,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };

            await docClient.send(
              new PutCommand({
                TableName: CALLS_TABLE,
                Item: callRecord,
              })
            );

            return {
              success: true,
              customerId: customer.id,
              phoneNumber: formattedPhoneNumber,
              contactId: callResult.contactId,
              callId: callRecord.id,
            };
          } catch (error) {
            return {
              success: false,
              customerId: customer.id,
              phoneNumber: customer.phoneNumber,
              error: error instanceof Error ? error.message : 'Unknown error',
            };
          }
        })
      );

      results.push(...batchResults);

      // Add delay between batches to prevent throttling
      if (i + batchSize < validCustomers.length) {
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
    }

    // Process results
    const successCount = results.filter((r) => r.status === 'fulfilled' && r.value.success).length;
    const failedCount = results.filter((r) => r.status === 'rejected' || !r.value?.success).length;

    // Update campaign analytics
    await campaignsTable.update({
      id: campaignId,
      tenantId,
      status: 'SENT',
      analytics: {
        sent: successCount,
        failed: failedCount,
      },
    });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          campaignId,
          totalRecipients: validCustomers.length,
          initiated: successCount,
          failed: failedCount,
          results: results.map((r) => (r.status === 'fulfilled' ? r.value : { success: false })),
        },
      }),
    };
  } catch (error) {
    console.error('Error sending voice campaign:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to send voice campaign',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};
