/**
 * Lambda function to handle Amazon Connect events
 */

import { Handler } from 'aws-lambda';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand, UpdateCommand, GetCommand } from '@aws-sdk/lib-dynamodb';
import { startCallRecording } from '../../lib/connect';
import { v4 as uuidv4 } from 'uuid';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);
const CALLS_TABLE = process.env.CALLS_TABLE || 'calls';

interface ConnectEvent {
  Details: {
    ContactData: {
      ContactId: string;
      InitialContactId: string;
      InstanceARN: string;
      Channel: string;
      CustomerEndpoint: {
        Address: string;
        Type: string;
      };
      SystemEndpoint: {
        Address: string;
        Type: string;
      };
      Attributes: Record<string, string>;
      InitiationMethod: string;
    };
    Parameters?: Record<string, string>;
  };
  Name: string;
}

export const handler: Handler = async (event: ConnectEvent) => {
  try {
    console.log('Connect event received:', JSON.stringify(event, null, 2));

    const contactData = event.Details.ContactData;
    const contactId = contactData.ContactId;
    const initialContactId = contactData.InitialContactId;
    const customerPhoneNumber = contactData.CustomerEndpoint?.Address || '';
    const systemPhoneNumber = contactData.SystemEndpoint?.Address || '';
    const attributes = contactData.Attributes || {};
    const initiationMethod = contactData.InitiationMethod; // INBOUND, OUTBOUND, TRANSFER, etc.
    const tenantId = attributes.tenantId || '';

    // Extract instance ID from ARN
    const instanceId = contactData.InstanceARN.split('/').pop() || '';

    // Handle different event types
    if (event.Name === 'ContactFlowEvent') {
      // Call initiated or in progress
      await handleCallInitiated({
        contactId,
        initialContactId,
        customerPhoneNumber,
        systemPhoneNumber,
        tenantId,
        attributes,
        initiationMethod,
        instanceId,
      });

      // Start recording if configured
      if (process.env.AUTO_RECORD_CALLS === 'true') {
        try {
          await startCallRecording({
            instanceId,
            contactId,
            initialContactId,
            voiceRecordingTrack: 'ALL',
          });

          console.log('Call recording started:', contactId);
        } catch (error) {
          console.error('Error starting call recording:', error);
        }
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        message: 'Event processed successfully',
      }),
    };
  } catch (error) {
    console.error('Error handling Connect event:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      }),
    };
  }
};

async function handleCallInitiated(params: {
  contactId: string;
  initialContactId: string;
  customerPhoneNumber: string;
  systemPhoneNumber: string;
  tenantId: string;
  attributes: Record<string, string>;
  initiationMethod: string;
  instanceId: string;
}) {
  const {
    contactId,
    initialContactId,
    customerPhoneNumber,
    systemPhoneNumber,
    tenantId,
    attributes,
    initiationMethod,
    instanceId,
  } = params;

  // Check if call record already exists (for outbound calls)
  const existingCall = await docClient.send(
    new GetCommand({
      TableName: CALLS_TABLE,
      Key: { connectContactId: contactId },
    })
  );

  if (existingCall.Item) {
    // Update existing call record
    await docClient.send(
      new UpdateCommand({
        TableName: CALLS_TABLE,
        Key: { id: existingCall.Item.id, tenantId },
        UpdateExpression:
          'SET #status = :status, initialContactId = :initialContactId, instanceId = :instanceId, updatedAt = :updatedAt',
        ExpressionAttributeNames: {
          '#status': 'status',
        },
        ExpressionAttributeValues: {
          ':status': 'IN_PROGRESS',
          ':initialContactId': initialContactId,
          ':instanceId': instanceId,
          ':updatedAt': new Date().toISOString(),
        },
      })
    );
  } else {
    // Create new call record (for inbound calls)
    const callRecord = {
      id: uuidv4(),
      connectContactId: contactId,
      initialContactId,
      instanceId,
      customerId: attributes.customerId || '',
      direction: initiationMethod === 'INBOUND' ? 'INBOUND' : 'OUTBOUND',
      status: 'IN_PROGRESS',
      fromNumber: initiationMethod === 'INBOUND' ? customerPhoneNumber : systemPhoneNumber,
      toNumber: initiationMethod === 'INBOUND' ? systemPhoneNumber : customerPhoneNumber,
      metadata: {
        attributes,
        initiationMethod,
      },
      tenantId: tenantId || 'default',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await docClient.send(
      new PutCommand({
        TableName: CALLS_TABLE,
        Item: callRecord,
      })
    );
  }
}

/**
 * Handle call completed event
 */
export const handleCallCompleted: Handler = async (event: any) => {
  try {
    console.log('Call completed event:', JSON.stringify(event, null, 2));

    const contactId = event.detail.contactId || event.ContactId;
    const disconnectReason = event.detail.disconnectReason || 'COMPLETED';
    const duration = event.detail.connectedToSystemTimestamp
      ? Math.floor(
          (new Date(event.detail.disconnectTimestamp).getTime() -
            new Date(event.detail.connectedToSystemTimestamp).getTime()) /
            1000
        )
      : 0;

    // Find and update call record
    const result = await docClient.send(
      new GetCommand({
        TableName: CALLS_TABLE,
        Key: { connectContactId: contactId },
      })
    );

    if (result.Item) {
      await docClient.send(
        new UpdateCommand({
          TableName: CALLS_TABLE,
          Key: { id: result.Item.id, tenantId: result.Item.tenantId },
          UpdateExpression: 'SET #status = :status, duration = :duration, disconnectReason = :reason, updatedAt = :updatedAt',
          ExpressionAttributeNames: {
            '#status': 'status',
          },
          ExpressionAttributeValues: {
            ':status': 'COMPLETED',
            ':duration': duration,
            ':reason': disconnectReason,
            ':updatedAt': new Date().toISOString(),
          },
        })
      );
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        message: 'Call completed event processed',
      }),
    };
  } catch (error) {
    console.error('Error handling call completed event:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      }),
    };
  }
};
