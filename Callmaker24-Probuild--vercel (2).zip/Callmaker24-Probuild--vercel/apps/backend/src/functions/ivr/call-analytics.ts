/**
 * Lambda function for call analytics and reporting
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, QueryCommand } from '@aws-sdk/lib-dynamodb';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);
const CALLS_TABLE = process.env.CALLS_TABLE || 'calls';

interface CallAnalytics {
  totalCalls: number;
  inboundCalls: number;
  outboundCalls: number;
  completedCalls: number;
  failedCalls: number;
  averageDuration: number;
  totalDuration: number;
  callsByStatus: Record<string, number>;
  callsByDirection: Record<string, number>;
  callsByHour: Record<string, number>;
  callsByDay: Record<string, number>;
}

/**
 * Get call analytics for a date range
 */
export const getAnalytics: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: { code: 'UNAUTHORIZED', message: 'Tenant ID is required' },
        }),
      };
    }

    const queryParams = event.queryStringParameters || {};
    const startDate = queryParams.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    const endDate = queryParams.endDate || new Date().toISOString();

    // Query calls within date range
    const result = await docClient.send(
      new QueryCommand({
        TableName: CALLS_TABLE,
        IndexName: 'tenantId-createdAt-index',
        KeyConditionExpression: 'tenantId = :tenantId AND createdAt BETWEEN :startDate AND :endDate',
        ExpressionAttributeValues: {
          ':tenantId': tenantId,
          ':startDate': startDate,
          ':endDate': endDate,
        },
      })
    );

    const calls = result.Items || [];

    // Calculate analytics
    const analytics: CallAnalytics = {
      totalCalls: calls.length,
      inboundCalls: calls.filter((c: any) => c.direction === 'INBOUND').length,
      outboundCalls: calls.filter((c: any) => c.direction === 'OUTBOUND').length,
      completedCalls: calls.filter((c: any) => c.status === 'COMPLETED').length,
      failedCalls: calls.filter((c: any) => c.status === 'FAILED').length,
      averageDuration: 0,
      totalDuration: 0,
      callsByStatus: {},
      callsByDirection: {},
      callsByHour: {},
      callsByDay: {},
    };

    // Calculate durations
    const callsWithDuration = calls.filter((c: any) => c.duration);
    if (callsWithDuration.length > 0) {
      analytics.totalDuration = callsWithDuration.reduce((sum: number, c: any) => sum + (c.duration || 0), 0);
      analytics.averageDuration = Math.round(analytics.totalDuration / callsWithDuration.length);
    }

    // Group by status
    calls.forEach((call: any) => {
      const status = call.status || 'UNKNOWN';
      analytics.callsByStatus[status] = (analytics.callsByStatus[status] || 0) + 1;

      const direction = call.direction || 'UNKNOWN';
      analytics.callsByDirection[direction] = (analytics.callsByDirection[direction] || 0) + 1;

      // Group by hour
      const date = new Date(call.createdAt);
      const hour = date.getHours().toString().padStart(2, '0');
      analytics.callsByHour[hour] = (analytics.callsByHour[hour] || 0) + 1;

      // Group by day
      const day = date.toISOString().split('T')[0];
      analytics.callsByDay[day] = (analytics.callsByDay[day] || 0) + 1;
    });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          analytics,
          dateRange: {
            startDate,
            endDate,
          },
        },
      }),
    };
  } catch (error) {
    console.error('Error getting call analytics:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to get call analytics',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

/**
 * Get call details
 */
export const getCall: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const callId = event.pathParameters?.id;

    if (!tenantId || !callId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Call ID are required',
          },
        }),
      };
    }

    const result = await docClient.send(
      new QueryCommand({
        TableName: CALLS_TABLE,
        KeyConditionExpression: 'id = :id AND tenantId = :tenantId',
        ExpressionAttributeValues: {
          ':id': callId,
          ':tenantId': tenantId,
        },
      })
    );

    if (!result.Items || result.Items.length === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: { code: 'NOT_FOUND', message: 'Call not found' },
        }),
      };
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result.Items[0],
      }),
    };
  } catch (error) {
    console.error('Error getting call:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to get call details',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

/**
 * List calls with pagination
 */
export const listCalls: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: { code: 'UNAUTHORIZED', message: 'Tenant ID is required' },
        }),
      };
    }

    const queryParams = event.queryStringParameters || {};
    const limit = parseInt(queryParams.limit || '50');
    const direction = queryParams.direction; // INBOUND or OUTBOUND
    const status = queryParams.status; // INITIATED, IN_PROGRESS, COMPLETED, FAILED

    let filterExpression: string | undefined;
    let expressionAttributeValues: any = {
      ':tenantId': tenantId,
    };

    if (direction) {
      filterExpression = 'direction = :direction';
      expressionAttributeValues[':direction'] = direction;
    }

    if (status) {
      filterExpression = filterExpression
        ? `${filterExpression} AND #status = :status`
        : '#status = :status';
      expressionAttributeValues[':status'] = status;
    }

    const result = await docClient.send(
      new QueryCommand({
        TableName: CALLS_TABLE,
        IndexName: 'tenantId-createdAt-index',
        KeyConditionExpression: 'tenantId = :tenantId',
        ExpressionAttributeValues: expressionAttributeValues,
        ...(filterExpression && {
          FilterExpression: filterExpression,
          ExpressionAttributeNames: status ? { '#status': 'status' } : undefined,
        }),
        Limit: limit,
        ScanIndexForward: false, // Most recent first
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result.Items || [],
        pagination: {
          count: result.Items?.length || 0,
          lastEvaluatedKey: result.LastEvaluatedKey,
        },
      }),
    };
  } catch (error) {
    console.error('Error listing calls:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to list calls',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};
