/**
 * Lambda function to initiate outbound voice calls
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { initiateOutboundCall, formatPhoneNumber, createContactAttributes } from '../../lib/connect';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand } from '@aws-sdk/lib-dynamodb';
import { v4 as uuidv4 } from 'uuid';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);
const CALLS_TABLE = process.env.CALLS_TABLE || 'calls';

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const { phoneNumber, customerId, contactFlowId, attributes, tenantId } = body;

    if (!phoneNumber || !contactFlowId || !tenantId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Phone number, contact flow ID, and tenant ID are required',
          },
        }),
      };
    }

    const instanceId = process.env.CONNECT_INSTANCE_ID;

    if (!instanceId) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'CONFIGURATION_ERROR',
            message: 'Amazon Connect instance ID not configured',
          },
        }),
      };
    }

    // Format phone number to E.164
    const formattedPhoneNumber = formatPhoneNumber(phoneNumber);

    // Prepare contact attributes
    const contactAttributes = createContactAttributes({
      tenantId,
      customerId: customerId || '',
      callPurpose: attributes?.callPurpose || 'general',
      ...attributes,
    });

    // Initiate the call
    const result = await initiateOutboundCall({
      destinationPhoneNumber: formattedPhoneNumber,
      contactFlowId,
      instanceId,
      attributes: contactAttributes,
    });

    // Create call record
    const callRecord = {
      id: uuidv4(),
      connectContactId: result.contactId,
      customerId: customerId || '',
      direction: 'OUTBOUND',
      status: 'INITIATED',
      fromNumber: process.env.CONNECT_PHONE_NUMBER || '',
      toNumber: formattedPhoneNumber,
      contactFlowId,
      metadata: {
        attributes: contactAttributes,
      },
      tenantId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await docClient.send(
      new PutCommand({
        TableName: CALLS_TABLE,
        Item: callRecord,
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          callId: callRecord.id,
          contactId: result.contactId,
          status: 'INITIATED',
          phoneNumber: formattedPhoneNumber,
        },
      }),
    };
  } catch (error) {
    console.error('Error initiating call:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to initiate call',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};
