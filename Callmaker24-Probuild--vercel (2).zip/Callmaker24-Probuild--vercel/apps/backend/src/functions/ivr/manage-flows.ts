/**
 * Lambda functions to manage IVR flows
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand, GetCommand, QueryCommand, DeleteCommand } from '@aws-sdk/lib-dynamodb';
import { v4 as uuidv4 } from 'uuid';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);
const IVR_FLOWS_TABLE = process.env.IVR_FLOWS_TABLE || 'ivr-flows';

interface IVRStep {
  id: string;
  type: 'message' | 'menu' | 'input' | 'transfer' | 'callback' | 'voicemail' | 'hours' | 'queue';
  message?: string;
  audioUrl?: string;
  options?: Array<{
    digit: string;
    label: string;
    action: string;
    nextStepId?: string;
    transferNumber?: string;
  }>;
  inputConfig?: {
    maxDigits?: number;
    timeout?: number;
    validationRegex?: string;
  };
  transferTo?: string;
  queueId?: string;
  nextStepId?: string;
  condition?: {
    attribute: string;
    operator: 'equals' | 'contains' | 'greater_than' | 'less_than';
    value: string;
    trueStepId: string;
    falseStepId: string;
  };
}

interface IVRFlow {
  id: string;
  name: string;
  description?: string;
  steps: IVRStep[];
  entryStepId: string;
  isActive: boolean;
  connectContactFlowId?: string;
  tenantId: string;
  createdAt: string;
  updatedAt: string;
}

/**
 * CREATE IVR Flow
 */
export const createFlow: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: { code: 'UNAUTHORIZED', message: 'Tenant ID is required' },
        }),
      };
    }

    const body = JSON.parse(event.body || '{}');
    const { name, description, steps, entryStepId } = body;

    if (!name || !steps || !entryStepId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Name, steps, and entry step ID are required',
          },
        }),
      };
    }

    // Validate entry step exists
    const entryStep = steps.find((step: IVRStep) => step.id === entryStepId);
    if (!entryStep) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Entry step ID must reference a valid step',
          },
        }),
      };
    }

    const flow: IVRFlow = {
      id: uuidv4(),
      name,
      description,
      steps: steps.map((step: Partial<IVRStep>) => ({
        id: step.id || uuidv4(),
        ...step,
      })),
      entryStepId,
      isActive: false, // Default to inactive until explicitly activated
      tenantId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await docClient.send(
      new PutCommand({
        TableName: IVR_FLOWS_TABLE,
        Item: flow,
      })
    );

    return {
      statusCode: 201,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: flow,
      }),
    };
  } catch (error) {
    console.error('Error creating IVR flow:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to create IVR flow',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

/**
 * LIST IVR Flows
 */
export const listFlows: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: { code: 'UNAUTHORIZED', message: 'Tenant ID is required' },
        }),
      };
    }

    const result = await docClient.send(
      new QueryCommand({
        TableName: IVR_FLOWS_TABLE,
        IndexName: 'tenantId-index',
        KeyConditionExpression: 'tenantId = :tenantId',
        ExpressionAttributeValues: {
          ':tenantId': tenantId,
        },
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result.Items || [],
      }),
    };
  } catch (error) {
    console.error('Error listing IVR flows:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to list IVR flows',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

/**
 * GET IVR Flow
 */
export const getFlow: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const flowId = event.pathParameters?.id;

    if (!tenantId || !flowId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Flow ID are required',
          },
        }),
      };
    }

    const result = await docClient.send(
      new GetCommand({
        TableName: IVR_FLOWS_TABLE,
        Key: { id: flowId, tenantId },
      })
    );

    if (!result.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: { code: 'NOT_FOUND', message: 'IVR flow not found' },
        }),
      };
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result.Item,
      }),
    };
  } catch (error) {
    console.error('Error getting IVR flow:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to get IVR flow',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

/**
 * UPDATE IVR Flow
 */
export const updateFlow: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const flowId = event.pathParameters?.id;

    if (!tenantId || !flowId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Flow ID are required',
          },
        }),
      };
    }

    const body = JSON.parse(event.body || '{}');
    const { name, description, steps, entryStepId, isActive, connectContactFlowId } = body;

    // Get existing flow
    const existing = await docClient.send(
      new GetCommand({
        TableName: IVR_FLOWS_TABLE,
        Key: { id: flowId, tenantId },
      })
    );

    if (!existing.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: { code: 'NOT_FOUND', message: 'IVR flow not found' },
        }),
      };
    }

    // Validate entry step if provided
    if (steps && entryStepId) {
      const entryStep = steps.find((step: IVRStep) => step.id === entryStepId);
      if (!entryStep) {
        return {
          statusCode: 400,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'INVALID_REQUEST',
              message: 'Entry step ID must reference a valid step',
            },
          }),
        };
      }
    }

    const updated = {
      ...existing.Item,
      ...(name && { name }),
      ...(description !== undefined && { description }),
      ...(steps && { steps }),
      ...(entryStepId && { entryStepId }),
      ...(typeof isActive === 'boolean' && { isActive }),
      ...(connectContactFlowId && { connectContactFlowId }),
      updatedAt: new Date().toISOString(),
    };

    await docClient.send(
      new PutCommand({
        TableName: IVR_FLOWS_TABLE,
        Item: updated,
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: updated,
      }),
    };
  } catch (error) {
    console.error('Error updating IVR flow:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to update IVR flow',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

/**
 * DELETE IVR Flow
 */
export const deleteFlow: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const flowId = event.pathParameters?.id;

    if (!tenantId || !flowId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Flow ID are required',
          },
        }),
      };
    }

    await docClient.send(
      new DeleteCommand({
        TableName: IVR_FLOWS_TABLE,
        Key: { id: flowId, tenantId },
      })
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        message: 'IVR flow deleted successfully',
      }),
    };
  } catch (error) {
    console.error('Error deleting IVR flow:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to delete IVR flow',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};

/**
 * Execute IVR Flow step (called by Connect contact flow)
 */
export const executeStep: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const { flowId, stepId, input, tenantId } = body;

    if (!flowId || !stepId || !tenantId) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Flow ID, Step ID, and Tenant ID are required',
          },
        }),
      };
    }

    // Get flow
    const flowResult = await docClient.send(
      new GetCommand({
        TableName: IVR_FLOWS_TABLE,
        Key: { id: flowId, tenantId },
      })
    );

    if (!flowResult.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: { code: 'NOT_FOUND', message: 'IVR flow not found' },
        }),
      };
    }

    const flow = flowResult.Item as IVRFlow;
    const step = flow.steps.find((s) => s.id === stepId);

    if (!step) {
      return {
        statusCode: 404,
        body: JSON.stringify({
          success: false,
          error: { code: 'NOT_FOUND', message: 'Step not found in flow' },
        }),
      };
    }

    // Process step based on type
    let nextStepId: string | null = null;
    let response: any = {
      stepType: step.type,
    };

    switch (step.type) {
      case 'message':
        response.message = step.message;
        response.audioUrl = step.audioUrl;
        nextStepId = step.nextStepId || null;
        break;

      case 'menu':
        response.message = step.message;
        response.options = step.options;
        // Next step determined by user input
        if (input && step.options) {
          const selectedOption = step.options.find((opt) => opt.digit === input);
          if (selectedOption) {
            nextStepId = selectedOption.nextStepId || null;
            response.selectedOption = selectedOption;
          }
        }
        break;

      case 'input':
        response.message = step.message;
        response.inputConfig = step.inputConfig;
        response.capturedInput = input;
        nextStepId = step.nextStepId || null;
        break;

      case 'transfer':
        response.transferNumber = step.transferTo;
        nextStepId = null; // End of flow
        break;

      case 'callback':
        response.action = 'callback_requested';
        nextStepId = step.nextStepId || null;
        break;

      default:
        response.message = 'Unknown step type';
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          currentStep: step,
          nextStepId,
          response,
        },
      }),
    };
  } catch (error) {
    console.error('Error executing IVR step:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to execute IVR step',
          details: error instanceof Error ? error.message : 'Unknown error',
        },
      }),
    };
  }
};
