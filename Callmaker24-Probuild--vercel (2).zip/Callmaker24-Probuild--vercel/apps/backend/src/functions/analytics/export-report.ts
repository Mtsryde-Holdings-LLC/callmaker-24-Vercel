import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { v4 as uuidv4 } from 'uuid';
import PDFDocument from 'pdfkit';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const s3Client = new S3Client({});
const campaignsTable = process.env.CAMPAIGNS_TABLE_NAME!;
const messagesTable = process.env.MESSAGES_TABLE_NAME!;
const bucketName = process.env.S3_BUCKET_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'MISSING_TENANT_ID',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    const body = JSON.parse(event.body || '{}');
    const timeRange = body.timeRange || '30d';
    const format = body.format || 'csv'; // csv or pdf
    const reportType = body.reportType || 'dashboard'; // dashboard, campaign, customer

    // Calculate date range
    const now = new Date();
    const startDate = new Date();

    switch (timeRange) {
      case '7d':
        startDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(now.getDate() - 90);
        break;
      case '1y':
        startDate.setFullYear(now.getFullYear() - 1);
        break;
      default:
        startDate.setDate(now.getDate() - 30);
    }

    const startDateISO = startDate.toISOString();

    // Fetch data based on report type
    let reportData: any;

    if (reportType === 'dashboard') {
      // Get campaigns
      const campaignsResult = await dynamoDb.query({
        TableName: campaignsTable,
        IndexName: 'TenantIndex',
        KeyConditionExpression: '#tenantId = :tenantId',
        FilterExpression: '#createdAt >= :startDate',
        ExpressionAttributeNames: {
          '#tenantId': 'tenantId',
          '#createdAt': 'createdAt',
        },
        ExpressionAttributeValues: {
          ':tenantId': tenantId,
          ':startDate': startDateISO,
        },
      });

      const campaigns = campaignsResult.Items || [];

      // Get messages
      const messagesResult = await dynamoDb.query({
        TableName: messagesTable,
        IndexName: 'TenantDateIndex',
        KeyConditionExpression: '#tenantId = :tenantId AND #sentAt >= :startDate',
        ExpressionAttributeNames: {
          '#tenantId': 'tenantId',
          '#sentAt': 'sentAt',
        },
        ExpressionAttributeValues: {
          ':tenantId': tenantId,
          ':startDate': startDateISO,
        },
      });

      const messages = messagesResult.Items || [];

      reportData = {
        summary: {
          totalCampaigns: campaigns.length,
          totalMessages: messages.length,
          emailsSent: messages.filter((m) => m.type === 'EMAIL').length,
          smsSent: messages.filter((m) => m.type === 'SMS').length,
        },
        campaigns: campaigns.map((c) => ({
          name: c.name,
          type: c.type,
          status: c.status,
          sent: c.analytics?.summary?.totalSent || 0,
          openRate: c.analytics?.rates?.openRate || 0,
          clickRate: c.analytics?.rates?.clickRate || 0,
        })),
      };
    }

    // Generate export content
    let exportContent: Buffer | string;
    let contentType: string;
    let fileExtension: string;

    if (format === 'csv') {
      // Generate CSV
      const headers = ['Campaign Name', 'Type', 'Status', 'Sent', 'Open Rate', 'Click Rate'];
      const csvRows = [headers.join(',')];

      if (reportData.campaigns) {
        reportData.campaigns.forEach((campaign: any) => {
          const row = [
            campaign.name,
            campaign.type,
            campaign.status,
            campaign.sent,
            `${(campaign.openRate * 100).toFixed(2)}%`,
            `${(campaign.clickRate * 100).toFixed(2)}%`,
          ];
          csvRows.push(row.join(','));
        });
      }

      exportContent = csvRows.join('\n');
      contentType = 'text/csv';
      fileExtension = 'csv';
    } else if (format === 'pdf') {
      // Generate PDF
      const doc = new PDFDocument();
      const chunks: Buffer[] = [];

      doc.on('data', (chunk: Buffer) => chunks.push(chunk));

      // Add content to PDF
      doc.fontSize(20).text('Analytics Report', { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).text(`Report Period: ${startDate.toLocaleDateString()} - ${now.toLocaleDateString()}`);
      doc.moveDown();

      // Summary
      doc.fontSize(16).text('Summary');
      doc.fontSize(12);
      doc.text(`Total Campaigns: ${reportData.summary.totalCampaigns}`);
      doc.text(`Total Messages: ${reportData.summary.totalMessages}`);
      doc.text(`Emails Sent: ${reportData.summary.emailsSent}`);
      doc.text(`SMS Sent: ${reportData.summary.smsSent}`);
      doc.moveDown();

      // Campaign details
      if (reportData.campaigns && reportData.campaigns.length > 0) {
        doc.fontSize(16).text('Campaign Performance');
        doc.fontSize(10);

        reportData.campaigns.slice(0, 20).forEach((campaign: any) => {
          doc.text(`${campaign.name} (${campaign.type})`);
          doc.text(`  Status: ${campaign.status}, Sent: ${campaign.sent}`);
          doc.text(`  Open Rate: ${(campaign.openRate * 100).toFixed(2)}%, Click Rate: ${(campaign.clickRate * 100).toFixed(2)}%`);
          doc.moveDown(0.5);
        });
      }

      doc.end();

      // Wait for PDF to finish
      await new Promise((resolve) => {
        doc.on('end', resolve);
      });

      exportContent = Buffer.concat(chunks);
      contentType = 'application/pdf';
      fileExtension = 'pdf';
    } else {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_FORMAT',
            message: 'Supported formats: csv, pdf',
          },
        }),
      };
    }

    // Upload to S3
    const fileName = `exports/reports/${tenantId}/${reportType}-${uuidv4()}.${fileExtension}`;
    const uploadCommand = new PutObjectCommand({
      Bucket: bucketName,
      Key: fileName,
      Body: exportContent,
      ContentType: contentType,
      Metadata: {
        tenantId,
        reportType,
        timeRange,
        exportedAt: new Date().toISOString(),
      },
    });

    await s3Client.send(uploadCommand);

    // Generate presigned URL for download (valid for 1 hour)
    const downloadUrl = await getSignedUrl(
      s3Client,
      new PutObjectCommand({
        Bucket: bucketName,
        Key: fileName,
      }),
      { expiresIn: 3600 }
    );

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: {
          downloadUrl,
          fileName,
          format,
          reportType,
          expiresIn: 3600,
        },
      }),
    };
  } catch (error) {
    console.error('Error exporting report:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to export report',
        },
      }),
    };
  }
};
