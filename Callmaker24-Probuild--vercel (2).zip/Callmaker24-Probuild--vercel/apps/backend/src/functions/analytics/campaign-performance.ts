import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const campaignsTable = process.env.CAMPAIGNS_TABLE_NAME!;
const messagesTable = process.env.MESSAGES_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'MISSING_TENANT_ID',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    const queryParams = event.queryStringParameters || {};
    const timeRange = queryParams.timeRange || '30d';
    const sortBy = queryParams.sortBy || 'openRate'; // openRate, clickRate, sent
    const limit = parseInt(queryParams.limit || '20', 10);

    // Calculate date range
    const now = new Date();
    const startDate = new Date();

    switch (timeRange) {
      case '7d':
        startDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(now.getDate() - 90);
        break;
      case '1y':
        startDate.setFullYear(now.getFullYear() - 1);
        break;
      default:
        startDate.setDate(now.getDate() - 30);
    }

    const startDateISO = startDate.toISOString();

    // Get campaigns sent in the date range
    const campaignsResult = await dynamoDb.query({
      TableName: campaignsTable,
      IndexName: 'TenantIndex',
      KeyConditionExpression: '#tenantId = :tenantId',
      FilterExpression: '#status = :status AND #sentAt >= :startDate',
      ExpressionAttributeNames: {
        '#tenantId': 'tenantId',
        '#status': 'status',
        '#sentAt': 'sentAt',
      },
      ExpressionAttributeValues: {
        ':tenantId': tenantId,
        ':status': 'SENT',
        ':startDate': startDateISO,
      },
    });

    const campaigns = campaignsResult.Items || [];

    // For each campaign, get message statistics
    const campaignPerformance = await Promise.all(
      campaigns.map(async (campaign) => {
        // Get messages for this campaign
        const messagesResult = await dynamoDb.query({
          TableName: messagesTable,
          IndexName: 'CampaignIndex',
          KeyConditionExpression: '#campaignId = :campaignId',
          ExpressionAttributeNames: {
            '#campaignId': 'campaignId',
          },
          ExpressionAttributeValues: {
            ':campaignId': campaign.id,
          },
        });

        const messages = messagesResult.Items || [];
        const sent = messages.length;
        const delivered = messages.filter((m) => m.status === 'DELIVERED').length;
        const opened = messages.filter((m) => m.openedAt).length;
        const clicked = messages.filter((m) => m.clickedAt).length;
        const bounced = messages.filter((m) => m.status === 'BOUNCED').length;
        const conversions = messages.filter((m) => m.converted).length;

        const openRate = delivered > 0 ? opened / delivered : 0;
        const clickRate = delivered > 0 ? clicked / delivered : 0;
        const bounceRate = sent > 0 ? bounced / sent : 0;
        const conversionRate = delivered > 0 ? conversions / delivered : 0;

        return {
          id: campaign.id,
          name: campaign.name,
          type: campaign.type,
          sentAt: campaign.sentAt,
          sent,
          delivered,
          opened,
          clicked,
          bounced,
          conversions,
          openRate,
          clickRate,
          bounceRate,
          conversionRate,
        };
      })
    );

    // Sort by specified metric
    campaignPerformance.sort((a, b) => {
      switch (sortBy) {
        case 'openRate':
          return b.openRate - a.openRate;
        case 'clickRate':
          return b.clickRate - a.clickRate;
        case 'sent':
          return b.sent - a.sent;
        case 'conversions':
          return b.conversions - a.conversions;
        default:
          return b.openRate - a.openRate;
      }
    });

    // Apply limit
    const topCampaigns = campaignPerformance.slice(0, limit);

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: topCampaigns,
      }),
    };
  } catch (error) {
    console.error('Error calculating campaign performance:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          // Security: Generic error message to prevent information leakage
          // Detailed errors are logged for debugging purposes
          message: 'Failed to calculate campaign performance',
        },
      }),
    };
  }
};
