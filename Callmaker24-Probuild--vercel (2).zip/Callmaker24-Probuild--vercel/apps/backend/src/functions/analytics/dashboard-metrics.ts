import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const campaignsTable = process.env.CAMPAIGNS_TABLE_NAME!;
const customersTable = process.env.CUSTOMERS_TABLE_NAME!;
const messagesTable = process.env.MESSAGES_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'MISSING_TENANT_ID',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    const queryParams = event.queryStringParameters || {};
    const timeRange = queryParams.timeRange || '30d';

    // Calculate date range
    const now = new Date();
    const startDate = new Date();

    switch (timeRange) {
      case '7d':
        startDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(now.getDate() - 90);
        break;
      case '1y':
        startDate.setFullYear(now.getFullYear() - 1);
        break;
      default:
        startDate.setDate(now.getDate() - 30);
    }

    const startDateISO = startDate.toISOString();

    // Get all campaigns
    const campaignsResult = await dynamoDb.query({
      TableName: campaignsTable,
      IndexName: 'TenantIndex',
      KeyConditionExpression: '#tenantId = :tenantId',
      ExpressionAttributeNames: {
        '#tenantId': 'tenantId',
      },
      ExpressionAttributeValues: {
        ':tenantId': tenantId,
      },
    });

    const allCampaigns = campaignsResult.Items || [];
    const recentCampaigns = allCampaigns.filter(
      (c) => c.createdAt && c.createdAt >= startDateISO
    );

    // Get all customers
    const customersResult = await dynamoDb.query({
      TableName: customersTable,
      IndexName: 'TenantIndex',
      KeyConditionExpression: '#tenantId = :tenantId',
      ExpressionAttributeNames: {
        '#tenantId': 'tenantId',
      },
      ExpressionAttributeValues: {
        ':tenantId': tenantId,
      },
    });

    const allCustomers = customersResult.Items || [];
    const activeCustomers = allCustomers.filter((c) => c.status === 'ACTIVE');

    // Get messages in date range
    let messages: any[] = [];
    let lastEvaluatedKey: any = undefined;

    do {
      const messagesResult = await dynamoDb.query({
        TableName: messagesTable,
        IndexName: 'TenantDateIndex',
        KeyConditionExpression: '#tenantId = :tenantId AND #sentAt >= :startDate',
        ExpressionAttributeNames: {
          '#tenantId': 'tenantId',
          '#sentAt': 'sentAt',
        },
        ExpressionAttributeValues: {
          ':tenantId': tenantId,
          ':startDate': startDateISO,
        },
        ExclusiveStartKey: lastEvaluatedKey,
      });

      messages = messages.concat(messagesResult.Items || []);
      lastEvaluatedKey = messagesResult.LastEvaluatedKey;
    } while (lastEvaluatedKey);

    // Calculate email metrics
    const emailMessages = messages.filter((m) => m.type === 'EMAIL');
    const smsMessages = messages.filter((m) => m.type === 'SMS');

    const emailsSent = emailMessages.length;
    const smsSent = smsMessages.length;

    const emailsDelivered = emailMessages.filter((m) => m.status === 'DELIVERED').length;
    const emailsOpened = emailMessages.filter((m) => m.openedAt).length;
    const emailsClicked = emailMessages.filter((m) => m.clickedAt).length;

    const avgOpenRate = emailsDelivered > 0 ? emailsOpened / emailsDelivered : 0;
    const avgClickRate = emailsDelivered > 0 ? emailsClicked / emailsDelivered : 0;

    // Calculate engagement metrics
    const engagedCustomers = new Set();
    messages.forEach((m) => {
      if (m.openedAt || m.clickedAt || m.repliedAt) {
        engagedCustomers.add(m.customerId);
      }
    });

    const avgEngagementRate =
      activeCustomers.length > 0 ? engagedCustomers.size / activeCustomers.length : 0;

    // Calculate revenue (placeholder - would come from billing/subscriptions table)
    const totalRevenue = activeCustomers.length * 99; // Assuming $99/month average

    // Calculate subscription metrics
    const activeSubscriptions = activeCustomers.filter((c) => c.subscriptionStatus === 'ACTIVE')
      .length;

    const churnedCustomers = allCustomers.filter(
      (c) => c.subscriptionStatus === 'CANCELED' && c.updatedAt >= startDateISO
    ).length;

    const churnRate = activeSubscriptions > 0 ? churnedCustomers / activeSubscriptions : 0;

    const metrics = {
      totalCampaigns: recentCampaigns.length,
      totalCustomers: activeCustomers.length,
      totalRevenue,
      avgEngagementRate,
      emailsSent,
      smsSent,
      avgOpenRate,
      avgClickRate,
      activeSubscriptions,
      churnRate,
      timeRange,
      startDate: startDateISO,
      endDate: now.toISOString(),
    };

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: metrics,
      }),
    };
  } catch (error) {
    console.error('Error calculating dashboard metrics:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to calculate dashboard metrics',
        },
      }),
    };
  }
};
