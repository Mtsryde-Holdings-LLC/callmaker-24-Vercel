import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const customersTable = process.env.CUSTOMERS_TABLE_NAME!;
const integrationsTable = process.env.INTEGRATIONS_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'MISSING_TENANT_ID',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    // Get Shopify integration credentials
    const integrationResult = await dynamoDb.query({
      TableName: integrationsTable,
      IndexName: 'TenantTypeIndex',
      KeyConditionExpression: '#tenantId = :tenantId AND #type = :type',
      ExpressionAttributeNames: {
        '#tenantId': 'tenantId',
        '#type': 'type',
      },
      ExpressionAttributeValues: {
        ':tenantId': tenantId,
        ':type': 'SHOPIFY',
      },
    });

    if (!integrationResult.Items || integrationResult.Items.length === 0) {
      return {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_CONFIGURED',
            message: 'Shopify integration not configured',
          },
        }),
      };
    }

    const integration = integrationResult.Items[0];
    const { shopDomain, accessToken } = integration.credentials || {};

    if (!shopDomain || !accessToken) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_CREDENTIALS',
            message: 'Shopify credentials are invalid',
          },
        }),
      };
    }

    // Fetch customers from Shopify
    const shopifyUrl = `https://${shopDomain}/admin/api/2024-01/customers.json`;
    const response = await axios.get(shopifyUrl, {
      headers: {
        'X-Shopify-Access-Token': accessToken,
        'Content-Type': 'application/json',
      },
    });

    const shopifyCustomers = response.data.customers || [];

    let imported = 0;
    let updated = 0;
    let errors = 0;

    // Sync each customer
    for (const shopifyCustomer of shopifyCustomers) {
      try {
        const email = shopifyCustomer.email;
        if (!email) continue;

        // Check if customer already exists
        const existingResult = await dynamoDb.query({
          TableName: customersTable,
          IndexName: 'EmailIndex',
          KeyConditionExpression: '#email = :email',
          ExpressionAttributeNames: {
            '#email': 'email',
          },
          ExpressionAttributeValues: {
            ':email': email,
          },
        });

        const now = new Date().toISOString();

        if (existingResult.Items && existingResult.Items.length > 0) {
          // Update existing customer
          const existingCustomer = existingResult.Items[0];

          await dynamoDb.update({
            TableName: customersTable,
            Key: {
              id: existingCustomer.id,
              tenantId,
            },
            UpdateExpression:
              'SET #firstName = :firstName, #lastName = :lastName, #phoneNumber = :phoneNumber, #totalSpent = :totalSpent, #ordersCount = :ordersCount, #updatedAt = :updatedAt, #shopifyData = :shopifyData',
            ExpressionAttributeNames: {
              '#firstName': 'firstName',
              '#lastName': 'lastName',
              '#phoneNumber': 'phoneNumber',
              '#totalSpent': 'totalSpent',
              '#ordersCount': 'ordersCount',
              '#updatedAt': 'updatedAt',
              '#shopifyData': 'shopifyData',
            },
            ExpressionAttributeValues: {
              ':firstName': shopifyCustomer.first_name || '',
              ':lastName': shopifyCustomer.last_name || '',
              ':phoneNumber': shopifyCustomer.phone || '',
              ':totalSpent': parseFloat(shopifyCustomer.total_spent || '0'),
              ':ordersCount': shopifyCustomer.orders_count || 0,
              ':updatedAt': now,
              ':shopifyData': {
                shopifyId: shopifyCustomer.id,
                syncedAt: now,
              },
            },
          });

          updated++;
        } else {
          // Create new customer
          const customerId = uuidv4();

          await dynamoDb.put({
            TableName: customersTable,
            Item: {
              id: customerId,
              tenantId,
              email,
              firstName: shopifyCustomer.first_name || '',
              lastName: shopifyCustomer.last_name || '',
              phoneNumber: shopifyCustomer.phone || '',
              status: 'ACTIVE',
              emailOptIn: shopifyCustomer.email_marketing_consent?.state === 'subscribed',
              smsOptIn: shopifyCustomer.sms_marketing_consent?.state === 'subscribed',
              totalSpent: parseFloat(shopifyCustomer.total_spent || '0'),
              ordersCount: shopifyCustomer.orders_count || 0,
              tags: shopifyCustomer.tags?.split(',').map((t: string) => t.trim()) || [],
              source: 'SHOPIFY',
              shopifyData: {
                shopifyId: shopifyCustomer.id,
                syncedAt: now,
              },
              createdAt: now,
              updatedAt: now,
            },
          });

          imported++;
        }
      } catch (customerError) {
        console.error('Error syncing customer:', customerError);
        errors++;
      }
    }

    // Update integration last sync time
    await dynamoDb.update({
      TableName: integrationsTable,
      Key: {
        id: integration.id,
        tenantId,
      },
      UpdateExpression: 'SET #lastSyncAt = :lastSyncAt',
      ExpressionAttributeNames: {
        '#lastSyncAt': 'lastSyncAt',
      },
      ExpressionAttributeValues: {
        ':lastSyncAt': new Date().toISOString(),
      },
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: {
          imported,
          updated,
          errors,
          total: shopifyCustomers.length,
        },
      }),
    };
  } catch (error: any) {
    console.error('Error syncing Shopify customers:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: error.message || 'Failed to sync Shopify customers',
        },
      }),
    };
  }
};
