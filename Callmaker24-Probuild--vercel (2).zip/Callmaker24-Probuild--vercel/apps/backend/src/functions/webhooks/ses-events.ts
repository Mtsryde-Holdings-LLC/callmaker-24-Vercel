import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const messagesTable = process.env.MESSAGES_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');

    // Handle SNS subscription confirmation
    if (body.Type === 'SubscriptionConfirmation') {
      console.log('SNS Subscription Confirmation:', body.SubscribeURL);
      // In production, you'd auto-confirm via HTTP request
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Subscription confirmation received' }),
      };
    }

    // Parse SNS message
    const message = JSON.parse(body.Message || '{}');
    const eventType = message.eventType || message.notificationType;

    if (!eventType) {
      console.log('Unknown event type:', message);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Event processed' }),
      };
    }

    // Extract message ID from SES
    const messageId = message.mail?.messageId;
    if (!messageId) {
      console.log('No message ID found');
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'No message ID' }),
      };
    }

    // Find message in DynamoDB by messageId in metadata
    const scanResult = await dynamoDb.scan({
      TableName: messagesTable,
      FilterExpression: '#metadata.#messageId = :messageId',
      ExpressionAttributeNames: {
        '#metadata': 'metadata',
        '#messageId': 'messageId',
      },
      ExpressionAttributeValues: {
        ':messageId': messageId,
      },
      Limit: 1,
    });

    if (!scanResult.Items || scanResult.Items.length === 0) {
      console.log('Message not found:', messageId);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Message not found' }),
      };
    }

    const dbMessage = scanResult.Items[0];
    const now = new Date().toISOString();

    // Update message based on event type
    let updates: any = { updatedAt: now };

    switch (eventType) {
      case 'Delivery':
        updates.status = 'DELIVERED';
        updates.deliveredAt = now;
        break;

      case 'Bounce':
        updates.status = 'BOUNCED';
        updates.bouncedAt = now;
        updates.bounceReason = message.bounce?.bouncedRecipients?.[0]?.diagnosticCode || 'Unknown';
        updates.bounceType = message.bounce?.bounceType || 'Unknown';
        break;

      case 'Complaint':
        updates.status = 'COMPLAINED';
        updates.complainedAt = now;
        break;

      case 'Open':
        if (!dbMessage.openedAt) {
          updates.openedAt = now;
          updates.openCount = 1;
        } else {
          updates.openCount = (dbMessage.openCount || 1) + 1;
        }
        // Track device/location if available
        if (message.open) {
          updates.openMetadata = {
            userAgent: message.open.userAgent,
            ipAddress: message.open.ipAddress,
            timestamp: now,
          };
        }
        break;

      case 'Click':
        if (!dbMessage.clickedAt) {
          updates.clickedAt = now;
          updates.clickCount = 1;
        } else {
          updates.clickCount = (dbMessage.clickCount || 1) + 1;
        }
        // Track clicked links
        if (message.click?.link) {
          const clickedLinks = dbMessage.clickedLinks || [];
          clickedLinks.push(message.click.link);
          updates.clickedLinks = clickedLinks;
        }
        break;

      case 'Reject':
        updates.status = 'REJECTED';
        updates.rejectedAt = now;
        updates.rejectReason = message.reject?.reason || 'Unknown';
        break;

      default:
        console.log('Unhandled event type:', eventType);
        return {
          statusCode: 200,
          body: JSON.stringify({ message: 'Event type not handled' }),
        };
    }

    // Build update expression dynamically
    const updateExpressions: string[] = [];
    const expressionAttributeNames: Record<string, string> = {};
    const expressionAttributeValues: Record<string, any> = {};

    Object.entries(updates).forEach(([key, value], index) => {
      const attrName = `#attr${index}`;
      const attrValue = `:val${index}`;
      updateExpressions.push(`${attrName} = ${attrValue}`);
      expressionAttributeNames[attrName] = key;
      expressionAttributeValues[attrValue] = value;
    });

    // Update message in DynamoDB
    await dynamoDb.update({
      TableName: messagesTable,
      Key: {
        id: dbMessage.id,
        tenantId: dbMessage.tenantId,
      },
      UpdateExpression: `SET ${updateExpressions.join(', ')}`,
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
    });

    console.log(`Updated message ${dbMessage.id} for event ${eventType}`);

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        message: 'Event processed',
      }),
    };
  } catch (error) {
    console.error('Error processing SES event:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: 'Failed to process event',
      }),
    };
  }
};
