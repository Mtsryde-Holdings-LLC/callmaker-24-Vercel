import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const messagesTable = process.env.MESSAGES_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');

    // Handle SNS subscription confirmation
    if (body.Type === 'SubscriptionConfirmation') {
      console.log('SNS Subscription Confirmation:', body.SubscribeURL);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Subscription confirmation received' }),
      };
    }

    // Parse SNS message
    const message = JSON.parse(body.Message || '{}');
    const status = message.status;
    const messageId = message.notification?.messageId;

    if (!messageId) {
      console.log('No message ID found');
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'No message ID' }),
      };
    }

    // Find message in DynamoDB
    const scanResult = await dynamoDb.scan({
      TableName: messagesTable,
      FilterExpression: '#metadata.#smsMessageId = :messageId',
      ExpressionAttributeNames: {
        '#metadata': 'metadata',
        '#smsMessageId': 'smsMessageId',
      },
      ExpressionAttributeValues: {
        ':messageId': messageId,
      },
      Limit: 1,
    });

    if (!scanResult.Items || scanResult.Items.length === 0) {
      console.log('SMS message not found:', messageId);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Message not found' }),
      };
    }

    const dbMessage = scanResult.Items[0];
    const now = new Date().toISOString();

    // Update message based on delivery status
    let updates: any = { updatedAt: now };

    switch (status) {
      case 'SUCCESS':
        updates.status = 'DELIVERED';
        updates.deliveredAt = now;
        break;

      case 'FAILURE':
        updates.status = 'FAILED';
        updates.failedAt = now;
        updates.failureReason =
          message.delivery?.providerResponse || 'SMS delivery failed';
        break;

      case 'OPTOUT':
        updates.status = 'OPTED_OUT';
        updates.optedOutAt = now;
        // Mark customer as SMS opted out
        // In production, you'd also update the customer record
        break;

      default:
        console.log('Unknown SMS status:', status);
        return {
          statusCode: 200,
          body: JSON.stringify({ message: 'Status not handled' }),
        };
    }

    // Track pricing if available
    if (message.delivery?.priceInUSD) {
      updates.cost = parseFloat(message.delivery.priceInUSD);
    }

    // Build update expression
    const updateExpressions: string[] = [];
    const expressionAttributeNames: Record<string, string> = {};
    const expressionAttributeValues: Record<string, any> = {};

    Object.entries(updates).forEach(([key, value], index) => {
      const attrName = `#attr${index}`;
      const attrValue = `:val${index}`;
      updateExpressions.push(`${attrName} = ${attrValue}`);
      expressionAttributeNames[attrName] = key;
      expressionAttributeValues[attrValue] = value;
    });

    // Update message
    await dynamoDb.update({
      TableName: messagesTable,
      Key: {
        id: dbMessage.id,
        tenantId: dbMessage.tenantId,
      },
      UpdateExpression: `SET ${updateExpressions.join(', ')}`,
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
    });

    console.log(`Updated SMS message ${dbMessage.id} with status ${status}`);

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        message: 'Event processed',
      }),
    };
  } catch (error) {
    console.error('Error processing SNS event:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: 'Failed to process event',
      }),
    };
  }
};
