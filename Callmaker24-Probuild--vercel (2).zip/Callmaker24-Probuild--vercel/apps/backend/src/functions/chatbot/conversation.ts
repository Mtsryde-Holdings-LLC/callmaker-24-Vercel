import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import { chatCompletion } from '../../lib/openai';
import { v4 as uuidv4 } from 'uuid';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const conversationsTable = process.env.CONVERSATIONS_TABLE_NAME!;
const messagesTable = process.env.MESSAGES_TABLE_NAME!;

const SYSTEM_PROMPT = `You are a helpful customer support assistant. Your role is to:
1. Answer customer questions about products and services
2. Help with order tracking and account issues
3. Provide troubleshooting assistance
4. Escalate complex issues to human agents when necessary

Guidelines:
- Be friendly, professional, and empathetic
- Keep responses concise (2-3 sentences max)
- If you can't help, offer to connect them with a human agent
- Never share sensitive information or make promises about refunds/discounts
- Always confirm you understand the customer's issue before providing solutions`;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const body = JSON.parse(event.body || '{}');

    const { conversationId, customerId, message } = body;

    if (!tenantId || !customerId || !message) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'tenantId, customerId, and message are required',
          },
        }),
      };
    }

    let conversation: any;
    let conversationHistory: any[] = [];

    if (conversationId) {
      // Get existing conversation
      const convResult = await dynamoDb.get({
        TableName: conversationsTable,
        Key: { id: conversationId, tenantId },
      });

      conversation = convResult.Item;

      if (!conversation) {
        return {
          statusCode: 404,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            success: false,
            error: {
              code: 'NOT_FOUND',
              message: 'Conversation not found',
            },
          }),
        };
      }

      // Get message history
      const messagesResult = await dynamoDb.query({
        TableName: messagesTable,
        IndexName: 'ConversationIndex',
        KeyConditionExpression: '#conversationId = :conversationId',
        ExpressionAttributeNames: {
          '#conversationId': 'conversationId',
        },
        ExpressionAttributeValues: {
          ':conversationId': conversationId,
        },
        Limit: 20,
        ScanIndexForward: true,
      });

      conversationHistory = messagesResult.Items || [];
    } else {
      // Create new conversation
      const newConversationId = uuidv4();
      conversation = {
        id: newConversationId,
        tenantId,
        customerId,
        status: 'OPEN',
        type: 'CHATBOT',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await dynamoDb.put({
        TableName: conversationsTable,
        Item: conversation,
      });
    }

    // Save customer message
    const customerMessageId = uuidv4();
    const now = new Date().toISOString();

    const customerMessage = {
      id: customerMessageId,
      conversationId: conversation.id,
      tenantId,
      customerId,
      content: message,
      type: 'TEXT',
      sender: 'CUSTOMER',
      status: 'SENT',
      createdAt: now,
      sentAt: now,
    };

    await dynamoDb.put({
      TableName: messagesTable,
      Item: customerMessage,
    });

    // Build OpenAI conversation history
    const messages = [
      { role: 'system', content: SYSTEM_PROMPT },
      ...conversationHistory.map((msg) => ({
        role: msg.sender === 'CUSTOMER' ? 'user' : 'assistant',
        content: msg.content,
      })),
      { role: 'user', content: message },
    ];

    // Get AI response
    const aiResponse = await chatCompletion({
      messages: messages as any,
      maxTokens: 150,
      temperature: 0.7,
    });

    const botReply = aiResponse.content;

    // Check if bot wants to escalate to human
    const shouldEscalate =
      botReply.toLowerCase().includes('connect you with') ||
      botReply.toLowerCase().includes('human agent') ||
      botReply.toLowerCase().includes('transfer you');

    // Save bot message
    const botMessageId = uuidv4();
    const botMessage = {
      id: botMessageId,
      conversationId: conversation.id,
      tenantId,
      content: botReply,
      type: 'TEXT',
      sender: 'BOT',
      status: 'SENT',
      createdAt: new Date().toISOString(),
      sentAt: new Date().toISOString(),
      metadata: {
        model: aiResponse.model || 'gpt-4',
        tokensUsed: aiResponse.usage?.totalTokens || 0,
        cost: aiResponse.cost || 0,
      },
    };

    await dynamoDb.put({
      TableName: messagesTable,
      Item: botMessage,
    });

    // Update conversation status if escalating
    if (shouldEscalate) {
      await dynamoDb.update({
        TableName: conversationsTable,
        Key: { id: conversation.id, tenantId },
        UpdateExpression: 'SET #status = :status, #updatedAt = :updatedAt',
        ExpressionAttributeNames: {
          '#status': 'status',
          '#updatedAt': 'updatedAt',
        },
        ExpressionAttributeValues: {
          ':status': 'PENDING',
          ':updatedAt': new Date().toISOString(),
        },
      });
    } else {
      // Just update the timestamp
      await dynamoDb.update({
        TableName: conversationsTable,
        Key: { id: conversation.id, tenantId },
        UpdateExpression: 'SET #updatedAt = :updatedAt',
        ExpressionAttributeNames: {
          '#updatedAt': 'updatedAt',
        },
        ExpressionAttributeValues: {
          ':updatedAt': new Date().toISOString(),
        },
      });
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: {
          conversationId: conversation.id,
          message: botMessage,
          escalated: shouldEscalate,
        },
      }),
    };
  } catch (error: any) {
    console.error('Error in chatbot conversation:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: error.message || 'Failed to process conversation',
        },
      }),
    };
  }
};
