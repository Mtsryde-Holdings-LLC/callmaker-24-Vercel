import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import { createSubscription } from '../../lib/stripe';
import { v4 as uuidv4 } from 'uuid';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const subscriptionsTable = process.env.SUBSCRIPTIONS_TABLE_NAME!;

interface CreateSubscriptionRequest {
  planId: string; // Stripe price ID
  paymentMethodId?: string;
  trialDays?: number;
}

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const userId = event.requestContext.authorizer?.claims?.sub;

    if (!tenantId || !userId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and User ID are required',
          },
        }),
      };
    }

    const body: CreateSubscriptionRequest = JSON.parse(event.body || '{}');

    if (!body.planId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'planId is required',
          },
        }),
      };
    }

    // Get user's Stripe customer ID from DynamoDB
    // In production, you'd query the users table
    const stripeCustomerId = `cus_${userId.slice(0, 14)}`;

    // Create subscription in Stripe
    const stripeSubscription = await createSubscription({
      customerId: stripeCustomerId,
      priceId: body.planId,
      trialDays: body.trialDays,
      paymentMethodId: body.paymentMethodId,
    });

    // Store subscription in DynamoDB
    const subscriptionId = uuidv4();
    const now = new Date().toISOString();

    const subscription = {
      id: subscriptionId,
      tenantId,
      userId,
      stripeSubscriptionId: stripeSubscription.id,
      stripeCustomerId,
      planId: body.planId,
      status: stripeSubscription.status,
      currentPeriodStart: new Date(stripeSubscription.current_period_start * 1000).toISOString(),
      currentPeriodEnd: new Date(stripeSubscription.current_period_end * 1000).toISOString(),
      cancelAtPeriodEnd: stripeSubscription.cancel_at_period_end,
      createdAt: now,
      updatedAt: now,
    };

    await dynamoDb.put({
      TableName: subscriptionsTable,
      Item: subscription,
    });

    return {
      statusCode: 201,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: subscription,
      }),
    };
  } catch (error: any) {
    console.error('Error creating subscription:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: error.message || 'Failed to create subscription',
        },
      }),
    };
  }
};
