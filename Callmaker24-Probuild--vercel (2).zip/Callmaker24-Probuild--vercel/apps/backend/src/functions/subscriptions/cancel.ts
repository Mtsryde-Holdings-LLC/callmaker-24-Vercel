import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import { cancelSubscription } from '../../lib/stripe';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const subscriptionsTable = process.env.SUBSCRIPTIONS_TABLE_NAME!;

interface CancelSubscriptionRequest {
  immediately?: boolean; // Cancel immediately or at period end
  reason?: string;
}

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const subscriptionId = event.pathParameters?.id;

    if (!tenantId || !subscriptionId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Subscription ID are required',
          },
        }),
      };
    }

    const body: CancelSubscriptionRequest = JSON.parse(event.body || '{}');

    // Get subscription
    const result = await dynamoDb.get({
      TableName: subscriptionsTable,
      Key: { id: subscriptionId, tenantId },
    });

    if (!result.Item) {
      return {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Subscription not found',
          },
        }),
      };
    }

    const subscription = result.Item;

    // Cancel in Stripe
    const stripeSubscription = await cancelSubscription({
      subscriptionId: subscription.stripeSubscriptionId,
      immediately: body.immediately,
    });

    // Update in DynamoDB
    const updates: any = {
      status: stripeSubscription.status,
      cancelAtPeriodEnd: stripeSubscription.cancel_at_period_end,
      updatedAt: new Date().toISOString(),
    };

    if (body.reason) {
      updates.cancellationReason = body.reason;
    }

    if (body.immediately) {
      updates.canceledAt = new Date().toISOString();
    }

    await dynamoDb.update({
      TableName: subscriptionsTable,
      Key: { id: subscriptionId, tenantId },
      UpdateExpression:
        'SET #status = :status, #cancelAtPeriodEnd = :cancelAtPeriodEnd, #updatedAt = :updatedAt' +
        (body.reason ? ', #cancellationReason = :cancellationReason' : '') +
        (body.immediately ? ', #canceledAt = :canceledAt' : ''),
      ExpressionAttributeNames: {
        '#status': 'status',
        '#cancelAtPeriodEnd': 'cancelAtPeriodEnd',
        '#updatedAt': 'updatedAt',
        ...(body.reason && { '#cancellationReason': 'cancellationReason' }),
        ...(body.immediately && { '#canceledAt': 'canceledAt' }),
      },
      ExpressionAttributeValues: {
        ':status': updates.status,
        ':cancelAtPeriodEnd': updates.cancelAtPeriodEnd,
        ':updatedAt': updates.updatedAt,
        ...(body.reason && { ':cancellationReason': updates.cancellationReason }),
        ...(body.immediately && { ':canceledAt': updates.canceledAt }),
      },
      ReturnValues: 'ALL_NEW',
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: {
          ...subscription,
          ...updates,
        },
      }),
    };
  } catch (error: any) {
    console.error('Error canceling subscription:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: error.message || 'Failed to cancel subscription',
        },
      }),
    };
  }
};
