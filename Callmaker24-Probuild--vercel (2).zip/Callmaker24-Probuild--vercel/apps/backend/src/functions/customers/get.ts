import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const customersTable = process.env.CUSTOMERS_TABLE_NAME!;
const messagesTable = process.env.MESSAGES_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const customerId = event.pathParameters?.id;

    if (!tenantId || !customerId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Customer ID are required',
          },
        }),
      };
    }

    // Get customer
    const result = await dynamoDb.get({
      TableName: customersTable,
      Key: { id: customerId, tenantId },
    });

    if (!result.Item) {
      return {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Customer not found',
          },
        }),
      };
    }

    const customer = result.Item;

    // Get customer's recent messages
    const messagesResult = await dynamoDb.query({
      TableName: messagesTable,
      IndexName: 'CustomerIndex',
      KeyConditionExpression: '#customerId = :customerId',
      ExpressionAttributeNames: {
        '#customerId': 'customerId',
      },
      ExpressionAttributeValues: {
        ':customerId': customerId,
      },
      Limit: 50,
      ScanIndexForward: false, // Most recent first
    });

    const messages = messagesResult.Items || [];

    // Calculate engagement metrics
    const totalMessages = messages.length;
    const emailMessages = messages.filter((m) => m.type === 'EMAIL');
    const smsMessages = messages.filter((m) => m.type === 'SMS');

    const emailOpens = emailMessages.filter((m) => m.openedAt).length;
    const emailClicks = emailMessages.filter((m) => m.clickedAt).length;

    const engagementMetrics = {
      totalMessages,
      emailMessages: emailMessages.length,
      smsMessages: smsMessages.length,
      emailOpenRate: emailMessages.length > 0 ? emailOpens / emailMessages.length : 0,
      emailClickRate: emailMessages.length > 0 ? emailClicks / emailMessages.length : 0,
      lastMessageAt: messages[0]?.sentAt || null,
    };

    // Build activity timeline
    const activities = messages.slice(0, 20).map((message) => ({
      id: message.id,
      type: message.type,
      status: message.status,
      campaignId: message.campaignId,
      sentAt: message.sentAt,
      openedAt: message.openedAt,
      clickedAt: message.clickedAt,
    }));

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: {
          ...customer,
          engagementMetrics,
          recentActivities: activities,
        },
      }),
    };
  } catch (error) {
    console.error('Error getting customer:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to get customer',
        },
      }),
    };
  }
};
