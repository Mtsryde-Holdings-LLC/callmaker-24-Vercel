import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const customersTable = process.env.CUSTOMERS_TABLE_NAME!;

interface UpdateCustomerRequest {
  firstName?: string;
  lastName?: string;
  email?: string;
  phoneNumber?: string;
  company?: string;
  status?: 'ACTIVE' | 'INACTIVE' | 'BLOCKED';
  emailOptIn?: boolean;
  smsOptIn?: boolean;
  tags?: string[];
  customFields?: Record<string, any>;
  metadata?: Record<string, any>;
}

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const customerId = event.pathParameters?.id;

    if (!tenantId || !customerId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Customer ID are required',
          },
        }),
      };
    }

    const body: UpdateCustomerRequest = JSON.parse(event.body || '{}');

    // Get existing customer
    const existingCustomer = await dynamoDb.get({
      TableName: customersTable,
      Key: { id: customerId, tenantId },
    });

    if (!existingCustomer.Item) {
      return {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Customer not found',
          },
        }),
      };
    }

    // Check if email is being changed and if it's already taken
    if (body.email && body.email !== existingCustomer.Item.email) {
      const emailCheck = await dynamoDb.query({
        TableName: customersTable,
        IndexName: 'EmailIndex',
        KeyConditionExpression: '#email = :email',
        ExpressionAttributeNames: {
          '#email': 'email',
        },
        ExpressionAttributeValues: {
          ':email': body.email,
        },
      });

      if (emailCheck.Items && emailCheck.Items.length > 0) {
        return {
          statusCode: 409,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            success: false,
            error: {
              code: 'EMAIL_EXISTS',
              message: 'A customer with this email already exists',
            },
          }),
        };
      }
    }

    // Build update expression
    const updateExpressions: string[] = [];
    const expressionAttributeNames: Record<string, string> = {};
    const expressionAttributeValues: Record<string, any> = {};

    if (body.firstName !== undefined) {
      updateExpressions.push('#firstName = :firstName');
      expressionAttributeNames['#firstName'] = 'firstName';
      expressionAttributeValues[':firstName'] = body.firstName;
    }

    if (body.lastName !== undefined) {
      updateExpressions.push('#lastName = :lastName');
      expressionAttributeNames['#lastName'] = 'lastName';
      expressionAttributeValues[':lastName'] = body.lastName;
    }

    if (body.email !== undefined) {
      updateExpressions.push('#email = :email');
      expressionAttributeNames['#email'] = 'email';
      expressionAttributeValues[':email'] = body.email;
    }

    if (body.phoneNumber !== undefined) {
      updateExpressions.push('#phoneNumber = :phoneNumber');
      expressionAttributeNames['#phoneNumber'] = 'phoneNumber';
      expressionAttributeValues[':phoneNumber'] = body.phoneNumber;
    }

    if (body.company !== undefined) {
      updateExpressions.push('#company = :company');
      expressionAttributeNames['#company'] = 'company';
      expressionAttributeValues[':company'] = body.company;
    }

    if (body.status !== undefined) {
      updateExpressions.push('#status = :status');
      expressionAttributeNames['#status'] = 'status';
      expressionAttributeValues[':status'] = body.status;
    }

    if (body.emailOptIn !== undefined) {
      updateExpressions.push('#emailOptIn = :emailOptIn');
      expressionAttributeNames['#emailOptIn'] = 'emailOptIn';
      expressionAttributeValues[':emailOptIn'] = body.emailOptIn;
    }

    if (body.smsOptIn !== undefined) {
      updateExpressions.push('#smsOptIn = :smsOptIn');
      expressionAttributeNames['#smsOptIn'] = 'smsOptIn';
      expressionAttributeValues[':smsOptIn'] = body.smsOptIn;
    }

    if (body.tags !== undefined) {
      updateExpressions.push('#tags = :tags');
      expressionAttributeNames['#tags'] = 'tags';
      expressionAttributeValues[':tags'] = body.tags;
    }

    if (body.customFields !== undefined) {
      updateExpressions.push('#customFields = :customFields');
      expressionAttributeNames['#customFields'] = 'customFields';
      expressionAttributeValues[':customFields'] = body.customFields;
    }

    if (body.metadata !== undefined) {
      updateExpressions.push('#metadata = :metadata');
      expressionAttributeNames['#metadata'] = 'metadata';
      expressionAttributeValues[':metadata'] = body.metadata;
    }

    // Always update updatedAt
    updateExpressions.push('#updatedAt = :updatedAt');
    expressionAttributeNames['#updatedAt'] = 'updatedAt';
    expressionAttributeValues[':updatedAt'] = new Date().toISOString();

    if (updateExpressions.length === 1) {
      // Only updatedAt would be updated
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'No fields to update',
          },
        }),
      };
    }

    // Update customer
    const result = await dynamoDb.update({
      TableName: customersTable,
      Key: { id: customerId, tenantId },
      UpdateExpression: `SET ${updateExpressions.join(', ')}`,
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
      ReturnValues: 'ALL_NEW',
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: result.Attributes,
      }),
    };
  } catch (error) {
    console.error('Error updating customer:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to update customer',
        },
      }),
    };
  }
};
