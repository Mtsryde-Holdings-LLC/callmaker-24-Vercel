import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { v4 as uuidv4 } from 'uuid';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const s3Client = new S3Client({});
const customersTable = process.env.CUSTOMERS_TABLE_NAME!;
const bucketName = process.env.S3_BUCKET_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'MISSING_TENANT_ID',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    const queryParams = event.queryStringParameters || {};
    const format = queryParams.format || 'csv';
    const status = queryParams.status;
    const tags = queryParams.tags?.split(',');

    // Get all customers for the tenant
    let customers: any[] = [];
    let lastEvaluatedKey: any = undefined;

    do {
      const result = await dynamoDb.query({
        TableName: customersTable,
        IndexName: 'TenantIndex',
        KeyConditionExpression: '#tenantId = :tenantId',
        ExpressionAttributeNames: {
          '#tenantId': 'tenantId',
        },
        ExpressionAttributeValues: {
          ':tenantId': tenantId,
        },
        ExclusiveStartKey: lastEvaluatedKey,
      });

      customers = customers.concat(result.Items || []);
      lastEvaluatedKey = result.LastEvaluatedKey;
    } while (lastEvaluatedKey);

    // Filter by status if provided
    if (status) {
      customers = customers.filter((c) => c.status === status);
    }

    // Filter by tags if provided
    if (tags && tags.length > 0) {
      customers = customers.filter((c) =>
        tags.some((tag) => c.tags && c.tags.includes(tag))
      );
    }

    // Generate export content
    let exportContent: string;
    let contentType: string;
    let fileExtension: string;

    if (format === 'csv') {
      // CSV headers
      const headers = [
        'ID',
        'First Name',
        'Last Name',
        'Email',
        'Phone Number',
        'Company',
        'Status',
        'Email Opt-in',
        'SMS Opt-in',
        'Tags',
        'Created At',
        'Updated At',
      ];

      const csvRows = [headers.join(',')];

      customers.forEach((customer) => {
        const row = [
          customer.id,
          customer.firstName || '',
          customer.lastName || '',
          customer.email || '',
          customer.phoneNumber || '',
          customer.company || '',
          customer.status || '',
          customer.emailOptIn ? 'Yes' : 'No',
          customer.smsOptIn ? 'Yes' : 'No',
          customer.tags?.join(';') || '',
          customer.createdAt || '',
          customer.updatedAt || '',
        ];

        // Escape CSV values
        const escapedRow = row.map((value) => {
          const stringValue = String(value);
          if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
            return `"${stringValue.replace(/"/g, '""')}"`;
          }
          return stringValue;
        });

        csvRows.push(escapedRow.join(','));
      });

      exportContent = csvRows.join('\n');
      contentType = 'text/csv';
      fileExtension = 'csv';
    } else if (format === 'json') {
      exportContent = JSON.stringify(customers, null, 2);
      contentType = 'application/json';
      fileExtension = 'json';
    } else {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_FORMAT',
            message: 'Supported formats: csv, json',
          },
        }),
      };
    }

    // Upload to S3
    const fileName = `exports/customers/${tenantId}/${uuidv4()}.${fileExtension}`;
    const uploadCommand = new PutObjectCommand({
      Bucket: bucketName,
      Key: fileName,
      Body: exportContent,
      ContentType: contentType,
      Metadata: {
        tenantId,
        exportedAt: new Date().toISOString(),
        recordCount: String(customers.length),
      },
    });

    await s3Client.send(uploadCommand);

    // Generate presigned URL for download (valid for 1 hour)
    const downloadUrl = await getSignedUrl(
      s3Client,
      new PutObjectCommand({
        Bucket: bucketName,
        Key: fileName,
      }),
      { expiresIn: 3600 }
    );

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: {
          downloadUrl,
          fileName,
          recordCount: customers.length,
          format,
          expiresIn: 3600,
        },
      }),
    };
  } catch (error) {
    console.error('Error exporting customers:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to export customers',
        },
      }),
    };
  }
};
