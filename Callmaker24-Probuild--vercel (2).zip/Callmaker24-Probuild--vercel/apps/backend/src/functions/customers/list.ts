/**
 * Lambda function to list customers with pagination and filtering
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { customersTable } from '../../lib/database';

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    // Parse query parameters
    const params = event.queryStringParameters || {};
    const page = parseInt(params.page || '1');
    const limit = parseInt(params.limit || '20');
    const search = params.search;
    const status = params.status;

    // Build filter expression
    let filterExpression = 'tenantId = :tenantId';
    const expressionValues: Record<string, any> = { ':tenantId': tenantId };

    if (status) {
      filterExpression += ' AND #status = :status';
      expressionValues[':status'] = status;
    }

    // Get customers
    let customers = await customersTable.scan(filterExpression, expressionValues);

    // Apply search filter (client-side for now)
    if (search) {
      const searchLower = search.toLowerCase();
      customers = customers.filter(
        (customer: any) =>
          customer.email?.toLowerCase().includes(searchLower) ||
          customer.firstName?.toLowerCase().includes(searchLower) ||
          customer.lastName?.toLowerCase().includes(searchLower) ||
          customer.company?.toLowerCase().includes(searchLower)
      );
    }

    // Sort by created date (newest first)
    customers.sort((a: any, b: any) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    // Paginate
    const total = customers.length;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedCustomers = customers.slice(startIndex, endIndex);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: paginatedCustomers,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      }),
    };
  } catch (error: any) {
    console.error('Error listing customers:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: error.message || 'An error occurred while fetching customers',
        },
      }),
    };
  }
};
