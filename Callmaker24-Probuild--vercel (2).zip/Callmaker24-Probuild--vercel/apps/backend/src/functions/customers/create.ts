/**
 * Lambda function to create a new customer
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { v4 as uuidv4 } from 'uuid';
import { customersTable } from '../../lib/database';

interface CreateCustomerRequest {
  email: string;
  phoneNumber?: string;
  firstName?: string;
  lastName?: string;
  company?: string;
  tags?: string[];
  customFields?: Record<string, any>;
}

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    // Parse request body
    const body: CreateCustomerRequest = JSON.parse(event.body || '{}');

    // Validate required fields
    if (!body.email) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Email is required',
          },
        }),
      };
    }

    // Get tenant ID from headers
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    // Create customer object
    const customer = {
      id: uuidv4(),
      email: body.email,
      phoneNumber: body.phoneNumber,
      firstName: body.firstName,
      lastName: body.lastName,
      company: body.company,
      status: 'ACTIVE',
      tags: body.tags || [],
      customFields: body.customFields || {},
      segments: [],
      emailOptIn: true,
      smsOptIn: !!body.phoneNumber,
      tenantId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Save to DynamoDB
    await customersTable.put(customer);

    // Return response
    return {
      statusCode: 201,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: customer,
      }),
    };
  } catch (error: any) {
    console.error('Error creating customer:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: error.message || 'An error occurred while creating the customer',
        },
      }),
    };
  }
};
