import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamoDb = DynamoDBDocument.from(new DynamoDB({}));
const customersTable = process.env.CUSTOMERS_TABLE_NAME!;

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];
    const customerId = event.pathParameters?.id;

    if (!tenantId || !customerId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Tenant ID and Customer ID are required',
          },
        }),
      };
    }

    // Get existing customer
    const existingCustomer = await dynamoDb.get({
      TableName: customersTable,
      Key: { id: customerId, tenantId },
    });

    if (!existingCustomer.Item) {
      return {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'Customer not found',
          },
        }),
      };
    }

    // Soft delete by updating status
    await dynamoDb.update({
      TableName: customersTable,
      Key: { id: customerId, tenantId },
      UpdateExpression: 'SET #status = :status, #deletedAt = :deletedAt, #updatedAt = :updatedAt',
      ExpressionAttributeNames: {
        '#status': 'status',
        '#deletedAt': 'deletedAt',
        '#updatedAt': 'updatedAt',
      },
      ExpressionAttributeValues: {
        ':status': 'DELETED',
        ':deletedAt': new Date().toISOString(),
        ':updatedAt': new Date().toISOString(),
      },
    });

    // Note: For GDPR compliance, you may want to:
    // 1. Archive customer data to S3
    // 2. Delete or anonymize associated messages
    // 3. Remove from all segments
    // 4. Unsubscribe from all campaigns

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        data: {
          id: customerId,
          message: 'Customer deleted successfully',
        },
      }),
    };
  } catch (error) {
    console.error('Error deleting customer:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'Failed to delete customer',
        },
      }),
    };
  }
};
