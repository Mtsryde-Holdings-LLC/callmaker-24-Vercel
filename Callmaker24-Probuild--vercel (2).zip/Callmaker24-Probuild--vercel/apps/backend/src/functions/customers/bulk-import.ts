/**
 * Lambda function to bulk import customers from CSV
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { customersTable } from '../../lib/database';
import { v4 as uuidv4 } from 'uuid';

const s3Client = new S3Client({ region: process.env.AWS_REGION });

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const tenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    if (!tenantId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'Tenant ID is required',
          },
        }),
      };
    }

    // Get S3 key from request
    const body = JSON.parse(event.body || '{}');
    const { s3Key } = body;

    if (!s3Key) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'S3 key is required',
          },
        }),
      };
    }

    // Download CSV from S3
    const getCommand = new GetObjectCommand({
      Bucket: process.env.S3_BUCKET_NAME,
      Key: s3Key,
    });

    const response = await s3Client.send(getCommand);
    const csvContent = await response.Body?.transformToString();

    if (!csvContent) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_FILE',
            message: 'Could not read CSV file',
          },
        }),
      };
    }

    // Parse CSV
    const lines = csvContent.split('\n');
    const headers = lines[0].split(',').map((h) => h.trim());

    // Required headers
    const emailIndex = headers.indexOf('email');

    if (emailIndex === -1) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_CSV',
            message: 'CSV must contain "email" column',
          },
        }),
      };
    }

    // Import customers
    const results = {
      success: 0,
      failed: 0,
      errors: [] as string[],
    };

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      const values = line.split(',').map((v) => v.trim());

      try {
        const customerData: any = {
          id: uuidv4(),
          email: values[emailIndex],
          status: 'ACTIVE',
          tags: [],
          customFields: {},
          segments: [],
          emailOptIn: true,
          smsOptIn: false,
          tenantId,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        // Map other columns
        headers.forEach((header, index) => {
          if (index === emailIndex) return;

          const value = values[index];
          if (!value) return;

          switch (header.toLowerCase()) {
            case 'firstname':
            case 'first_name':
              customerData.firstName = value;
              break;
            case 'lastname':
            case 'last_name':
              customerData.lastName = value;
              break;
            case 'company':
              customerData.company = value;
              break;
            case 'phone':
            case 'phonenumber':
            case 'phone_number':
              customerData.phoneNumber = value;
              customerData.smsOptIn = true;
              break;
            case 'tags':
              customerData.tags = value.split('|').map((t: string) => t.trim());
              break;
            default:
              // Add to custom fields
              customerData.customFields[header] = value;
          }
        });

        // Validate email
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerData.email)) {
          throw new Error('Invalid email address');
        }

        // Save to database
        await customersTable.put(customerData);
        results.success++;
      } catch (error: any) {
        results.failed++;
        results.errors.push(`Line ${i + 1}: ${error.message}`);
      }
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: results,
      }),
    };
  } catch (error: any) {
    console.error('Error importing customers:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: error.message || 'An error occurred during import',
        },
      }),
    };
  }
};
