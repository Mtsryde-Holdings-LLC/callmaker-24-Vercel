import { EventBridgeHandler } from 'aws-lambda';
import { EventBridgeClient, DeleteRuleCommand, RemoveTargetsCommand } from '@aws-sdk/client-eventbridge';
import { SocialMediaManager } from '../../services/social';

const eventBridge = new EventBridgeClient({ region: process.env.AWS_REGION || 'us-east-1' });

/**
 * Lambda handler triggered by EventBridge to publish scheduled posts
 * This function is called when a scheduled post's time arrives
 */
export const handler: EventBridgeHandler<'Scheduled Event', any, void> = async (event) => {
  try {
    console.log('Publishing scheduled post:', event.detail);

    const {
      platform,
      content,
      mediaUrls,
      hashtags,
      ruleName,
    } = event.detail;

    // TODO: Get social media credentials from database
    // const prisma = new PrismaClient();
    // const socialAccount = await prisma.socialAccount.findUnique({
    //   where: {
    //     businessId_platform: {
    //       businessId,
    //       platform,
    //     },
    //   },
    // });

    // For now, use environment variables (not recommended for production)
    // Security: Fail fast if credentials are missing rather than using empty strings
    // Only include platform credentials if ALL required fields are present
    const credentials: {
      twitter?: {
        apiKey: string;
        apiSecret: string;
        accessToken: string;
        accessSecret: string;
        bearerToken?: string;
      };
      linkedin?: {
        accessToken: string;
        personUrn?: string;
      };
      facebook?: {
        accessToken: string;
        pageId?: string;
      };
      instagram?: {
        accessToken: string;
        accountId?: string;
      };
    } = {};
    
    // Twitter - require all credentials
    if (process.env.TWITTER_API_KEY && 
        process.env.TWITTER_API_SECRET && 
        process.env.TWITTER_ACCESS_TOKEN && 
        process.env.TWITTER_ACCESS_SECRET) {
      credentials.twitter = {
        apiKey: process.env.TWITTER_API_KEY,
        apiSecret: process.env.TWITTER_API_SECRET,
        accessToken: process.env.TWITTER_ACCESS_TOKEN,
        accessSecret: process.env.TWITTER_ACCESS_SECRET,
        bearerToken: process.env.TWITTER_BEARER_TOKEN,
      };
    }
    
    // LinkedIn - require access token
    if (process.env.LINKEDIN_ACCESS_TOKEN) {
      credentials.linkedin = {
        accessToken: process.env.LINKEDIN_ACCESS_TOKEN,
        personUrn: process.env.LINKEDIN_PERSON_URN,
      };
    }
    
    // Facebook - require access token
    if (process.env.FACEBOOK_ACCESS_TOKEN) {
      credentials.facebook = {
        accessToken: process.env.FACEBOOK_ACCESS_TOKEN,
        pageId: process.env.FACEBOOK_PAGE_ID,
      };
    }
    
    // Instagram - require access token
    if (process.env.INSTAGRAM_ACCESS_TOKEN) {
      credentials.instagram = {
        accessToken: process.env.INSTAGRAM_ACCESS_TOKEN,
        accountId: process.env.INSTAGRAM_ACCOUNT_ID,
      };
    }

    const socialManager = new SocialMediaManager(credentials);

    // Prepare full content with hashtags
    const fullContent = hashtags && hashtags.length > 0
      ? `${content}\n\n${hashtags.join(' ')}`
      : content;

    // Post to platform
    const result = await socialManager.postToMultiplePlatforms({
      content: fullContent,
      platforms: [platform.toLowerCase()],
      mediaUrl: mediaUrls && mediaUrls.length > 0 ? mediaUrls[0] : undefined,
    });

    console.log('Post published:', result);

    // TODO: Update database with published status
    // const postSuccess = result.results[0]?.success;
    // const postId = result.results[0]?.postId;
    // if (postSuccess && postId) {
    //   await prisma.content.update({
    //     where: { id: contentId },
    //     data: {
    //       status: 'PUBLISHED',
    //       publishedAt: new Date(),
    //       platformPostId: postId,
    //     },
    //   });
    // } else {
    //   await prisma.content.update({
    //     where: { id: contentId },
    //     data: {
    //       status: 'FAILED',
    //     },
    //   });
    // }

    // Clean up EventBridge rule after execution
    if (ruleName) {
      try {
        // Remove targets first
        await eventBridge.send(
          new RemoveTargetsCommand({
            Rule: ruleName,
            Ids: ['1'],
          })
        );

        // Then delete the rule
        await eventBridge.send(
          new DeleteRuleCommand({
            Name: ruleName,
          })
        );

        console.log('EventBridge rule cleaned up:', ruleName);
      } catch (error) {
        console.error('Error cleaning up EventBridge rule:', error);
      }
    }

    return;
  } catch (error) {
    console.error('Error publishing post:', error);
    throw error;
  }
};

/**
 * Manual post handler (immediate posting without scheduling)
 * POST /api/publish-post
 */
import { APIGatewayProxyHandler } from 'aws-lambda';

export const manualPublishHandler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');

    const {
      businessId,
      platforms,
      content,
      mediaUrl,
      link,
    } = body;

    if (!businessId || !platforms || !content) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Missing required fields: businessId, platforms, content',
        }),
      };
    }

    // TODO: Get credentials from database
    // Security: Fail fast if credentials are missing rather than using empty strings
    // Only include platform credentials if ALL required fields are present
    const credentials: {
      twitter?: {
        apiKey: string;
        apiSecret: string;
        accessToken: string;
        accessSecret: string;
        bearerToken?: string;
      };
      linkedin?: {
        accessToken: string;
        personUrn?: string;
      };
      facebook?: {
        accessToken: string;
        pageId?: string;
      };
      instagram?: {
        accessToken: string;
        accountId?: string;
      };
    } = {};
    
    // Twitter - require all credentials
    if (process.env.TWITTER_API_KEY && 
        process.env.TWITTER_API_SECRET && 
        process.env.TWITTER_ACCESS_TOKEN && 
        process.env.TWITTER_ACCESS_SECRET) {
      credentials.twitter = {
        apiKey: process.env.TWITTER_API_KEY,
        apiSecret: process.env.TWITTER_API_SECRET,
        accessToken: process.env.TWITTER_ACCESS_TOKEN,
        accessSecret: process.env.TWITTER_ACCESS_SECRET,
        bearerToken: process.env.TWITTER_BEARER_TOKEN,
      };
    }
    
    // LinkedIn - require access token
    if (process.env.LINKEDIN_ACCESS_TOKEN) {
      credentials.linkedin = {
        accessToken: process.env.LINKEDIN_ACCESS_TOKEN,
        personUrn: process.env.LINKEDIN_PERSON_URN,
      };
    }
    
    // Facebook - require access token
    if (process.env.FACEBOOK_ACCESS_TOKEN) {
      credentials.facebook = {
        accessToken: process.env.FACEBOOK_ACCESS_TOKEN,
        pageId: process.env.FACEBOOK_PAGE_ID,
      };
    }
    
    // Instagram - require access token
    if (process.env.INSTAGRAM_ACCESS_TOKEN) {
      credentials.instagram = {
        accessToken: process.env.INSTAGRAM_ACCESS_TOKEN,
        accountId: process.env.INSTAGRAM_ACCOUNT_ID,
      };
    }

    const socialManager = new SocialMediaManager(credentials);

    const result = await socialManager.postToMultiplePlatforms({
      content,
      platforms,
      mediaUrl,
      link,
    });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result,
      }),
    };
  } catch (error: any) {
    console.error('Error publishing post:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        // Security: Don't expose internal error details to prevent information leakage
        error: 'Failed to publish post',
      }),
    };
  }
};
