import { APIGatewayProxyHandler } from 'aws-lambda';
import {
  generateContent,
  generateContentVariations,
  generateHashtags,
  generateImagePrompt,
} from '../../services/ai/contentGenerator';

/**
 * Lambda handler for AI content generation
 * POST /api/generate-content
 */
export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');

    const {
      topic,
      businessType,
      targetAudience,
      platform,
      tone,
      contentType,
      maxLength,
      includeHashtags,
      includeEmojis,
      includeCallToAction,
      brandVoice,
      keywords,
      generateVariations,
      variationCount,
    } = body;

    // Validate required fields
    if (!topic || !businessType || !targetAudience || !platform) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Missing required fields: topic, businessType, targetAudience, platform',
        }),
      };
    }

    const params = {
      topic,
      businessType,
      targetAudience,
      platform,
      tone,
      contentType,
      maxLength,
      includeHashtags,
      includeEmojis,
      includeCallToAction,
      brandVoice,
      keywords,
    };

    let result;

    if (generateVariations) {
      // Generate multiple variations for A/B testing
      const variations = await generateContentVariations(params, variationCount || 3);
      result = {
        variations,
      };
    } else {
      // Generate single content
      result = await generateContent(params);
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result,
      }),
    };
  } catch (error: any) {
    console.error('Error generating content:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: error.message || 'Failed to generate content',
      }),
    };
  }
};

/**
 * Lambda handler for hashtag generation
 * POST /api/generate-hashtags
 */
export const generateHashtagsHandler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const { content, platform, count } = body;

    if (!content || !platform) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Missing required fields: content, platform',
        }),
      };
    }

    const hashtags = await generateHashtags(content, platform, count);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: { hashtags },
      }),
    };
  } catch (error: any) {
    console.error('Error generating hashtags:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: error.message || 'Failed to generate hashtags',
      }),
    };
  }
};

/**
 * Lambda handler for image prompt generation
 * POST /api/generate-image-prompt
 */
export const generateImagePromptHandler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const { content } = body;

    if (!content) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Missing required field: content',
        }),
      };
    }

    const imagePrompt = await generateImagePrompt(content);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: { imagePrompt },
      }),
    };
  } catch (error: any) {
    console.error('Error generating image prompt:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: error.message || 'Failed to generate image prompt',
      }),
    };
  }
};
