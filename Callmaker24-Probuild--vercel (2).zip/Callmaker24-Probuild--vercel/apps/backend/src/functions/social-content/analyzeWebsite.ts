import { APIGatewayProxyHandler } from 'aws-lambda';
import {
  scrapeWebsite,
  analyzeWebsiteForBrand,
  parseRSSFeed,
  analyzeContentPerformance,
} from '../../services/ai/contentAnalyzer';

/**
 * Lambda handler for website analysis
 * POST /api/analyze-website
 */
export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const { url, analyzeBrand } = body;

    if (!url) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Missing required field: url',
        }),
      };
    }

    let result;

    if (analyzeBrand) {
      // Full brand analysis including AI processing
      result = await analyzeWebsiteForBrand(url);
    } else {
      // Basic website scraping
      result = await scrapeWebsite(url);
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result,
      }),
    };
  } catch (error: any) {
    console.error('Error analyzing website:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: error.message || 'Failed to analyze website',
      }),
    };
  }
};

/**
 * Lambda handler for RSS feed parsing
 * POST /api/parse-rss
 */
export const parseRSSHandler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const { feedUrl } = body;

    if (!feedUrl) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Missing required field: feedUrl',
        }),
      };
    }

    const items = await parseRSSFeed(feedUrl);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: { items },
      }),
    };
  } catch (error: any) {
    console.error('Error parsing RSS feed:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: error.message || 'Failed to parse RSS feed',
      }),
    };
  }
};

/**
 * Lambda handler for content performance analysis
 * POST /api/analyze-performance
 */
export const analyzePerformanceHandler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const { posts } = body;

    if (!posts || !Array.isArray(posts)) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Missing or invalid field: posts (must be an array)',
        }),
      };
    }

    const analysis = analyzeContentPerformance(posts);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: analysis,
      }),
    };
  } catch (error: any) {
    console.error('Error analyzing performance:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: error.message || 'Failed to analyze performance',
      }),
    };
  }
};
