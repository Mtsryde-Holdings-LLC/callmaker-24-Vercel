import { APIGatewayProxyHandler } from 'aws-lambda';
import { EventBridgeClient, PutRuleCommand, PutTargetsCommand } from '@aws-sdk/client-eventbridge';

const eventBridge = new EventBridgeClient({ region: process.env.AWS_REGION || 'us-east-1' });

/**
 * Lambda handler for scheduling posts
 * POST /api/schedule-post
 *
 * Creates EventBridge rule to trigger post at scheduled time
 */
export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');

    const {
      businessId,
      platform,
      content,
      scheduledAt,
      mediaUrls,
      hashtags,
    } = body;

    // Validate required fields
    if (!businessId || !platform || !content || !scheduledAt) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Missing required fields: businessId, platform, content, scheduledAt',
        }),
      };
    }

    const scheduledTime = new Date(scheduledAt);
    const now = new Date();

    if (scheduledTime <= now) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Scheduled time must be in the future',
        }),
      };
    }

    // Create a unique rule name
    const ruleName = `social-post-${businessId}-${Date.now()}`;

    // Create cron expression from scheduledAt
    const cronExpression = createCronExpression(scheduledTime);

    // Create EventBridge rule
    await eventBridge.send(
      new PutRuleCommand({
        Name: ruleName,
        ScheduleExpression: cronExpression,
        State: 'ENABLED',
        Description: `Scheduled social media post for ${platform}`,
      })
    );

    // Add target (the Lambda function that will publish the post)
    await eventBridge.send(
      new PutTargetsCommand({
        Rule: ruleName,
        Targets: [
          {
            Id: '1',
            Arn: process.env.PUBLISH_POST_LAMBDA_ARN || '',
            Input: JSON.stringify({
              businessId,
              platform,
              content,
              mediaUrls,
              hashtags,
              scheduledAt,
              ruleName, // So we can delete the rule after execution
            }),
          },
        ],
      })
    );

    // TODO: Save to database
    // const prisma = new PrismaClient();
    // await prisma.content.create({
    //   data: {
    //     businessId,
    //     platform,
    //     content,
    //     status: 'SCHEDULED',
    //     scheduledAt,
    //     mediaUrls,
    //     hashtags,
    //   },
    // });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: {
          message: 'Post scheduled successfully',
          scheduledAt,
          ruleName,
        },
      }),
    };
  } catch (error: any) {
    console.error('Error scheduling post:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: error.message || 'Failed to schedule post',
      }),
    };
  }
};

/**
 * Lambda handler for getting scheduled posts
 * GET /api/scheduled-posts
 */
export const getScheduledPostsHandler: APIGatewayProxyHandler = async (event) => {
  try {
    const businessId = event.queryStringParameters?.businessId;

    if (!businessId) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Missing required parameter: businessId',
        }),
      };
    }

    // TODO: Get from database
    // const prisma = new PrismaClient();
    // const scheduledPosts = await prisma.content.findMany({
    //   where: {
    //     businessId,
    //     status: 'SCHEDULED',
    //   },
    //   orderBy: {
    //     scheduledAt: 'asc',
    //   },
    // });

    const scheduledPosts: any[] = []; // Placeholder

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: scheduledPosts,
      }),
    };
  } catch (error: any) {
    console.error('Error getting scheduled posts:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: error.message || 'Failed to get scheduled posts',
      }),
    };
  }
};

/**
 * Lambda handler for deleting/canceling scheduled posts
 * DELETE /api/schedule-post/{id}
 */
export const deleteScheduledPostHandler: APIGatewayProxyHandler = async (event) => {
  try {
    const postId = event.pathParameters?.id;

    if (!postId) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          success: false,
          error: 'Missing post ID',
        }),
      };
    }

    // TODO: Delete from database and remove EventBridge rule
    // const prisma = new PrismaClient();
    // const post = await prisma.content.findUnique({ where: { id: postId } });
    // if (post && post.ruleName) {
    //   await eventBridge.send(new DeleteRuleCommand({ Name: post.ruleName }));
    // }
    // await prisma.content.delete({ where: { id: postId } });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        message: 'Scheduled post deleted',
      }),
    };
  } catch (error: any) {
    console.error('Error deleting scheduled post:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: error.message || 'Failed to delete scheduled post',
      }),
    };
  }
};

/**
 * Helper function to create cron expression from Date
 */
function createCronExpression(date: Date): string {
  const minute = date.getUTCMinutes();
  const hour = date.getUTCHours();
  const dayOfMonth = date.getUTCDate();
  const month = date.getUTCMonth() + 1;
  const year = date.getUTCFullYear();

  // EventBridge cron format: cron(minutes hours day-of-month month day-of-week year)
  return `cron(${minute} ${hour} ${dayOfMonth} ${month} ? ${year})`;
}
