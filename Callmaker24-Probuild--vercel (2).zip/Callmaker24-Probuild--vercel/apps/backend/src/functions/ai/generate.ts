/**
 * Lambda function for AI content generation
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { generateContent } from '../../lib/openai';

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');

    if (!body.prompt) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Prompt is required',
          },
        }),
      };
    }

    if (!body.type || !['email', 'sms', 'subject', 'general'].includes(body.type)) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Valid type is required (email, sms, subject, or general)',
          },
        }),
      };
    }

    const result = await generateContent({
      prompt: body.prompt,
      type: body.type,
      context: body.context,
      maxTokens: body.maxTokens,
    });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: true,
        data: result,
      }),
    };
  } catch (error: any) {
    console.error('Error generating content:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          // Security: Generic error message to prevent information leakage
          // Detailed errors are logged for debugging purposes
          message: 'An error occurred while generating content',
        },
      }),
    };
  }
};
