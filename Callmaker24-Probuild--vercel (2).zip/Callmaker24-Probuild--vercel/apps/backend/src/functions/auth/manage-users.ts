/**
 * Lambda functions for user management (Admin/Super Admin only)
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, QueryCommand, UpdateCommand, DeleteCommand } from '@aws-sdk/lib-dynamodb';
import { requireMinimumRole, requireSuperAdmin, AuthenticatedEvent } from '../../middleware/auth-middleware';
import { getUserPermissions } from '../../lib/auth';
import {
  UpdateUserRequest,
  AssignRoleRequest,
  UserRole,
  SubscriptionTier,
} from '../../types/auth';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);
const USERS_TABLE = process.env.USERS_TABLE || 'users';

/**
 * List all users (Admin/Super Admin only)
 */
export const listUsers: APIGatewayProxyHandler = requireMinimumRole(UserRole.ADMIN)(
  async (event: AuthenticatedEvent) => {
    try {
      const requestingUser = event.user;
      const tenantId = event.queryStringParameters?.tenantId || requestingUser.tenantId;

      // Super admin can list users from all tenants
      // Admin can only list users from their tenant
      if (requestingUser.role !== UserRole.SUPER_ADMIN && tenantId !== requestingUser.tenantId) {
        return {
          statusCode: 403,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'FORBIDDEN',
              message: 'You can only list users from your own tenant',
            },
          }),
        };
      }

      const queryParams: any = {
        TableName: USERS_TABLE,
      };

      if (tenantId) {
        queryParams.IndexName = 'tenantId-index';
        queryParams.KeyConditionExpression = 'tenantId = :tenantId';
        queryParams.ExpressionAttributeValues = {
          ':tenantId': tenantId,
        };
      }

      const result = await docClient.send(new QueryCommand(queryParams));

      const users = (result.Items || []).map((user) => ({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        subscriptionTier: user.subscriptionTier,
        tenantId: user.tenantId,
        isActive: user.isActive,
        lastLoginAt: user.lastLoginAt,
        createdAt: user.createdAt,
      }));

      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          users,
        }),
      };
    } catch (error: any) {
      console.error('List users error:', error);

      return {
        statusCode: 500,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INTERNAL_ERROR',
            message: 'Failed to list users',
          },
        }),
      };
    }
  }
);

/**
 * Get user details (Admin/Super Admin only)
 */
export const getUser: APIGatewayProxyHandler = requireMinimumRole(UserRole.ADMIN)(
  async (event: AuthenticatedEvent) => {
    try {
      const requestingUser = event.user;
      const userId = event.pathParameters?.id;

      if (!userId) {
        return {
          statusCode: 400,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'INVALID_REQUEST',
              message: 'User ID is required',
            },
          }),
        };
      }

      const result = await docClient.send(
        new GetCommand({
          TableName: USERS_TABLE,
          Key: { id: userId },
        })
      );

      if (!result.Item) {
        return {
          statusCode: 404,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'USER_NOT_FOUND',
              message: 'User not found',
            },
          }),
        };
      }

      const user = result.Item;

      // Admin can only view users from their tenant
      if (requestingUser.role !== UserRole.SUPER_ADMIN && user.tenantId !== requestingUser.tenantId) {
        return {
          statusCode: 403,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'FORBIDDEN',
              message: 'You can only view users from your own tenant',
            },
          }),
        };
      }

      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          user: {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            subscriptionTier: user.subscriptionTier,
            permissions: user.permissions,
            tenantId: user.tenantId,
            isActive: user.isActive,
            lastLoginAt: user.lastLoginAt,
            createdAt: user.createdAt,
            updatedAt: user.updatedAt,
          },
        }),
      };
    } catch (error: any) {
      console.error('Get user error:', error);

      return {
        statusCode: 500,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INTERNAL_ERROR',
            message: 'Failed to get user',
          },
        }),
      };
    }
  }
);

/**
 * Assign role to user (Super Admin only)
 */
export const assignRole: APIGatewayProxyHandler = requireSuperAdmin()(
  async (event: AuthenticatedEvent) => {
    try {
      const body: AssignRoleRequest = JSON.parse(event.body || '{}');
      const { userId, role, permissions: customPermissions, functions } = body;

      if (!userId || !role) {
        return {
          statusCode: 400,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'INVALID_REQUEST',
              message: 'User ID and role are required',
            },
          }),
        };
      }

      // Get user
      const userResult = await docClient.send(
        new GetCommand({
          TableName: USERS_TABLE,
          Key: { id: userId },
        })
      );

      if (!userResult.Item) {
        return {
          statusCode: 404,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'USER_NOT_FOUND',
              message: 'User not found',
            },
          }),
        };
      }

      const user = userResult.Item;

      // Calculate new permissions
      const newPermissions = customPermissions || getUserPermissions(
        role,
        user.subscriptionTier as SubscriptionTier,
        user.permissions
      );

      // Update user
      await docClient.send(
        new UpdateCommand({
          TableName: USERS_TABLE,
          Key: { id: userId },
          UpdateExpression: 'SET #role = :role, permissions = :permissions, updatedAt = :now',
          ExpressionAttributeNames: {
            '#role': 'role',
          },
          ExpressionAttributeValues: {
            ':role': role,
            ':permissions': newPermissions.map((p) => p.toString()),
            ':now': new Date().toISOString(),
          },
        })
      );

      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          message: 'Role assigned successfully',
          user: {
            id: userId,
            role,
            permissions: newPermissions,
            functions: functions || [],
          },
        }),
      };
    } catch (error: any) {
      console.error('Assign role error:', error);

      return {
        statusCode: 500,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INTERNAL_ERROR',
            message: 'Failed to assign role',
          },
        }),
      };
    }
  }
);

/**
 * Update user (Admin can update users in their tenant, Super Admin can update any user)
 */
export const updateUser: APIGatewayProxyHandler = requireMinimumRole(UserRole.ADMIN)(
  async (event: AuthenticatedEvent) => {
    try {
      const requestingUser = event.user;
      const userId = event.pathParameters?.id;
      const body: UpdateUserRequest = JSON.parse(event.body || '{}');

      if (!userId) {
        return {
          statusCode: 400,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'INVALID_REQUEST',
              message: 'User ID is required',
            },
          }),
        };
      }

      // Get user
      const userResult = await docClient.send(
        new GetCommand({
          TableName: USERS_TABLE,
          Key: { id: userId },
        })
      );

      if (!userResult.Item) {
        return {
          statusCode: 404,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'USER_NOT_FOUND',
              message: 'User not found',
            },
          }),
        };
      }

      const user = userResult.Item;

      // Admin can only update users from their tenant
      if (requestingUser.role !== UserRole.SUPER_ADMIN && user.tenantId !== requestingUser.tenantId) {
        return {
          statusCode: 403,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'FORBIDDEN',
              message: 'You can only update users from your own tenant',
            },
          }),
        };
      }

      // Only super admin can change roles
      if (body.role && requestingUser.role !== UserRole.SUPER_ADMIN) {
        return {
          statusCode: 403,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'FORBIDDEN',
              message: 'Only super admins can change user roles',
            },
          }),
        };
      }

      // Build update expression
      const updateExpressions: string[] = ['updatedAt = :now'];
      const expressionValues: any = {
        ':now': new Date().toISOString(),
      };
      const expressionNames: any = {};

      if (body.role !== undefined) {
        updateExpressions.push('#role = :role');
        expressionNames['#role'] = 'role';
        expressionValues[':role'] = body.role;
      }

      if (body.subscriptionTier !== undefined) {
        updateExpressions.push('subscriptionTier = :tier');
        expressionValues[':tier'] = body.subscriptionTier;

        // Recalculate permissions based on new tier
        const newPermissions = getUserPermissions(
          body.role || user.role,
          body.subscriptionTier,
          body.permissions
        );
        updateExpressions.push('permissions = :permissions');
        expressionValues[':permissions'] = newPermissions.map((p) => p.toString());
      }

      if (body.permissions !== undefined) {
        updateExpressions.push('permissions = :permissions');
        expressionValues[':permissions'] = body.permissions.map((p) => p.toString());
      }

      if (body.isActive !== undefined) {
        updateExpressions.push('isActive = :active');
        expressionValues[':active'] = body.isActive;
      }

      // Update user
      await docClient.send(
        new UpdateCommand({
          TableName: USERS_TABLE,
          Key: { id: userId },
          UpdateExpression: 'SET ' + updateExpressions.join(', '),
          ExpressionAttributeNames: Object.keys(expressionNames).length > 0 ? expressionNames : undefined,
          ExpressionAttributeValues: expressionValues,
        })
      );

      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          message: 'User updated successfully',
        }),
      };
    } catch (error: any) {
      console.error('Update user error:', error);

      return {
        statusCode: 500,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INTERNAL_ERROR',
            message: 'Failed to update user',
          },
        }),
      };
    }
  }
);

/**
 * Delete user (Super Admin only)
 */
export const deleteUser: APIGatewayProxyHandler = requireSuperAdmin()(
  async (event: AuthenticatedEvent) => {
    try {
      const userId = event.pathParameters?.id;

      if (!userId) {
        return {
          statusCode: 400,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'INVALID_REQUEST',
              message: 'User ID is required',
            },
          }),
        };
      }

      // Check if user exists
      const userResult = await docClient.send(
        new GetCommand({
          TableName: USERS_TABLE,
          Key: { id: userId },
        })
      );

      if (!userResult.Item) {
        return {
          statusCode: 404,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'USER_NOT_FOUND',
              message: 'User not found',
            },
          }),
        };
      }

      // Delete user
      await docClient.send(
        new DeleteCommand({
          TableName: USERS_TABLE,
          Key: { id: userId },
        })
      );

      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          message: 'User deleted successfully',
        }),
      };
    } catch (error: any) {
      console.error('Delete user error:', error);

      return {
        statusCode: 500,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INTERNAL_ERROR',
            message: 'Failed to delete user',
          },
        }),
      };
    }
  }
);
