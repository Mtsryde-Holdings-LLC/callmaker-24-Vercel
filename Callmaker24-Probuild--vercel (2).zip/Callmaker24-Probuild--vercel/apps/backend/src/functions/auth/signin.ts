/**
 * Lambda function for user signin
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, QueryCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import {
  comparePassword,
  generateToken,
  generateRefreshToken,
  getUserPermissions,
} from '../../lib/auth';
import {
  SigninRequest,
  AuthResponse,
  UserRole,
  SubscriptionTier,
} from '../../types/auth';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);
const USERS_TABLE = process.env.USERS_TABLE || 'users';

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const body: SigninRequest = JSON.parse(event.body || '{}');
    const { email, password } = body;

    // Validate required fields
    if (!email || !password) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Email and password are required',
          },
        } as AuthResponse),
      };
    }

    // Find user by email
    const userQuery = await docClient.send(
      new QueryCommand({
        TableName: USERS_TABLE,
        IndexName: 'email-index',
        KeyConditionExpression: 'email = :email',
        ExpressionAttributeValues: {
          ':email': email,
        },
        Limit: 1,
      })
    );

    if (!userQuery.Items || userQuery.Items.length === 0) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_CREDENTIALS',
            message: 'Invalid email or password',
          },
        } as AuthResponse),
      };
    }

    const user = userQuery.Items[0];

    // Check if user is active
    if (!user.isActive) {
      return {
        statusCode: 403,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'ACCOUNT_DISABLED',
            message: 'Your account has been disabled. Please contact support.',
          },
        } as AuthResponse),
      };
    }

    // Verify password
    if (!user.password) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_CREDENTIALS',
            message: 'Invalid email or password',
          },
        } as AuthResponse),
      };
    }

    const isPasswordValid = await comparePassword(password, user.password);

    if (!isPasswordValid) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_CREDENTIALS',
            message: 'Invalid email or password',
          },
        } as AuthResponse),
      };
    }

    // Get user permissions
    const role = user.role as UserRole;
    const subscriptionTier = user.subscriptionTier as SubscriptionTier;
    const customPermissions = user.permissions || [];

    const permissions = getUserPermissions(role, subscriptionTier, customPermissions);

    // Update last login time
    await docClient.send(
      new UpdateCommand({
        TableName: USERS_TABLE,
        Key: {
          id: user.id,
        },
        UpdateExpression: 'SET lastLoginAt = :now, updatedAt = :now',
        ExpressionAttributeValues: {
          ':now': new Date().toISOString(),
        },
      })
    );

    // Generate tokens
    const token = generateToken({
      userId: user.id,
      email: user.email,
      role,
      tenantId: user.tenantId,
      subscriptionTier,
      permissions,
    });

    const refreshToken = generateRefreshToken({
      userId: user.id,
      email: user.email,
      role,
      tenantId: user.tenantId,
      subscriptionTier,
    });

    // Return success response
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        token,
        refreshToken,
        user: {
          id: user.id,
          email: user.email,
          name: user.name || undefined,
          role,
          subscriptionTier,
          permissions,
          tenantId: user.tenantId,
        },
      } as AuthResponse),
    };
  } catch (error: any) {
    console.error('Signin error:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An error occurred during signin',
        },
      } as AuthResponse),
    };
  }
};
