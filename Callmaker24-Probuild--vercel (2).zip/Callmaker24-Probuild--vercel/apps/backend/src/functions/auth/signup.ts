/**
 * Lambda function for user signup
 */

import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand, QueryCommand } from '@aws-sdk/lib-dynamodb';
import { v4 as uuidv4 } from 'uuid';
import {
  hashPassword,
  generateToken,
  generateRefreshToken,
  getUserPermissions,
  isValidEmail,
  isValidPassword,
  generateTenantId,
} from '../../lib/auth';
import {
  SignupRequest,
  AuthResponse,
  UserRole,
  SubscriptionTier,
} from '../../types/auth';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);
const USERS_TABLE = process.env.USERS_TABLE || 'users';

export const handler: APIGatewayProxyHandler = async (event) => {
  try {
    const body: SignupRequest = JSON.parse(event.body || '{}');
    const { email, password, name, role, subscriptionTier, tenantId } = body;

    // Validate required fields
    if (!email || !password) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Email and password are required',
          },
        } as AuthResponse),
      };
    }

    // Validate email format
    if (!isValidEmail(email)) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'INVALID_EMAIL',
            message: 'Invalid email format',
          },
        } as AuthResponse),
      };
    }

    // Validate password strength
    const passwordValidation = isValidPassword(password);
    if (!passwordValidation.valid) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'WEAK_PASSWORD',
            message: passwordValidation.errors.join('. '),
          },
        } as AuthResponse),
      };
    }

    // Check if user already exists
    const existingUserQuery = await docClient.send(
      new QueryCommand({
        TableName: USERS_TABLE,
        IndexName: 'email-index',
        KeyConditionExpression: 'email = :email',
        ExpressionAttributeValues: {
          ':email': email,
        },
        Limit: 1,
      })
    );

    if (existingUserQuery.Items && existingUserQuery.Items.length > 0) {
      return {
        statusCode: 409,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'USER_EXISTS',
            message: 'User with this email already exists',
          },
        } as AuthResponse),
      };
    }

    // Determine user role and subscription tier
    // Only super admin can create other super admins or admins
    let userRole = UserRole.USER;
    let userSubscriptionTier = SubscriptionTier.FREE;

    if (role && (role === UserRole.SUPER_ADMIN || role === UserRole.ADMIN)) {
      // Check if requester is super admin (requires auth header)
      const authHeader = event.headers?.Authorization || event.headers?.authorization;
      if (!authHeader) {
        // If no auth, can only create regular USER
        userRole = UserRole.USER;
      } else {
        // In production, verify token and check if super admin
        // For now, allow role assignment if header is present
        userRole = role;
      }
    } else if (role) {
      userRole = role;
    }

    if (subscriptionTier) {
      userSubscriptionTier = subscriptionTier;
    }

    // Generate tenant ID if not provided
    const userTenantId = tenantId || generateTenantId();

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Get user permissions
    const permissions = getUserPermissions(userRole, userSubscriptionTier);

    // Create user
    const userId = uuidv4();
    const now = new Date().toISOString();

    const user = {
      id: userId,
      email,
      password: hashedPassword,
      name: name || null,
      image: null,
      emailVerified: null,
      role: userRole,
      subscriptionTier: userSubscriptionTier,
      permissions: permissions.map((p) => p.toString()),
      tenantId: userTenantId,
      isActive: true,
      lastLoginAt: null,
      createdAt: now,
      updatedAt: now,
    };

    await docClient.send(
      new PutCommand({
        TableName: USERS_TABLE,
        Item: user,
      })
    );

    // Generate tokens
    const token = generateToken({
      userId,
      email,
      role: userRole,
      tenantId: userTenantId,
      subscriptionTier: userSubscriptionTier,
      permissions,
    });

    const refreshToken = generateRefreshToken({
      userId,
      email,
      role: userRole,
      tenantId: userTenantId,
      subscriptionTier: userSubscriptionTier,
    });

    // Return success response
    return {
      statusCode: 201,
      body: JSON.stringify({
        success: true,
        token,
        refreshToken,
        user: {
          id: userId,
          email,
          name: name || undefined,
          role: userRole,
          subscriptionTier: userSubscriptionTier,
          permissions,
          tenantId: userTenantId,
        },
      } as AuthResponse),
    };
  } catch (error: any) {
    console.error('Signup error:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An error occurred during signup',
        },
      } as AuthResponse),
    };
  }
};
