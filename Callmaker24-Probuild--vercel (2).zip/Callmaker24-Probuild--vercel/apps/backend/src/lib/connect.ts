/**
 * Amazon Connect service for IVR/Voice calls
 */

import {
  ConnectClient,
  StartOutboundVoiceContactCommand,
  GetContactAttributesCommand,
  UpdateContactAttributesCommand,
  StartContactRecordingCommand,
  StopContactRecordingCommand,
} from '@aws-sdk/client-connect';

const client = new ConnectClient({ region: process.env.AWS_REGION || 'us-east-1' });

export interface OutboundCallParams {
  destinationPhoneNumber: string;
  sourcePhoneNumber?: string;
  contactFlowId: string;
  instanceId: string;
  attributes?: Record<string, string>;
}

export interface CallRecordingParams {
  instanceId: string;
  contactId: string;
  initialContactId: string;
  voiceRecordingTrack?: 'FROM_AGENT' | 'TO_AGENT' | 'ALL';
}

/**
 * Initiate an outbound voice call
 */
export async function initiateOutboundCall(
  params: OutboundCallParams
): Promise<{ contactId: string }> {
  const command = new StartOutboundVoiceContactCommand({
    DestinationPhoneNumber: params.destinationPhoneNumber,
    ContactFlowId: params.contactFlowId,
    InstanceId: params.instanceId,
    SourcePhoneNumber: params.sourcePhoneNumber || process.env.CONNECT_PHONE_NUMBER,
    Attributes: params.attributes || {},
  });

  const response = await client.send(command);

  if (!response.ContactId) {
    throw new Error('Failed to initiate outbound call: No contact ID returned');
  }

  return {
    contactId: response.ContactId,
  };
}

/**
 * Get contact attributes
 */
export async function getContactAttributes(
  instanceId: string,
  initialContactId: string
): Promise<Record<string, string>> {
  const command = new GetContactAttributesCommand({
    InstanceId: instanceId,
    InitialContactId: initialContactId,
  });

  const response = await client.send(command);
  return response.Attributes || {};
}

/**
 * Update contact attributes
 */
export async function updateContactAttributes(
  instanceId: string,
  initialContactId: string,
  attributes: Record<string, string>
): Promise<void> {
  const command = new UpdateContactAttributesCommand({
    InstanceId: instanceId,
    InitialContactId: initialContactId,
    Attributes: attributes,
  });

  await client.send(command);
}

/**
 * Start call recording
 */
export async function startCallRecording(params: CallRecordingParams): Promise<void> {
  const command = new StartContactRecordingCommand({
    InstanceId: params.instanceId,
    ContactId: params.contactId,
    InitialContactId: params.initialContactId,
    VoiceRecordingConfiguration: {
      VoiceRecordingTrack: params.voiceRecordingTrack || 'ALL',
    },
  });

  await client.send(command);
}

/**
 * Stop call recording
 */
export async function stopCallRecording(params: CallRecordingParams): Promise<void> {
  const command = new StopContactRecordingCommand({
    InstanceId: params.instanceId,
    ContactId: params.contactId,
    InitialContactId: params.initialContactId,
  });

  await client.send(command);
}

/**
 * Format phone number for Connect (E.164 format)
 */
export function formatPhoneNumber(phoneNumber: string): string {
  // Remove all non-digit characters
  let cleaned = phoneNumber.replace(/\D/g, '');

  // Add country code if not present (assuming US +1)
  if (!cleaned.startsWith('1') && cleaned.length === 10) {
    cleaned = '1' + cleaned;
  }

  // Add + prefix for E.164 format
  if (!cleaned.startsWith('+')) {
    cleaned = '+' + cleaned;
  }

  return cleaned;
}

/**
 * Create contact flow attributes
 */
export function createContactAttributes(data: Record<string, any>): Record<string, string> {
  // Convert all values to strings as required by Connect
  const attributes: Record<string, string> = {};

  for (const [key, value] of Object.entries(data)) {
    if (value !== null && value !== undefined) {
      attributes[key] = String(value);
    }
  }

  return attributes;
}
