/**
 * Amazon SES service for sending emails
 */

import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';

const client = new SESClient({ region: process.env.AWS_REGION || 'us-east-1' });

export interface EmailParams {
  to: string[];
  from: string;
  fromName?: string;
  subject: string;
  htmlBody: string;
  textBody?: string;
  replyTo?: string;
  configurationSet?: string;
}

export async function sendEmail(params: EmailParams): Promise<{ messageId: string }> {
  const command = new SendEmailCommand({
    Source: params.fromName ? `${params.fromName} <${params.from}>` : params.from,
    Destination: {
      ToAddresses: params.to,
    },
    Message: {
      Subject: {
        Data: params.subject,
        Charset: 'UTF-8',
      },
      Body: {
        Html: {
          Data: params.htmlBody,
          Charset: 'UTF-8',
        },
        Text: params.textBody
          ? {
              Data: params.textBody,
              Charset: 'UTF-8',
            }
          : undefined,
      },
    },
    ReplyToAddresses: params.replyTo ? [params.replyTo] : undefined,
    ConfigurationSetName: params.configurationSet || process.env.SES_CONFIGURATION_SET,
  });

  const response = await client.send(command);

  return {
    messageId: response.MessageId!,
  };
}

/**
 * Bulk email functionality
 * Note: AWS SDK v3 requires SendBulkTemplatedEmailCommand which needs email templates
 * configured in SES. This function is commented out for future implementation.
 * To use bulk email, you need to:
 * 1. Create email templates in AWS SES console
 * 2. Use SendBulkTemplatedEmailCommand instead
 * 3. Update the response handling for the new command
 */

/*
export interface BulkEmailRecipient {
  email: string;
  replacements: Record<string, string>;
}

export async function sendBulkEmail(
  params: Omit<EmailParams, 'to'> & { recipients: BulkEmailRecipient[] }
): Promise<{ results: { messageId?: string; error?: string; email: string }[] }> {
  // Implementation requires SendBulkTemplatedEmailCommand from '@aws-sdk/client-ses'
  // and pre-configured email templates in AWS SES
  throw new Error('Bulk email not implemented - requires SES templates configuration');
}
*/

export async function sendTransactionalEmail(
  to: string,
  subject: string,
  htmlBody: string
): Promise<{ messageId: string }> {
  return sendEmail({
    to: [to],
    from: process.env.SES_FROM_EMAIL!,
    fromName: process.env.SES_FROM_NAME,
    subject,
    htmlBody,
  });
}
