/**
 * OpenAI service for AI content generation
 */

import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface GenerateContentParams {
  prompt: string;
  type: 'email' | 'sms' | 'subject' | 'general';
  context?: Record<string, any>;
  maxTokens?: number;
}

export interface GenerateContentResponse {
  content: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  cost: number;
}

const SYSTEM_PROMPTS = {
  email: 'You are an expert marketing email copywriter. Create engaging, professional email content that drives conversions while maintaining a friendly tone.',
  sms: 'You are an expert SMS marketing copywriter. Create concise, compelling SMS messages under 160 characters that drive action.',
  subject: 'You are an expert at writing email subject lines. Create attention-grabbing subject lines that increase open rates.',
  general: 'You are a helpful marketing assistant. Provide clear, actionable marketing content.',
};

export async function generateContent(
  params: GenerateContentParams
): Promise<GenerateContentResponse> {
  const systemPrompt = SYSTEM_PROMPTS[params.type];

  const response = await openai.chat.completions.create({
    model: process.env.OPENAI_MODEL || 'gpt-4-turbo-preview',
    messages: [
      {
        role: 'system',
        content: systemPrompt,
      },
      {
        role: 'user',
        content: params.context
          ? `${params.prompt}\n\nContext: ${JSON.stringify(params.context)}`
          : params.prompt,
      },
    ],
    max_tokens: params.maxTokens || 500,
    temperature: 0.7,
  });

  const content = response.choices[0].message.content || '';
  const usage = response.usage!;

  // Calculate cost (approximate, based on GPT-4 pricing)
  const promptCost = (usage.prompt_tokens / 1000) * 0.03;
  const completionCost = (usage.completion_tokens / 1000) * 0.06;
  const totalCost = promptCost + completionCost;

  return {
    content,
    usage: {
      promptTokens: usage.prompt_tokens,
      completionTokens: usage.completion_tokens,
      totalTokens: usage.total_tokens,
    },
    cost: totalCost,
  };
}

export async function chatWithBot(
  conversationHistory: { role: 'user' | 'assistant'; content: string }[],
  newMessage: string
): Promise<{ reply: string; usage: any }> {
  const response = await openai.chat.completions.create({
    model: process.env.OPENAI_MODEL || 'gpt-4-turbo-preview',
    messages: [
      {
        role: 'system',
        content:
          'You are a helpful customer support assistant. Be friendly, professional, and provide accurate information. If you cannot help, politely suggest escalating to a human agent.',
      },
      ...conversationHistory.map((msg) => ({
        role: msg.role,
        content: msg.content,
      })),
      {
        role: 'user',
        content: newMessage,
      },
    ],
    max_tokens: 300,
    temperature: 0.7,
  });

  return {
    reply: response.choices[0].message.content || '',
    usage: response.usage,
  };
}

// Alias for chatbot function
export async function chatCompletion(params: {
  messages: { role: 'system' | 'user' | 'assistant'; content: string }[];
  maxTokens?: number;
  temperature?: number;
}): Promise<{ content: string; usage?: any; model?: string; cost?: number }> {
  const response = await openai.chat.completions.create({
    model: process.env.OPENAI_MODEL || 'gpt-4-turbo-preview',
    messages: params.messages as any,
    max_tokens: params.maxTokens || 500,
    temperature: params.temperature || 0.7,
  });

  const usage = response.usage;
  const cost = usage
    ? ((usage.prompt_tokens / 1000) * 0.03 + (usage.completion_tokens / 1000) * 0.06)
    : 0;

  return {
    content: response.choices[0].message.content || '',
    usage,
    model: response.model,
    cost,
  };
}
