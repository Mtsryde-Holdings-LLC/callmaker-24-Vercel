/**
 * Stripe service for payment processing
 */

import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

export interface CreateCustomerParams {
  email: string;
  name: string;
  metadata?: Record<string, string>;
}

export async function createStripeCustomer(params: CreateCustomerParams) {
  return await stripe.customers.create({
    email: params.email,
    name: params.name,
    metadata: params.metadata,
  });
}

export interface CreateSubscriptionParams {
  customerId: string;
  priceId: string;
  trialDays?: number;
  paymentMethodId?: string;
}

export async function createSubscription(params: CreateSubscriptionParams) {
  const subscriptionParams: Stripe.SubscriptionCreateParams = {
    customer: params.customerId,
    items: [{ price: params.priceId }],
    trial_period_days: params.trialDays,
    payment_behavior: 'default_incomplete',
    expand: ['latest_invoice.payment_intent'],
  };

  // Add default payment method if provided
  if (params.paymentMethodId) {
    subscriptionParams.default_payment_method = params.paymentMethodId;
  }

  return await stripe.subscriptions.create(subscriptionParams);
}

export interface CancelSubscriptionParams {
  subscriptionId: string;
  immediately?: boolean;
}

export async function cancelSubscription(params: CancelSubscriptionParams) {
  const cancelParams: Stripe.SubscriptionCancelParams = {};

  // If immediately is false, cancel at period end, otherwise cancel immediately
  if (!params.immediately) {
    // Cancel at period end (default behavior)
    return await stripe.subscriptions.update(params.subscriptionId, {
      cancel_at_period_end: true,
    });
  }

  // Cancel immediately
  return await stripe.subscriptions.cancel(params.subscriptionId, cancelParams);
}

export async function updateSubscription(subscriptionId: string, priceId: string) {
  const subscription = await stripe.subscriptions.retrieve(subscriptionId);

  return await stripe.subscriptions.update(subscriptionId, {
    items: [
      {
        id: subscription.items.data[0].id,
        price: priceId,
      },
    ],
  });
}

export async function createPaymentIntent(amount: number, currency: string = 'usd') {
  return await stripe.paymentIntents.create({
    amount,
    currency,
    automatic_payment_methods: {
      enabled: true,
    },
  });
}

export async function handleWebhook(body: string, signature: string) {
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

  const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);

  switch (event.type) {
    case 'payment_intent.succeeded':
      // Handle successful payment
      console.log('Payment succeeded:', event.data.object);
      break;

    case 'customer.subscription.created':
      // Handle subscription creation
      console.log('Subscription created:', event.data.object);
      break;

    case 'customer.subscription.updated':
      // Handle subscription update
      console.log('Subscription updated:', event.data.object);
      break;

    case 'customer.subscription.deleted':
      // Handle subscription cancellation
      console.log('Subscription deleted:', event.data.object);
      break;

    case 'invoice.payment_failed':
      // Handle failed payment
      console.log('Payment failed:', event.data.object);
      break;

    default:
      console.log(`Unhandled event type: ${event.type}`);
  }

  return { received: true };
}
