/**
 * Amazon SNS service for sending SMS
 */

import { SNSClient, PublishCommand } from '@aws-sdk/client-sns';

const client = new SNSClient({ region: process.env.AWS_REGION || 'us-east-1' });

export interface SMSParams {
  phoneNumber: string;
  message: string;
  senderId?: string;
  smsType?: 'Promotional' | 'Transactional';
}

export async function sendSMS(params: SMSParams): Promise<{ messageId: string }> {
  const command = new PublishCommand({
    PhoneNumber: params.phoneNumber,
    Message: params.message,
    MessageAttributes: {
      'AWS.SNS.SMS.SMSType': {
        DataType: 'String',
        StringValue: params.smsType || 'Transactional',
      },
      ...(params.senderId && {
        'AWS.SNS.SMS.SenderID': {
          DataType: 'String',
          StringValue: params.senderId,
        },
      }),
    },
  });

  const response = await client.send(command);

  return {
    messageId: response.MessageId!,
  };
}

export async function sendBulkSMS(
  recipients: { phoneNumber: string; message: string }[]
): Promise<{ results: { messageId?: string; error?: string; phoneNumber: string }[] }> {
  const results = await Promise.allSettled(
    recipients.map((recipient) =>
      sendSMS({
        phoneNumber: recipient.phoneNumber,
        message: recipient.message,
      })
    )
  );

  return {
    results: results.map((result, index) => ({
      phoneNumber: recipients[index].phoneNumber,
      messageId: result.status === 'fulfilled' ? result.value.messageId : undefined,
      error: result.status === 'rejected' ? result.reason.message : undefined,
    })),
  };
}

export async function sendTransactionalSMS(
  phoneNumber: string,
  message: string
): Promise<{ messageId: string }> {
  return sendSMS({
    phoneNumber,
    message,
    smsType: 'Transactional',
  });
}
