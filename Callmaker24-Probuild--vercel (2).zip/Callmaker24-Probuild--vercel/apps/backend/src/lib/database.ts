/**
 * Database utilities for DynamoDB and RDS
 */

import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  UpdateCommand,
  DeleteCommand,
  QueryCommand,
  ScanCommand,
} from '@aws-sdk/lib-dynamodb';

const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(client);

export class DynamoDBService {
  constructor(private tableName: string) {}

  async get(key: Record<string, any>) {
    const command = new GetCommand({
      TableName: this.tableName,
      Key: key,
    });

    const response = await docClient.send(command);
    return response.Item;
  }

  async put(item: Record<string, any>) {
    const command = new PutCommand({
      TableName: this.tableName,
      Item: item,
    });

    await docClient.send(command);
    return item;
  }

  async update(
    keyOrData: Record<string, any>,
    updates?: Record<string, any>
  ) {
    // Support both patterns:
    // 1. update(key, updates) - separate key and updates
    // 2. update({ id, tenantId, ...updates }) - combined object
    let key: Record<string, any>;
    let updateData: Record<string, any>;

    if (updates) {
      // Pattern 1: separate parameters
      key = keyOrData;
      updateData = updates;
    } else {
      // Pattern 2: combined object - extract key fields
      const { id, tenantId, ...rest } = keyOrData;
      key = { id, tenantId };
      updateData = rest;
    }

    const updateExpression = Object.keys(updateData)
      .map((_k, i) => `#attr${i} = :val${i}`)
      .join(', ');

    const expressionAttributeNames = Object.keys(updateData).reduce(
      (acc, k, i) => ({
        ...acc,
        [`#attr${i}`]: k,
      }),
      {}
    );

    const expressionAttributeValues = Object.values(updateData).reduce(
      (acc, v, i) => ({
        ...acc,
        [`:val${i}`]: v,
      }),
      {}
    );

    const command = new UpdateCommand({
      TableName: this.tableName,
      Key: key,
      UpdateExpression: `SET ${updateExpression}`,
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
      ReturnValues: 'ALL_NEW',
    });

    const response = await docClient.send(command);
    return response.Attributes;
  }

  async delete(key: Record<string, any>) {
    const command = new DeleteCommand({
      TableName: this.tableName,
      Key: key,
    });

    await docClient.send(command);
  }

  async query(
    keyCondition: string,
    expressionAttributeValues: Record<string, any>,
    expressionAttributeNames?: Record<string, string>
  ) {
    const command = new QueryCommand({
      TableName: this.tableName,
      KeyConditionExpression: keyCondition,
      ExpressionAttributeValues: expressionAttributeValues,
      ExpressionAttributeNames: expressionAttributeNames,
    });

    const response = await docClient.send(command);
    return response.Items || [];
  }

  async scan(filterExpression?: string, expressionAttributeValues?: Record<string, any>) {
    const command = new ScanCommand({
      TableName: this.tableName,
      FilterExpression: filterExpression,
      ExpressionAttributeValues: expressionAttributeValues,
    });

    const response = await docClient.send(command);
    return response.Items || [];
  }

  /**
   * Find customer by phone number
   */
  async findByPhoneNumber(params: { tenantId: string; phoneNumber: string }) {
    const command = new QueryCommand({
      TableName: this.tableName,
      IndexName: 'phoneNumber-index',
      KeyConditionExpression: 'phoneNumber = :phoneNumber AND tenantId = :tenantId',
      ExpressionAttributeValues: {
        ':phoneNumber': params.phoneNumber,
        ':tenantId': params.tenantId,
      },
      Limit: 1,
    });

    const response = await docClient.send(command);
    return response.Items && response.Items.length > 0 ? response.Items[0] : null;
  }

  /**
   * Query customers by segments
   */
  async queryBySegments(params: {
    tenantId: string;
    segments: string[];
    smsOptIn?: boolean;
  }): Promise<any[]> {
    const { tenantId, segments, smsOptIn } = params;

    // Query customers in the specified segments
    const command = new QueryCommand({
      TableName: this.tableName,
      IndexName: 'tenantId-index',
      KeyConditionExpression: 'tenantId = :tenantId',
      FilterExpression: smsOptIn !== undefined
        ? 'contains(segments, :segment) AND smsOptIn = :smsOptIn'
        : 'contains(segments, :segment)',
      ExpressionAttributeValues: {
        ':tenantId': tenantId,
        ':segment': segments[0], // Simplified: just check first segment
        ...(smsOptIn !== undefined && { ':smsOptIn': smsOptIn }),
      },
    });

    const response = await docClient.send(command);
    return response.Items || [];
  }

  /**
   * Batch create items
   */
  async batchCreate(items: Record<string, any>[]): Promise<void> {
    // DynamoDB BatchWriteItem has a limit of 25 items per request
    const batchSize = 25;

    for (let i = 0; i < items.length; i += batchSize) {
      const batch = items.slice(i, i + batchSize);

      // Use individual puts for batch operations
      // In production, consider using BatchWriteItemCommand from @aws-sdk/client-dynamodb
      for (const item of batch) {
        await this.put(item);
      }
    }
  }
}

// Table services
export const customersTable = new DynamoDBService(
  process.env.DYNAMODB_CUSTOMERS_TABLE || 'marketing-platform-customers'
);

export const campaignsTable = new DynamoDBService(
  process.env.DYNAMODB_CAMPAIGNS_TABLE || 'marketing-platform-campaigns'
);

export const messagesTable = new DynamoDBService(
  process.env.DYNAMODB_MESSAGES_TABLE || 'marketing-platform-messages'
);

export const conversationsTable = new DynamoDBService(
  process.env.DYNAMODB_CONVERSATIONS_TABLE || 'marketing-platform-conversations'
);
