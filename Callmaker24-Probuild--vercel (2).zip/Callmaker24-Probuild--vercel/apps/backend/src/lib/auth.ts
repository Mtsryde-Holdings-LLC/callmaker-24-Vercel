/**
 * JWT Authentication and Authorization Library
 */

import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import {
  AuthPayload,
  UserRole,
  SubscriptionTier,
  Permission,
  SubscriptionPermissions,
  RolePermissions,
} from '../types/auth';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'your-refresh-secret-key';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '1h';
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '7d';

/**
 * Hash a password using bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

/**
 * Compare a password with a hash
 */
export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

/**
 * Get permissions for a user based on role and subscription tier
 */
export function getUserPermissions(
  role: UserRole,
  subscriptionTier?: SubscriptionTier,
  customPermissions?: string[]
): Permission[] {
  // Super admin has all permissions
  if (role === UserRole.SUPER_ADMIN) {
    return Object.values(Permission);
  }

  // Start with role-based permissions
  let permissions: Permission[] = [];

  if (RolePermissions[role] !== 'ALL') {
    permissions = [...RolePermissions[role]];
  }

  // Add subscription tier permissions for admins
  if (role === UserRole.ADMIN && subscriptionTier) {
    const tierPermissions = SubscriptionPermissions[subscriptionTier] || [];
    permissions = [...new Set([...permissions, ...tierPermissions])];
  }

  // Add custom permissions
  if (customPermissions && customPermissions.length > 0) {
    const validCustomPermissions = customPermissions.filter((p) =>
      Object.values(Permission).includes(p as Permission)
    ) as Permission[];
    permissions = [...new Set([...permissions, ...validCustomPermissions])];
  }

  return permissions;
}

/**
 * Generate JWT access token
 */
export function generateToken(payload: AuthPayload): string {
  return jwt.sign(payload as Record<string, any>, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  } as jwt.SignOptions);
}

/**
 * Generate JWT refresh token
 */
export function generateRefreshToken(payload: Omit<AuthPayload, 'permissions'>): string {
  return jwt.sign(payload as Record<string, any>, JWT_REFRESH_SECRET, {
    expiresIn: JWT_REFRESH_EXPIRES_IN,
  } as jwt.SignOptions);
}

/**
 * Verify JWT access token
 */
export function verifyToken(token: string): AuthPayload {
  try {
    return jwt.verify(token, JWT_SECRET) as AuthPayload;
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      throw new Error('TOKEN_EXPIRED');
    }
    throw new Error('INVALID_TOKEN');
  }
}

/**
 * Verify JWT refresh token
 */
export function verifyRefreshToken(token: string): Omit<AuthPayload, 'permissions'> {
  try {
    return jwt.verify(token, JWT_REFRESH_SECRET) as Omit<AuthPayload, 'permissions'>;
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      throw new Error('REFRESH_TOKEN_EXPIRED');
    }
    throw new Error('INVALID_REFRESH_TOKEN');
  }
}

/**
 * Check if user has specific permission
 */
export function hasPermission(userPermissions: Permission[], requiredPermission: Permission): boolean {
  return userPermissions.includes(requiredPermission);
}

/**
 * Check if user has any of the required permissions
 */
export function hasAnyPermission(userPermissions: Permission[], requiredPermissions: Permission[]): boolean {
  return requiredPermissions.some((permission) => userPermissions.includes(permission));
}

/**
 * Check if user has all required permissions
 */
export function hasAllPermissions(userPermissions: Permission[], requiredPermissions: Permission[]): boolean {
  return requiredPermissions.every((permission) => userPermissions.includes(permission));
}

/**
 * Check if user has specific role
 */
export function hasRole(userRole: UserRole, requiredRole: UserRole): boolean {
  // Super admin can access everything
  if (userRole === UserRole.SUPER_ADMIN) {
    return true;
  }
  return userRole === requiredRole;
}

/**
 * Check if user has minimum role (role hierarchy)
 */
export function hasMinimumRole(userRole: UserRole, minimumRole: UserRole): boolean {
  const roleHierarchy = {
    [UserRole.SUPER_ADMIN]: 4,
    [UserRole.ADMIN]: 3,
    [UserRole.USER]: 2,
    [UserRole.GUEST]: 1,
  };

  return roleHierarchy[userRole] >= roleHierarchy[minimumRole];
}

/**
 * Extract token from Authorization header
 */
export function extractTokenFromHeader(authHeader?: string): string | null {
  if (!authHeader) {
    return null;
  }

  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return null;
  }

  return parts[1];
}

/**
 * Validate email format
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate password strength
 */
export function isValidPassword(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long');
  }

  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }

  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }

  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain at least one number');
  }

  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    errors.push('Password must contain at least one special character');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Generate a tenant ID
 */
export function generateTenantId(): string {
  return `tenant_${Date.now()}_${Math.random().toString(36).substring(7)}`;
}
