/**
 * Authentication and Authorization Type Definitions
 */

// User roles in the system
export enum UserRole {
  SUPER_ADMIN = 'SUPER_ADMIN', // Full access to everything
  ADMIN = 'ADMIN',              // Access based on subscription tier
  USER = 'USER',                 // Regular user with limited access
  GUEST = 'GUEST',               // Read-only access
}

// Subscription tiers
export enum SubscriptionTier {
  FREE = 'FREE',
  STARTER = 'STARTER',
  PROFESSIONAL = 'PROFESSIONAL',
  ENTERPRISE = 'ENTERPRISE',
}

// System permissions
export enum Permission {
  // User Management
  USER_CREATE = 'USER_CREATE',
  USER_READ = 'USER_READ',
  USER_UPDATE = 'USER_UPDATE',
  USER_DELETE = 'USER_DELETE',
  USER_ASSIGN_ROLES = 'USER_ASSIGN_ROLES',

  // Customer Management
  CUSTOMER_CREATE = 'CUSTOMER_CREATE',
  CUSTOMER_READ = 'CUSTOMER_READ',
  CUSTOMER_UPDATE = 'CUSTOMER_UPDATE',
  CUSTOMER_DELETE = 'CUSTOMER_DELETE',
  CUSTOMER_IMPORT = 'CUSTOMER_IMPORT',
  CUSTOMER_EXPORT = 'CUSTOMER_EXPORT',

  // Campaign Management
  CAMPAIGN_CREATE = 'CAMPAIGN_CREATE',
  CAMPAIGN_READ = 'CAMPAIGN_READ',
  CAMPAIGN_UPDATE = 'CAMPAIGN_UPDATE',
  CAMPAIGN_DELETE = 'CAMPAIGN_DELETE',
  CAMPAIGN_SEND = 'CAMPAIGN_SEND',

  // Email Marketing
  EMAIL_SEND = 'EMAIL_SEND',
  EMAIL_TEMPLATE_MANAGE = 'EMAIL_TEMPLATE_MANAGE',

  // SMS Marketing
  SMS_SEND = 'SMS_SEND',
  SMS_TEMPLATE_MANAGE = 'SMS_TEMPLATE_MANAGE',
  SMS_CONVERSATION_MANAGE = 'SMS_CONVERSATION_MANAGE',

  // IVR/Voice
  VOICE_CALL_INITIATE = 'VOICE_CALL_INITIATE',
  VOICE_FLOW_MANAGE = 'VOICE_FLOW_MANAGE',
  VOICE_ANALYTICS_VIEW = 'VOICE_ANALYTICS_VIEW',

  // Social Media
  SOCIAL_CONTENT_CREATE = 'SOCIAL_CONTENT_CREATE',
  SOCIAL_CONTENT_PUBLISH = 'SOCIAL_CONTENT_PUBLISH',
  SOCIAL_ACCOUNT_MANAGE = 'SOCIAL_ACCOUNT_MANAGE',

  // Analytics
  ANALYTICS_VIEW = 'ANALYTICS_VIEW',
  ANALYTICS_EXPORT = 'ANALYTICS_EXPORT',

  // Integrations
  INTEGRATION_MANAGE = 'INTEGRATION_MANAGE',

  // Billing & Subscriptions
  BILLING_MANAGE = 'BILLING_MANAGE',
  SUBSCRIPTION_MANAGE = 'SUBSCRIPTION_MANAGE',

  // System Administration
  SYSTEM_SETTINGS = 'SYSTEM_SETTINGS',
  SYSTEM_LOGS = 'SYSTEM_LOGS',
  SYSTEM_BACKUP = 'SYSTEM_BACKUP',
}

// Permission groups for easier assignment
export const PermissionGroups = {
  USER_MANAGEMENT: [
    Permission.USER_CREATE,
    Permission.USER_READ,
    Permission.USER_UPDATE,
    Permission.USER_DELETE,
    Permission.USER_ASSIGN_ROLES,
  ],
  CUSTOMER_MANAGEMENT: [
    Permission.CUSTOMER_CREATE,
    Permission.CUSTOMER_READ,
    Permission.CUSTOMER_UPDATE,
    Permission.CUSTOMER_DELETE,
    Permission.CUSTOMER_IMPORT,
    Permission.CUSTOMER_EXPORT,
  ],
  MARKETING: [
    Permission.CAMPAIGN_CREATE,
    Permission.CAMPAIGN_READ,
    Permission.CAMPAIGN_UPDATE,
    Permission.CAMPAIGN_DELETE,
    Permission.CAMPAIGN_SEND,
    Permission.EMAIL_SEND,
    Permission.EMAIL_TEMPLATE_MANAGE,
    Permission.SMS_SEND,
    Permission.SMS_TEMPLATE_MANAGE,
  ],
  VOICE: [
    Permission.VOICE_CALL_INITIATE,
    Permission.VOICE_FLOW_MANAGE,
    Permission.VOICE_ANALYTICS_VIEW,
  ],
  SOCIAL_MEDIA: [
    Permission.SOCIAL_CONTENT_CREATE,
    Permission.SOCIAL_CONTENT_PUBLISH,
    Permission.SOCIAL_ACCOUNT_MANAGE,
  ],
  ANALYTICS: [
    Permission.ANALYTICS_VIEW,
    Permission.ANALYTICS_EXPORT,
  ],
};

// Define base permissions for each tier
const FREE_PERMISSIONS = [
  Permission.CUSTOMER_READ,
  Permission.CAMPAIGN_READ,
  Permission.ANALYTICS_VIEW,
];

const STARTER_PERMISSIONS = [
  ...FREE_PERMISSIONS,
  Permission.CUSTOMER_CREATE,
  Permission.CUSTOMER_UPDATE,
  Permission.CAMPAIGN_CREATE,
  Permission.CAMPAIGN_UPDATE,
  Permission.EMAIL_SEND,
  Permission.SMS_SEND,
];

const PROFESSIONAL_PERMISSIONS = [
  ...STARTER_PERMISSIONS,
  Permission.CUSTOMER_DELETE,
  Permission.CUSTOMER_IMPORT,
  Permission.CUSTOMER_EXPORT,
  Permission.CAMPAIGN_DELETE,
  Permission.CAMPAIGN_SEND,
  Permission.EMAIL_TEMPLATE_MANAGE,
  Permission.SMS_TEMPLATE_MANAGE,
  Permission.SMS_CONVERSATION_MANAGE,
  Permission.SOCIAL_CONTENT_CREATE,
  Permission.SOCIAL_CONTENT_PUBLISH,
  Permission.ANALYTICS_EXPORT,
];

const ENTERPRISE_PERMISSIONS = [
  ...PROFESSIONAL_PERMISSIONS,
  Permission.USER_CREATE,
  Permission.USER_READ,
  Permission.USER_UPDATE,
  Permission.VOICE_CALL_INITIATE,
  Permission.VOICE_FLOW_MANAGE,
  Permission.VOICE_ANALYTICS_VIEW,
  Permission.SOCIAL_ACCOUNT_MANAGE,
  Permission.INTEGRATION_MANAGE,
  Permission.BILLING_MANAGE,
  Permission.SUBSCRIPTION_MANAGE,
];

// Subscription tier permission mapping
export const SubscriptionPermissions: Record<SubscriptionTier, Permission[]> = {
  [SubscriptionTier.FREE]: FREE_PERMISSIONS,
  [SubscriptionTier.STARTER]: STARTER_PERMISSIONS,
  [SubscriptionTier.PROFESSIONAL]: PROFESSIONAL_PERMISSIONS,
  [SubscriptionTier.ENTERPRISE]: ENTERPRISE_PERMISSIONS,
};

// Role-based permissions
export const RolePermissions: Record<UserRole, Permission[] | 'ALL'> = {
  [UserRole.SUPER_ADMIN]: 'ALL', // Super admin has all permissions
  [UserRole.ADMIN]: [], // Admin permissions determined by subscription tier
  [UserRole.USER]: [
    Permission.CUSTOMER_READ,
    Permission.CAMPAIGN_READ,
    Permission.ANALYTICS_VIEW,
  ],
  [UserRole.GUEST]: [
    Permission.CUSTOMER_READ,
    Permission.CAMPAIGN_READ,
  ],
};

// User authentication payload (JWT)
export interface AuthPayload {
  userId: string;
  email: string;
  role: UserRole;
  tenantId: string;
  subscriptionTier?: SubscriptionTier;
  permissions: Permission[];
  iat?: number;
  exp?: number;
}

// User signup request
export interface SignupRequest {
  email: string;
  password: string;
  name?: string;
  tenantId?: string;
  role?: UserRole; // Only super admin can set this
  subscriptionTier?: SubscriptionTier;
}

// User signin request
export interface SigninRequest {
  email: string;
  password: string;
}

// User signin response
export interface AuthResponse {
  success: boolean;
  token?: string;
  refreshToken?: string;
  user?: {
    id: string;
    email: string;
    name?: string;
    role: UserRole;
    subscriptionTier?: SubscriptionTier;
    permissions: Permission[];
    tenantId: string;
  };
  error?: {
    code: string;
    message: string;
  };
}

// User update request (for admin)
export interface UpdateUserRequest {
  userId: string;
  role?: UserRole;
  permissions?: Permission[];
  subscriptionTier?: SubscriptionTier;
  isActive?: boolean;
}

// User assignment request
export interface AssignRoleRequest {
  userId: string;
  role: UserRole;
  permissions?: Permission[]; // Custom permissions (override defaults)
  functions?: string[]; // Specific function access
}
