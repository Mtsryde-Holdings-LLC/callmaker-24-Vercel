/**
 * Authentication and Authorization Middleware
 */

import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { verifyToken, extractTokenFromHeader, hasPermission, hasRole, hasMinimumRole } from '../lib/auth';
import { AuthPayload, Permission, UserRole } from '../types/auth';

/**
 * Authenticated request with user context
 */
export interface AuthenticatedEvent extends APIGatewayProxyEvent {
  user: AuthPayload;
}

/**
 * Middleware to authenticate requests
 */
export function authenticate(handler: (event: AuthenticatedEvent) => Promise<APIGatewayProxyResult>) {
  return async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
    try {
      // Extract token from Authorization header
      const token = extractTokenFromHeader(event.headers?.Authorization || event.headers?.authorization);

      if (!token) {
        return {
          statusCode: 401,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'UNAUTHORIZED',
              message: 'Missing authentication token',
            },
          }),
        };
      }

      // Verify token
      const user = verifyToken(token);

      // Check if user is active
      if (!user) {
        return {
          statusCode: 401,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'UNAUTHORIZED',
              message: 'Invalid authentication token',
            },
          }),
        };
      }

      // Attach user to event
      const authenticatedEvent = event as AuthenticatedEvent;
      authenticatedEvent.user = user;

      // Call the handler
      return await handler(authenticatedEvent);
    } catch (error: any) {
      if (error.message === 'TOKEN_EXPIRED') {
        return {
          statusCode: 401,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'TOKEN_EXPIRED',
              message: 'Authentication token has expired',
            },
          }),
        };
      }

      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'Invalid authentication token',
          },
        }),
      };
    }
  };
}

/**
 * Middleware to check if user has required permission
 */
export function requirePermission(permission: Permission) {
  return function (handler: (event: AuthenticatedEvent) => Promise<APIGatewayProxyResult>) {
    return authenticate(async (event: AuthenticatedEvent): Promise<APIGatewayProxyResult> => {
      const user = event.user;

      if (!hasPermission(user.permissions, permission)) {
        return {
          statusCode: 403,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'FORBIDDEN',
              message: `Insufficient permissions. Required: ${permission}`,
            },
          }),
        };
      }

      return await handler(event);
    });
  };
}

/**
 * Middleware to check if user has any of the required permissions
 */
export function requireAnyPermission(permissions: Permission[]) {
  return function (handler: (event: AuthenticatedEvent) => Promise<APIGatewayProxyResult>) {
    return authenticate(async (event: AuthenticatedEvent): Promise<APIGatewayProxyResult> => {
      const user = event.user;

      const hasAny = permissions.some((permission) => hasPermission(user.permissions, permission));

      if (!hasAny) {
        return {
          statusCode: 403,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'FORBIDDEN',
              message: `Insufficient permissions. Required one of: ${permissions.join(', ')}`,
            },
          }),
        };
      }

      return await handler(event);
    });
  };
}

/**
 * Middleware to check if user has specific role
 */
export function requireRole(role: UserRole) {
  return function (handler: (event: AuthenticatedEvent) => Promise<APIGatewayProxyResult>) {
    return authenticate(async (event: AuthenticatedEvent): Promise<APIGatewayProxyResult> => {
      const user = event.user;

      if (!hasRole(user.role, role)) {
        return {
          statusCode: 403,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'FORBIDDEN',
              message: `Insufficient role. Required: ${role}`,
            },
          }),
        };
      }

      return await handler(event);
    });
  };
}

/**
 * Middleware to check if user has minimum role (role hierarchy)
 */
export function requireMinimumRole(minimumRole: UserRole) {
  return function (handler: (event: AuthenticatedEvent) => Promise<APIGatewayProxyResult>) {
    return authenticate(async (event: AuthenticatedEvent): Promise<APIGatewayProxyResult> => {
      const user = event.user;

      if (!hasMinimumRole(user.role, minimumRole)) {
        return {
          statusCode: 403,
          body: JSON.stringify({
            success: false,
            error: {
              code: 'FORBIDDEN',
              message: `Insufficient role. Required minimum: ${minimumRole}`,
            },
          }),
        };
      }

      return await handler(event);
    });
  };
}

/**
 * Middleware to check if user is super admin
 */
export function requireSuperAdmin() {
  return requireRole(UserRole.SUPER_ADMIN);
}

/**
 * Middleware to check if user is admin or super admin
 */
export function requireAdmin() {
  return requireMinimumRole(UserRole.ADMIN);
}

/**
 * Middleware to validate tenant access
 */
export function requireTenantAccess(handler: (event: AuthenticatedEvent) => Promise<APIGatewayProxyResult>) {
  return authenticate(async (event: AuthenticatedEvent): Promise<APIGatewayProxyResult> => {
    const user = event.user;
    const requestTenantId = event.headers['X-Tenant-ID'] || event.headers['x-tenant-id'];

    // Super admin can access all tenants
    if (user.role === UserRole.SUPER_ADMIN) {
      return await handler(event);
    }

    // Check if user belongs to the requested tenant
    if (user.tenantId !== requestTenantId) {
      return {
        statusCode: 403,
        body: JSON.stringify({
          success: false,
          error: {
            code: 'FORBIDDEN',
            message: 'Access denied to this tenant',
          },
        }),
      };
    }

    return await handler(event);
  });
}
