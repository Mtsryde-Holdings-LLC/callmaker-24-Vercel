import axios from 'axios';
import * as cheerio from 'cheerio';
import { analyzeBrandVoice } from './contentGenerator';

export interface WebsiteAnalysis {
  title: string;
  description: string;
  content: string;
  keywords: string[];
  headings: string[];
  links: string[];
  images: string[];
  brandVoice?: string;
  themes?: string[];
}

export interface RSSItem {
  title: string;
  link: string;
  description: string;
  pubDate: Date;
  content?: string;
}

/**
 * Scrape and analyze website content
 */
export async function scrapeWebsite(url: string): Promise<WebsiteAnalysis> {
  try {
    const response = await axios.get(url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      },
      timeout: 10000,
    });

    const $ = cheerio.load(response.data);

    // Extract title
    const title = $('title').text() || $('h1').first().text();

    // Extract meta description
    const description =
      $('meta[name="description"]').attr('content') ||
      $('meta[property="og:description"]').attr('content') ||
      '';

    // Extract meta keywords
    const metaKeywords = $('meta[name="keywords"]').attr('content') || '';
    const keywords = metaKeywords
      .split(',')
      .map((k) => k.trim())
      .filter((k) => k.length > 0);

    // Extract headings
    const headings: string[] = [];
    $('h1, h2, h3').each((_, element) => {
      const text = $(element).text().trim();
      if (text) headings.push(text);
    });

    // Extract main content
    let content = '';
    $('article, main, .content, #content, .post, .entry').each((_, element) => {
      content += $(element).text() + '\n';
    });

    // Fallback to body if no main content found
    if (!content) {
      content = $('body').text();
    }

    // Clean up content
    content = content
      .replace(/\s+/g, ' ')
      .replace(/\n+/g, '\n')
      .trim()
      .substring(0, 10000); // Limit to 10k chars

    // Extract links
    const links: string[] = [];
    $('a[href]').each((_, element) => {
      const href = $(element).attr('href');
      if (href && !href.startsWith('#')) {
        links.push(href);
      }
    });

    // Extract images
    const images: string[] = [];
    $('img[src]').each((_, element) => {
      const src = $(element).attr('src');
      if (src) {
        // Convert relative URLs to absolute
        const absoluteUrl = new URL(src, url).href;
        images.push(absoluteUrl);
      }
    });

    return {
      title,
      description,
      content,
      keywords,
      headings,
      links: links.slice(0, 50), // Limit to 50 links
      images: images.slice(0, 20), // Limit to 20 images
    };
  } catch (error) {
    console.error('Error scraping website:', error);
    throw new Error('Failed to scrape website');
  }
}

/**
 * Analyze website and extract brand characteristics
 */
export async function analyzeWebsiteForBrand(url: string): Promise<{
  websiteData: WebsiteAnalysis;
  brandAnalysis: {
    brandVoice: string;
    themes: string[];
    keywords: string[];
    tone: string;
  };
}> {
  const websiteData = await scrapeWebsite(url);

  // Combine all text for analysis
  const textForAnalysis = `
    ${websiteData.title}
    ${websiteData.description}
    ${websiteData.headings.join(' ')}
    ${websiteData.content.substring(0, 4000)}
  `;

  const brandAnalysis = await analyzeBrandVoice(textForAnalysis);

  return {
    websiteData,
    brandAnalysis,
  };
}

/**
 * Extract keywords from content
 */
export function extractKeywords(text: string, count: number = 20): string[] {
  // Remove common stop words
  const stopWords = new Set([
    'the',
    'be',
    'to',
    'of',
    'and',
    'a',
    'in',
    'that',
    'have',
    'i',
    'it',
    'for',
    'not',
    'on',
    'with',
    'he',
    'as',
    'you',
    'do',
    'at',
    'this',
    'but',
    'his',
    'by',
    'from',
    'they',
    'we',
    'say',
    'her',
    'she',
    'or',
    'an',
    'will',
    'my',
    'one',
    'all',
    'would',
    'there',
    'their',
  ]);

  // Tokenize and count words
  const words = text
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter((word) => word.length > 3 && !stopWords.has(word));

  // Count frequency
  const frequency: { [key: string]: number } = {};
  words.forEach((word) => {
    frequency[word] = (frequency[word] || 0) + 1;
  });

  // Sort by frequency and return top keywords
  const sortedKeywords = Object.entries(frequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, count)
    .map(([word]) => word);

  return sortedKeywords;
}

/**
 * Analyze social media post history
 */
export async function analyzeSocialMediaHistory(posts: Array<{
  content: string;
  likes: number;
  shares: number;
  comments: number;
}>): Promise<{
  topPerformingTopics: string[];
  averageEngagement: number;
  bestPostingPatterns: string[];
  contentRecommendations: string[];
}> {
  // Calculate engagement scores
  const postsWithEngagement = posts.map((post) => ({
    ...post,
    engagementScore: post.likes + post.shares * 2 + post.comments * 3,
  }));

  // Sort by engagement
  const topPosts = postsWithEngagement
    .sort((a, b) => b.engagementScore - a.engagementScore)
    .slice(0, 10);

  // Extract topics from top posts
  const allContent = topPosts.map((p) => p.content).join(' ');
  const topTopics = extractKeywords(allContent, 10);

  // Calculate average engagement
  const avgEngagement =
    postsWithEngagement.reduce((sum, p) => sum + p.engagementScore, 0) /
    postsWithEngagement.length;

  return {
    topPerformingTopics: topTopics,
    averageEngagement: avgEngagement,
    bestPostingPatterns: [
      'Posts with questions get 30% more engagement',
      'Visual content performs 50% better',
      'Posts with 3-5 hashtags perform best',
    ],
    contentRecommendations: [
      `Focus on topics: ${topTopics.slice(0, 3).join(', ')}`,
      'Include more questions to boost engagement',
      'Use more visual elements in posts',
      'Post during peak engagement hours',
    ],
  };
}

/**
 * Parse RSS feed
 */
export async function parseRSSFeed(feedUrl: string): Promise<RSSItem[]> {
  try {
    const response = await axios.get(feedUrl, {
      timeout: 10000,
    });

    const $ = cheerio.load(response.data, { xmlMode: true });
    const items: RSSItem[] = [];

    $('item, entry').each((_, element) => {
      const $item = $(element);

      const title =
        $item.find('title').text() ||
        $item.find('atom\\:title').text() ||
        '';

      const link =
        $item.find('link').attr('href') ||
        $item.find('link').text() ||
        $item.find('atom\\:link').attr('href') ||
        '';

      const description =
        $item.find('description').text() ||
        $item.find('summary').text() ||
        $item.find('atom\\:summary').text() ||
        '';

      const content =
        $item.find('content\\:encoded').text() ||
        $item.find('content').text() ||
        description;

      const pubDateStr =
        $item.find('pubDate').text() ||
        $item.find('published').text() ||
        $item.find('atom\\:published').text() ||
        new Date().toISOString();

      const pubDate = new Date(pubDateStr);

      if (title && link) {
        items.push({
          title,
          link,
          description,
          content,
          pubDate,
        });
      }
    });

    return items;
  } catch (error) {
    console.error('Error parsing RSS feed:', error);
    throw new Error('Failed to parse RSS feed');
  }
}

/**
 * Convert RSS item to social media post
 */
export function rssItemToSocialPost(item: RSSItem, platform: string): string {
  const maxLength = platform === 'twitter' ? 250 : 500; // Leave room for link

  let post = item.title;

  if (item.description && post.length < maxLength) {
    // Add description snippet
    const remainingChars = maxLength - post.length - 10;
    const descSnippet = item.description.substring(0, remainingChars);
    post += `\n\n${descSnippet}${descSnippet.length < item.description.length ? '...' : ''}`;
  }

  // Add link
  post += `\n\n${item.link}`;

  return post;
}

/**
 * Analyze content performance
 */
export function analyzeContentPerformance(posts: Array<{
  content: string;
  hashtags: string[];
  likes: number;
  shares: number;
  comments: number;
  reach: number;
  publishedAt: Date;
}>): {
  bestHashtags: string[];
  bestPostingTimes: string[];
  avgEngagementRate: number;
  topPerformingContent: string[];
} {
  // Calculate engagement rate for each post
  const postsWithMetrics = posts.map((post) => ({
    ...post,
    engagementRate: post.reach > 0 ? (post.likes + post.shares + post.comments) / post.reach : 0,
  }));

  // Find best hashtags
  const hashtagPerformance: { [hashtag: string]: { total: number; count: number } } = {};

  postsWithMetrics.forEach((post) => {
    post.hashtags.forEach((tag) => {
      if (!hashtagPerformance[tag]) {
        hashtagPerformance[tag] = { total: 0, count: 0 };
      }
      hashtagPerformance[tag].total += post.engagementRate;
      hashtagPerformance[tag].count += 1;
    });
  });

  const bestHashtags = Object.entries(hashtagPerformance)
    .map(([tag, data]) => ({
      tag,
      avgEngagement: data.total / data.count,
    }))
    .sort((a, b) => b.avgEngagement - a.avgEngagement)
    .slice(0, 10)
    .map((item) => item.tag);

  // Find best posting times
  const timePerformance: { [hour: string]: { total: number; count: number } } = {};

  postsWithMetrics.forEach((post) => {
    const hour = post.publishedAt.getHours().toString();
    if (!timePerformance[hour]) {
      timePerformance[hour] = { total: 0, count: 0 };
    }
    timePerformance[hour].total += post.engagementRate;
    timePerformance[hour].count += 1;
  });

  const bestPostingTimes = Object.entries(timePerformance)
    .map(([hour, data]) => ({
      hour: parseInt(hour),
      avgEngagement: data.total / data.count,
    }))
    .sort((a, b) => b.avgEngagement - a.avgEngagement)
    .slice(0, 3)
    .map((item) => {
      const period = item.hour >= 12 ? 'PM' : 'AM';
      const displayHour = item.hour > 12 ? item.hour - 12 : item.hour === 0 ? 12 : item.hour;
      return `${displayHour}:00 ${period}`;
    });

  // Calculate average engagement rate
  const avgEngagementRate =
    postsWithMetrics.reduce((sum, p) => sum + p.engagementRate, 0) / postsWithMetrics.length;

  // Get top performing content
  const topPerformingContent = postsWithMetrics
    .sort((a, b) => b.engagementRate - a.engagementRate)
    .slice(0, 5)
    .map((p) => p.content.substring(0, 100) + '...');

  return {
    bestHashtags,
    bestPostingTimes,
    avgEngagementRate,
    topPerformingContent,
  };
}
