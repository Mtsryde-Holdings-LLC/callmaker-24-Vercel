import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface ContentGenerationParams {
  topic: string;
  businessType: string;
  targetAudience: string;
  platform: 'twitter' | 'facebook' | 'instagram' | 'linkedin' | 'tiktok';
  tone?: 'professional' | 'casual' | 'friendly' | 'informative' | 'humorous';
  contentType?: 'post' | 'story' | 'tweet' | 'article' | 'caption';
  maxLength?: number;
  includeHashtags?: boolean;
  includeEmojis?: boolean;
  includeCallToAction?: boolean;
  brandVoice?: string;
  keywords?: string[];
}

export interface ContentVariation {
  content: string;
  hashtags: string[];
  estimatedReach?: string;
  sentiment?: 'positive' | 'neutral' | 'negative';
}

export interface GeneratedContent {
  mainContent: string;
  variations: ContentVariation[];
  hashtags: string[];
  suggestedImages?: string[];
  bestTimeToPost?: string;
  estimatedEngagement?: string;
  estimatedReach?: string;
}

/**
 * Generate social media content using OpenAI GPT-4
 */
export async function generateContent(
  params: ContentGenerationParams
): Promise<GeneratedContent> {
  const {
    topic,
    businessType,
    targetAudience,
    platform,
    tone = 'professional',
    contentType = 'post',
    maxLength,
    includeHashtags = true,
    includeEmojis = true,
    includeCallToAction = true,
    brandVoice,
    keywords = [],
  } = params;

  // Platform-specific constraints
  const platformLimits = {
    twitter: 280,
    facebook: 5000,
    instagram: 2200,
    linkedin: 3000,
    tiktok: 2200,
  };

  const charLimit = maxLength || platformLimits[platform];

  // Build the prompt
  const prompt = buildContentPrompt({
    topic,
    businessType,
    targetAudience,
    platform,
    tone,
    contentType,
    charLimit,
    includeHashtags,
    includeEmojis,
    includeCallToAction,
    brandVoice,
    keywords,
  });

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      messages: [
        {
          role: 'system',
          content: `You are an expert social media content creator specializing in ${platform} content for ${businessType} businesses. You understand marketing psychology, engagement tactics, and platform-specific best practices.`,
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.8,
      max_tokens: 1500,
    });

    const responseText = completion.choices[0].message.content || '';

    // Parse the AI response
    const parsedContent = parseAIResponse(responseText, platform);

    return parsedContent;
  } catch (error) {
    console.error('Error generating content:', error);
    throw new Error('Failed to generate content');
  }
}

/**
 * Generate multiple content variations for A/B testing
 */
export async function generateContentVariations(
  params: ContentGenerationParams,
  count: number = 3
): Promise<ContentVariation[]> {
  const variations: ContentVariation[] = [];

  const tones: Array<'professional' | 'casual' | 'friendly' | 'informative' | 'humorous'> = [
    'professional',
    'casual',
    'friendly',
    'informative',
    'humorous',
  ];

  for (let i = 0; i < count; i++) {
    const tone = tones[i % tones.length];
    const result = await generateContent({ ...params, tone });

    variations.push({
      content: result.mainContent,
      hashtags: result.hashtags,
      estimatedReach: result.estimatedReach,
      sentiment: analyzeSentiment(result.mainContent),
    });

    // Add small delay to avoid rate limiting
    await new Promise((resolve) => setTimeout(resolve, 500));
  }

  return variations;
}

/**
 * Analyze website content to extract brand voice and themes
 */
export async function analyzeBrandVoice(
  websiteContent: string
): Promise<{
  brandVoice: string;
  themes: string[];
  keywords: string[];
  tone: string;
}> {
  const prompt = `Analyze this website content and extract:
1. The brand voice and tone (professional, casual, friendly, etc.)
2. Key themes and topics discussed
3. Important keywords that represent the brand
4. Overall communication style

Website content:
${websiteContent.substring(0, 4000)}

Provide your analysis in the following JSON format:
{
  "brandVoice": "description of brand voice",
  "themes": ["theme1", "theme2"],
  "keywords": ["keyword1", "keyword2"],
  "tone": "primary tone"
}`;

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      messages: [
        {
          role: 'system',
          content:
            'You are a brand analysis expert. Analyze content and extract brand characteristics.',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.3,
      response_format: { type: 'json_object' },
    });

    const analysis = JSON.parse(completion.choices[0].message.content || '{}');
    return analysis;
  } catch (error) {
    console.error('Error analyzing brand voice:', error);
    throw new Error('Failed to analyze brand voice');
  }
}

/**
 * Generate hashtags for content
 */
export async function generateHashtags(
  content: string,
  platform: string,
  count: number = 10
): Promise<string[]> {
  const prompt = `Generate ${count} relevant and trending hashtags for this ${platform} content:

"${content}"

Return only the hashtags, one per line, with the # symbol.`;

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      messages: [
        {
          role: 'system',
          content: 'You are a social media hashtag expert.',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 200,
    });

    const hashtagText = completion.choices[0].message.content || '';
    const hashtags = hashtagText
      .split('\n')
      .filter((tag) => tag.trim().startsWith('#'))
      .map((tag) => tag.trim());

    return hashtags.slice(0, count);
  } catch (error) {
    console.error('Error generating hashtags:', error);
    return [];
  }
}

/**
 * Generate image description/prompt for AI image generation
 */
export async function generateImagePrompt(content: string): Promise<string> {
  const prompt = `Based on this social media content, generate a detailed image description that would work well with AI image generators like DALL-E or Midjourney:

Content: "${content}"

Provide only the image description, optimized for visual appeal and brand consistency.`;

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      messages: [
        {
          role: 'system',
          content: 'You are an expert at creating prompts for AI image generation.',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 200,
    });

    return completion.choices[0].message.content || '';
  } catch (error) {
    console.error('Error generating image prompt:', error);
    return '';
  }
}

// Helper functions

function buildContentPrompt(params: any): string {
  const {
    topic,
    businessType,
    targetAudience,
    platform,
    tone,
    contentType,
    charLimit,
    includeHashtags,
    includeEmojis,
    includeCallToAction,
    brandVoice,
    keywords,
  } = params;

  let prompt = `Create an engaging ${contentType} for ${platform} about "${topic}" for a ${businessType} business targeting ${targetAudience}.\n\n`;

  prompt += `Requirements:\n`;
  prompt += `- Tone: ${tone}\n`;
  prompt += `- Maximum length: ${charLimit} characters\n`;
  if (brandVoice) prompt += `- Brand voice: ${brandVoice}\n`;
  if (keywords.length > 0) prompt += `- Include these keywords: ${keywords.join(', ')}\n`;
  if (includeEmojis) prompt += `- Include relevant emojis\n`;
  if (includeHashtags) prompt += `- Include 3-5 relevant hashtags\n`;
  if (includeCallToAction) prompt += `- Include a clear call-to-action\n`;

  prompt += `\nPlatform-specific tips:\n`;
  switch (platform) {
    case 'twitter':
      prompt += `- Be concise and punchy\n- Use trending hashtags\n- Encourage retweets\n`;
      break;
    case 'linkedin':
      prompt += `- Be professional and insightful\n- Share valuable industry knowledge\n- Encourage engagement\n`;
      break;
    case 'instagram':
      prompt += `- Be visual and lifestyle-focused\n- Use storytelling\n- Include emoji variety\n`;
      break;
    case 'facebook':
      prompt += `- Be conversational and community-focused\n- Encourage discussion\n- Be authentic\n`;
      break;
    case 'tiktok':
      prompt += `- Be trendy and entertaining\n- Use popular formats\n- Be authentic and relatable\n`;
      break;
  }

  prompt += `\nProvide the content in this format:
[MAIN CONTENT]
Your engaging post content here

[HASHTAGS]
#hashtag1 #hashtag2 #hashtag3

[IMAGE SUGGESTION]
Brief description of ideal accompanying image

[BEST TIME]
Recommended posting time and reason`;

  return prompt;
}

function parseAIResponse(response: string, platform: string): GeneratedContent {
  const sections = {
    mainContent: '',
    hashtags: [] as string[],
    suggestedImages: [] as string[],
    bestTimeToPost: '',
  };

  // Extract main content
  const mainContentMatch = response.match(/\[MAIN CONTENT\]([\s\S]*?)(?:\[|$)/);
  if (mainContentMatch) {
    sections.mainContent = mainContentMatch[1].trim();
  } else {
    // If no sections found, use the whole response
    sections.mainContent = response.trim();
  }

  // Extract hashtags
  const hashtagsMatch = response.match(/\[HASHTAGS\]([\s\S]*?)(?:\[|$)/);
  if (hashtagsMatch) {
    const hashtagText = hashtagsMatch[1];
    sections.hashtags = hashtagText
      .split(/[\s\n]+/)
      .filter((tag) => tag.startsWith('#'))
      .map((tag) => tag.trim());
  }

  // Extract hashtags from main content if not found in dedicated section
  if (sections.hashtags.length === 0) {
    const hashtagMatches = sections.mainContent.match(/#\w+/g);
    if (hashtagMatches) {
      sections.hashtags = hashtagMatches;
    }
  }

  // Extract image suggestions
  const imageSuggestionMatch = response.match(/\[IMAGE SUGGESTION\]([\s\S]*?)(?:\[|$)/);
  if (imageSuggestionMatch) {
    sections.suggestedImages = [imageSuggestionMatch[1].trim()];
  }

  // Extract best time to post
  const bestTimeMatch = response.match(/\[BEST TIME\]([\s\S]*?)(?:\[|$)/);
  if (bestTimeMatch) {
    sections.bestTimeToPost = bestTimeMatch[1].trim();
  }

  return {
    mainContent: sections.mainContent,
    variations: [],
    hashtags: sections.hashtags,
    suggestedImages: sections.suggestedImages,
    bestTimeToPost: sections.bestTimeToPost,
    estimatedEngagement: calculateEstimatedEngagement(sections.mainContent, platform),
  };
}

function analyzeSentiment(content: string): 'positive' | 'neutral' | 'negative' {
  // Simple sentiment analysis based on keywords
  const positiveWords = ['great', 'amazing', 'excellent', 'love', 'best', 'wonderful', '❤️', '🎉', '✨'];
  const negativeWords = ['bad', 'worst', 'hate', 'terrible', 'awful', 'disappointing'];

  let score = 0;
  const lowerContent = content.toLowerCase();

  positiveWords.forEach((word) => {
    if (lowerContent.includes(word)) score += 1;
  });

  negativeWords.forEach((word) => {
    if (lowerContent.includes(word)) score -= 1;
  });

  if (score > 0) return 'positive';
  if (score < 0) return 'negative';
  return 'neutral';
}

function calculateEstimatedEngagement(content: string, platform: string): string {
  // Simple engagement estimation based on content characteristics
  let score = 0;

  // Check for emojis
  if (/[\u{1F600}-\u{1F64F}]/u.test(content)) score += 10;

  // Check for hashtags
  if (/#\w+/.test(content)) score += 15;

  // Check for questions
  if (/\?/.test(content)) score += 10;

  // Check for call-to-action words
  const ctaWords = ['click', 'visit', 'learn', 'discover', 'join', 'follow', 'share'];
  if (ctaWords.some((word) => content.toLowerCase().includes(word))) score += 15;

  // Platform-specific modifiers
  const platformMultiplier = {
    instagram: 1.2,
    tiktok: 1.3,
    twitter: 1.0,
    facebook: 0.9,
    linkedin: 0.8,
  };

  score *= platformMultiplier[platform as keyof typeof platformMultiplier] || 1;

  if (score >= 40) return 'High (4-6% engagement rate)';
  if (score >= 25) return 'Medium (2-4% engagement rate)';
  return 'Low (1-2% engagement rate)';
}
