import axios from 'axios';

export interface LinkedInCredentials {
  accessToken: string;
  personUrn?: string; // LinkedIn person URN
  organizationUrn?: string; // If posting as company
}

export interface LinkedInPost {
  id: string;
  created: number;
  text: string;
  totalSocialActivityCounts: {
    numLikes: number;
    numComments: number;
    numShares: number;
  };
}

export interface LinkedInPostParams {
  text: string;
  mediaUrl?: string;
  articleUrl?: string;
  visibility?: 'PUBLIC' | 'CONNECTIONS';
}

/**
 * LinkedIn API Service
 */
export class LinkedInService {
  private credentials: LinkedInCredentials;
  private baseUrl = 'https://api.linkedin.com/v2';

  constructor(credentials: LinkedInCredentials) {
    this.credentials = credentials;
  }

  /**
   * Create a post/share
   */
  async createPost(params: LinkedInPostParams): Promise<LinkedInPost> {
    try {
      const author = this.credentials.organizationUrn || this.credentials.personUrn;

      const shareData: any = {
        author: author,
        lifecycleState: 'PUBLISHED',
        specificContent: {
          'com.linkedin.ugc.ShareContent': {
            shareCommentary: {
              text: params.text,
            },
            shareMediaCategory: params.mediaUrl ? 'IMAGE' : params.articleUrl ? 'ARTICLE' : 'NONE',
          },
        },
        visibility: {
          'com.linkedin.ugc.MemberNetworkVisibility':
            params.visibility || 'PUBLIC',
        },
      };

      // Add media if provided
      if (params.mediaUrl) {
        shareData.specificContent['com.linkedin.ugc.ShareContent'].media = [
          {
            status: 'READY',
            media: params.mediaUrl,
          },
        ];
      }

      // Add article if provided
      if (params.articleUrl) {
        shareData.specificContent['com.linkedin.ugc.ShareContent'].media = [
          {
            status: 'READY',
            originalUrl: params.articleUrl,
          },
        ];
      }

      const response = await axios.post(`${this.baseUrl}/ugcPosts`, shareData, {
        headers: {
          Authorization: `Bearer ${this.credentials.accessToken}`,
          'Content-Type': 'application/json',
          'X-Restli-Protocol-Version': '2.0.0',
        },
      });

      return response.data;
    } catch (error: any) {
      console.error('Error creating LinkedIn post:', error.response?.data || error);
      throw new Error('Failed to create LinkedIn post');
    }
  }

  /**
   * Delete a post
   */
  async deletePost(postId: string): Promise<boolean> {
    try {
      await axios.delete(`${this.baseUrl}/ugcPosts/${postId}`, {
        headers: {
          Authorization: `Bearer ${this.credentials.accessToken}`,
          'X-Restli-Protocol-Version': '2.0.0',
        },
      });

      return true;
    } catch (error) {
      console.error('Error deleting LinkedIn post:', error);
      return false;
    }
  }

  /**
   * Get post analytics
   */
  async getPostAnalytics(postId: string): Promise<{
    likes: number;
    comments: number;
    shares: number;
    clicks: number;
    impressions: number;
  }> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/socialActions/${postId}/statistics`,
        {
          headers: {
            Authorization: `Bearer ${this.credentials.accessToken}`,
          },
        }
      );

      const stats = response.data;

      return {
        likes: stats.numLikes || 0,
        comments: stats.numComments || 0,
        shares: stats.numShares || 0,
        clicks: stats.clickCount || 0,
        impressions: stats.impressionCount || 0,
      };
    } catch (error) {
      console.error('Error getting post analytics:', error);
      throw new Error('Failed to get post analytics');
    }
  }

  /**
   * Get user profile
   */
  async getProfile(): Promise<{
    id: string;
    firstName: string;
    lastName: string;
    headline: string;
  }> {
    try {
      const response = await axios.get(`${this.baseUrl}/me`, {
        headers: {
          Authorization: `Bearer ${this.credentials.accessToken}`,
        },
      });

      return {
        id: response.data.id,
        firstName: response.data.localizedFirstName,
        lastName: response.data.localizedLastName,
        headline: response.data.headline,
      };
    } catch (error) {
      console.error('Error getting LinkedIn profile:', error);
      throw new Error('Failed to get LinkedIn profile');
    }
  }

  /**
   * Get organization analytics
   */
  async getOrganizationAnalytics(organizationId: string): Promise<{
    followers: number;
    engagement: number;
  }> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/organizationalEntityFollowerStatistics`,
        {
          params: {
            q: 'organizationalEntity',
            organizationalEntity: `urn:li:organization:${organizationId}`,
          },
          headers: {
            Authorization: `Bearer ${this.credentials.accessToken}`,
          },
        }
      );

      const stats = response.data.elements[0];

      return {
        followers: stats.followerCounts?.organicFollowerCount || 0,
        engagement: stats.followerCounts?.paidFollowerCount || 0,
      };
    } catch (error) {
      console.error('Error getting organization analytics:', error);
      throw new Error('Failed to get organization analytics');
    }
  }

  /**
   * Upload image
   */
  async uploadImage(imageUrl: string): Promise<string> {
    try {
      // Step 1: Register upload
      const registerResponse = await axios.post(
        `${this.baseUrl}/assets?action=registerUpload`,
        {
          registerUploadRequest: {
            recipes: ['urn:li:digitalmediaRecipe:feedshare-image'],
            owner: this.credentials.personUrn || this.credentials.organizationUrn,
            serviceRelationships: [
              {
                relationshipType: 'OWNER',
                identifier: 'urn:li:userGeneratedContent',
              },
            ],
          },
        },
        {
          headers: {
            Authorization: `Bearer ${this.credentials.accessToken}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const uploadUrl = registerResponse.data.value.uploadMechanism[
        'com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest'
      ].uploadUrl;
      const asset = registerResponse.data.value.asset;

      // Step 2: Download image
      const imageResponse = await axios.get(imageUrl, {
        responseType: 'arraybuffer',
      });

      // Step 3: Upload image
      await axios.put(uploadUrl, imageResponse.data, {
        headers: {
          Authorization: `Bearer ${this.credentials.accessToken}`,
          'Content-Type': 'image/png',
        },
      });

      return asset;
    } catch (error) {
      console.error('Error uploading image to LinkedIn:', error);
      throw new Error('Failed to upload image');
    }
  }
}

export default LinkedInService;
