import axios from 'axios';

export interface FacebookCredentials {
  accessToken: string;
  pageId?: string; // For posting to a page
}

export interface FacebookPost {
  id: string;
  message: string;
  created_time: string;
  likes?: number;
  comments?: number;
  shares?: number;
}

export interface FacebookPostParams {
  message: string;
  link?: string;
  imageUrl?: string;
  videoUrl?: string;
  scheduled_publish_time?: number; // Unix timestamp
}

/**
 * Facebook API Service
 * Also handles Instagram Business Account posts through Graph API
 */
export class FacebookService {
  private credentials: FacebookCredentials;
  private baseUrl = 'https://graph.facebook.com/v18.0';

  constructor(credentials: FacebookCredentials) {
    this.credentials = credentials;
  }

  /**
   * Create a post on Facebook page
   */
  async createPost(params: FacebookPostParams): Promise<FacebookPost> {
    try {
      const pageId = this.credentials.pageId;
      if (!pageId) {
        throw new Error('Page ID is required for posting');
      }

      const postData: any = {
        message: params.message,
        access_token: this.credentials.accessToken,
      };

      // Add link if provided
      if (params.link) {
        postData.link = params.link;
      }

      // Schedule post if time provided
      if (params.scheduled_publish_time) {
        postData.published = false;
        postData.scheduled_publish_time = params.scheduled_publish_time;
      }

      let endpoint = `${this.baseUrl}/${pageId}/feed`;

      // If image is provided, use photos endpoint
      if (params.imageUrl) {
        endpoint = `${this.baseUrl}/${pageId}/photos`;
        postData.url = params.imageUrl;
        delete postData.message; // Message becomes caption
        postData.caption = params.message;
      }

      // If video is provided, use videos endpoint
      if (params.videoUrl) {
        endpoint = `${this.baseUrl}/${pageId}/videos`;
        postData.file_url = params.videoUrl;
        postData.description = params.message;
        delete postData.message;
      }

      const response = await axios.post(endpoint, postData);

      return {
        id: response.data.id,
        message: params.message,
        created_time: new Date().toISOString(),
      };
    } catch (error: any) {
      console.error('Error creating Facebook post:', error.response?.data || error);
      throw new Error('Failed to create Facebook post');
    }
  }

  /**
   * Delete a post
   */
  async deletePost(postId: string): Promise<boolean> {
    try {
      await axios.delete(`${this.baseUrl}/${postId}`, {
        params: {
          access_token: this.credentials.accessToken,
        },
      });

      return true;
    } catch (error) {
      console.error('Error deleting Facebook post:', error);
      return false;
    }
  }

  /**
   * Get post insights/analytics
   */
  async getPostInsights(postId: string): Promise<{
    likes: number;
    comments: number;
    shares: number;
    reach: number;
    impressions: number;
    engagement: number;
  }> {
    try {
      // Get engagement metrics
      const response = await axios.get(`${this.baseUrl}/${postId}`, {
        params: {
          fields:
            'likes.summary(true),comments.summary(true),shares,insights.metric(post_impressions,post_reach,post_engaged_users)',
          access_token: this.credentials.accessToken,
        },
      });

      const data = response.data;
      const insights = data.insights?.data || [];

      const impressions =
        insights.find((i: any) => i.name === 'post_impressions')?.values[0]?.value || 0;
      const reach =
        insights.find((i: any) => i.name === 'post_reach')?.values[0]?.value || 0;
      const engagement =
        insights.find((i: any) => i.name === 'post_engaged_users')?.values[0]?.value || 0;

      return {
        likes: data.likes?.summary?.total_count || 0,
        comments: data.comments?.summary?.total_count || 0,
        shares: data.shares?.count || 0,
        reach,
        impressions,
        engagement,
      };
    } catch (error) {
      console.error('Error getting post insights:', error);
      throw new Error('Failed to get post insights');
    }
  }

  /**
   * Get page analytics
   */
  async getPageAnalytics(days: number = 7): Promise<{
    followers: number;
    engagement: number;
    reach: number;
    impressions: number;
  }> {
    try {
      const pageId = this.credentials.pageId;
      if (!pageId) {
        throw new Error('Page ID is required');
      }

      const since = Math.floor(Date.now() / 1000) - days * 24 * 60 * 60;
      const until = Math.floor(Date.now() / 1000);

      const response = await axios.get(`${this.baseUrl}/${pageId}/insights`, {
        params: {
          metric: 'page_fans,page_engaged_users,page_impressions,page_post_engagements',
          since,
          until,
          access_token: this.credentials.accessToken,
        },
      });

      const insights = response.data.data;

      return {
        followers:
          insights.find((i: any) => i.name === 'page_fans')?.values[0]?.value || 0,
        engagement:
          insights.find((i: any) => i.name === 'page_engaged_users')?.values[0]?.value || 0,
        reach: 0,
        impressions:
          insights.find((i: any) => i.name === 'page_impressions')?.values[0]?.value || 0,
      };
    } catch (error) {
      console.error('Error getting page analytics:', error);
      throw new Error('Failed to get page analytics');
    }
  }

  /**
   * Get page posts
   */
  async getPagePosts(limit: number = 25): Promise<FacebookPost[]> {
    try {
      const pageId = this.credentials.pageId;
      if (!pageId) {
        throw new Error('Page ID is required');
      }

      const response = await axios.get(`${this.baseUrl}/${pageId}/posts`, {
        params: {
          fields: 'id,message,created_time,likes.summary(true),comments.summary(true),shares',
          limit,
          access_token: this.credentials.accessToken,
        },
      });

      return response.data.data.map((post: any) => ({
        id: post.id,
        message: post.message,
        created_time: post.created_time,
        likes: post.likes?.summary?.total_count || 0,
        comments: post.comments?.summary?.total_count || 0,
        shares: post.shares?.count || 0,
      }));
    } catch (error) {
      console.error('Error getting page posts:', error);
      throw new Error('Failed to get page posts');
    }
  }
}

/**
 * Instagram Business API Service
 * Requires Facebook Page connected to Instagram Business Account
 */
export class InstagramService {
  private credentials: FacebookCredentials;
  private baseUrl = 'https://graph.facebook.com/v18.0';
  private instagramAccountId?: string;

  constructor(credentials: FacebookCredentials, instagramAccountId?: string) {
    this.credentials = credentials;
    this.instagramAccountId = instagramAccountId;
  }

  /**
   * Create Instagram post (image or carousel)
   */
  async createPost(params: {
    imageUrl: string;
    caption: string;
    locationId?: string;
  }): Promise<{ id: string }> {
    try {
      if (!this.instagramAccountId) {
        throw new Error('Instagram account ID is required');
      }

      // Step 1: Create media container
      const containerResponse = await axios.post(
        `${this.baseUrl}/${this.instagramAccountId}/media`,
        {
          image_url: params.imageUrl,
          caption: params.caption,
          location_id: params.locationId,
          access_token: this.credentials.accessToken,
        }
      );

      const creationId = containerResponse.data.id;

      // Step 2: Publish the container
      const publishResponse = await axios.post(
        `${this.baseUrl}/${this.instagramAccountId}/media_publish`,
        {
          creation_id: creationId,
          access_token: this.credentials.accessToken,
        }
      );

      return {
        id: publishResponse.data.id,
      };
    } catch (error: any) {
      console.error('Error creating Instagram post:', error.response?.data || error);
      throw new Error('Failed to create Instagram post');
    }
  }

  /**
   * Get Instagram post insights
   */
  async getPostInsights(postId: string): Promise<{
    likes: number;
    comments: number;
    reach: number;
    impressions: number;
    engagement: number;
    saves: number;
  }> {
    try {
      const response = await axios.get(`${this.baseUrl}/${postId}/insights`, {
        params: {
          metric: 'engagement,impressions,reach,saved',
          access_token: this.credentials.accessToken,
        },
      });

      const insights = response.data.data;

      return {
        likes: 0, // Requires separate call
        comments: 0, // Requires separate call
        reach: insights.find((i: any) => i.name === 'reach')?.values[0]?.value || 0,
        impressions:
          insights.find((i: any) => i.name === 'impressions')?.values[0]?.value || 0,
        engagement:
          insights.find((i: any) => i.name === 'engagement')?.values[0]?.value || 0,
        saves: insights.find((i: any) => i.name === 'saved')?.values[0]?.value || 0,
      };
    } catch (error) {
      console.error('Error getting Instagram post insights:', error);
      throw new Error('Failed to get post insights');
    }
  }

  /**
   * Get account insights
   */
  async getAccountInsights(period: 'day' | 'week' | 'month' = 'day'): Promise<{
    followers: number;
    reach: number;
    impressions: number;
    profileViews: number;
  }> {
    try {
      if (!this.instagramAccountId) {
        throw new Error('Instagram account ID is required');
      }

      const response = await axios.get(
        `${this.baseUrl}/${this.instagramAccountId}/insights`,
        {
          params: {
            metric: 'follower_count,reach,impressions,profile_views',
            period,
            access_token: this.credentials.accessToken,
          },
        }
      );

      const insights = response.data.data;

      return {
        followers:
          insights.find((i: any) => i.name === 'follower_count')?.values[0]?.value || 0,
        reach: insights.find((i: any) => i.name === 'reach')?.values[0]?.value || 0,
        impressions:
          insights.find((i: any) => i.name === 'impressions')?.values[0]?.value || 0,
        profileViews:
          insights.find((i: any) => i.name === 'profile_views')?.values[0]?.value || 0,
      };
    } catch (error) {
      console.error('Error getting Instagram account insights:', error);
      throw new Error('Failed to get account insights');
    }
  }
}
