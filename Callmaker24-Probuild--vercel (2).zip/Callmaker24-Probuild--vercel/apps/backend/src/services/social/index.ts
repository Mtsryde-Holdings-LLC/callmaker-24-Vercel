export { TwitterService } from './twitter';
export type { TwitterCredentials, Tweet, TwitterPostParams } from './twitter';

export { LinkedInService } from './linkedin';
export type { LinkedInCredentials, LinkedInPost, LinkedInPostParams } from './linkedin';

export { FacebookService, InstagramService } from './facebook';
export type { FacebookCredentials, FacebookPost, FacebookPostParams } from './facebook';

/**
 * Social Media Platform Manager
 * Unified interface for posting to multiple platforms
 */
import { TwitterService } from './twitter';
import { LinkedInService } from './linkedin';
import { FacebookService, InstagramService } from './facebook';

export interface SocialMediaCredentials {
  twitter?: {
    apiKey: string;
    apiSecret: string;
    accessToken: string;
    accessSecret: string;
    bearerToken?: string;
  };
  linkedin?: {
    accessToken: string;
    personUrn?: string;
    organizationUrn?: string;
  };
  facebook?: {
    accessToken: string;
    pageId?: string;
  };
  instagram?: {
    accessToken: string;
    accountId?: string;
  };
}

export interface CrossPlatformPostParams {
  content: string;
  platforms: Array<'twitter' | 'linkedin' | 'facebook' | 'instagram'>;
  mediaUrl?: string;
  link?: string;
}

export class SocialMediaManager {
  private twitter?: TwitterService;
  private linkedin?: LinkedInService;
  private facebook?: FacebookService;
  private instagram?: InstagramService;

  constructor(credentials: SocialMediaCredentials) {
    if (credentials.twitter) {
      this.twitter = new TwitterService(credentials.twitter);
    }

    if (credentials.linkedin) {
      this.linkedin = new LinkedInService(credentials.linkedin);
    }

    if (credentials.facebook) {
      this.facebook = new FacebookService(credentials.facebook);
    }

    if (credentials.instagram && credentials.instagram.accountId) {
      this.instagram = new InstagramService(
        { accessToken: credentials.instagram.accessToken },
        credentials.instagram.accountId
      );
    }
  }

  /**
   * Post to multiple platforms simultaneously
   */
  async postToMultiplePlatforms(params: CrossPlatformPostParams): Promise<{
    results: Array<{
      platform: string;
      success: boolean;
      postId?: string;
      error?: string;
    }>;
  }> {
    const results = await Promise.allSettled(
      params.platforms.map(async (platform) => {
        try {
          let postId: string | undefined;

          switch (platform) {
            case 'twitter':
              if (this.twitter) {
                const tweet = await this.twitter.postTweet({ text: params.content });
                postId = tweet.id;
              }
              break;

            case 'linkedin':
              if (this.linkedin) {
                const post = await this.linkedin.createPost({
                  text: params.content,
                  articleUrl: params.link,
                });
                postId = post.id;
              }
              break;

            case 'facebook':
              if (this.facebook) {
                const post = await this.facebook.createPost({
                  message: params.content,
                  link: params.link,
                  imageUrl: params.mediaUrl,
                });
                postId = post.id;
              }
              break;

            case 'instagram':
              if (this.instagram && params.mediaUrl) {
                const post = await this.instagram.createPost({
                  imageUrl: params.mediaUrl,
                  caption: params.content,
                });
                postId = post.id;
              }
              break;
          }

          return {
            platform,
            success: true,
            postId,
          };
        } catch (error: any) {
          return {
            platform,
            success: false,
            error: error.message,
          };
        }
      })
    );

    return {
      results: results.map((result) => {
        if (result.status === 'fulfilled') {
          return result.value;
        } else {
          return {
            platform: 'unknown',
            success: false,
            error: result.reason?.message || 'Unknown error',
          };
        }
      }),
    };
  }

  /**
   * Get analytics from all connected platforms
   */
  async getAllPlatformAnalytics(): Promise<{
    twitter?: any;
    linkedin?: any;
    facebook?: any;
    instagram?: any;
  }> {
    const analytics: any = {};

    try {
      if (this.twitter) {
        // Twitter analytics would go here
        analytics.twitter = {};
      }

      if (this.linkedin) {
        // LinkedIn analytics would go here
        analytics.linkedin = {};
      }

      if (this.facebook) {
        analytics.facebook = await this.facebook.getPageAnalytics(7);
      }

      if (this.instagram) {
        analytics.instagram = await this.instagram.getAccountInsights('week');
      }
    } catch (error) {
      console.error('Error getting platform analytics:', error);
    }

    return analytics;
  }
}
