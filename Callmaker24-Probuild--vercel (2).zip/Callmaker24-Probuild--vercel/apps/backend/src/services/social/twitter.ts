import axios from 'axios';

export interface TwitterCredentials {
  apiKey: string;
  apiSecret: string;
  accessToken: string;
  accessSecret: string;
  bearerToken?: string;
}

export interface Tweet {
  id: string;
  text: string;
  created_at: string;
  public_metrics: {
    retweet_count: number;
    reply_count: number;
    like_count: number;
    quote_count: number;
    impression_count?: number;
  };
}

export interface TwitterPostParams {
  text: string;
  media_ids?: string[];
  reply_settings?: 'everyone' | 'mentionedUsers' | 'following';
}

/**
 * Twitter/X API Service
 */
export class TwitterService {
  private credentials: TwitterCredentials;
  private baseUrl = 'https://api.twitter.com/2';

  constructor(credentials: TwitterCredentials) {
    this.credentials = credentials;
  }

  /**
   * Post a tweet
   */
  async postTweet(params: TwitterPostParams): Promise<Tweet> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/tweets`,
        {
          text: params.text,
          media: params.media_ids ? { media_ids: params.media_ids } : undefined,
          reply_settings: params.reply_settings,
        },
        {
          headers: {
            Authorization: `Bearer ${this.credentials.bearerToken}`,
            'Content-Type': 'application/json',
          },
        }
      );

      return response.data.data;
    } catch (error: any) {
      console.error('Error posting tweet:', error.response?.data || error);
      throw new Error('Failed to post tweet');
    }
  }

  /**
   * Delete a tweet
   */
  async deleteTweet(tweetId: string): Promise<boolean> {
    try {
      await axios.delete(`${this.baseUrl}/tweets/${tweetId}`, {
        headers: {
          Authorization: `Bearer ${this.credentials.bearerToken}`,
        },
      });

      return true;
    } catch (error) {
      console.error('Error deleting tweet:', error);
      return false;
    }
  }

  /**
   * Get tweet metrics
   */
  async getTweetMetrics(tweetId: string): Promise<Tweet> {
    try {
      const response = await axios.get(`${this.baseUrl}/tweets/${tweetId}`, {
        params: {
          'tweet.fields': 'public_metrics,created_at',
        },
        headers: {
          Authorization: `Bearer ${this.credentials.bearerToken}`,
        },
      });

      return response.data.data;
    } catch (error) {
      console.error('Error getting tweet metrics:', error);
      throw new Error('Failed to get tweet metrics');
    }
  }

  /**
   * Get user tweets
   */
  async getUserTweets(userId: string, maxResults: number = 10): Promise<Tweet[]> {
    try {
      const response = await axios.get(`${this.baseUrl}/users/${userId}/tweets`, {
        params: {
          max_results: maxResults,
          'tweet.fields': 'public_metrics,created_at',
        },
        headers: {
          Authorization: `Bearer ${this.credentials.bearerToken}`,
        },
      });

      return response.data.data || [];
    } catch (error) {
      console.error('Error getting user tweets:', error);
      throw new Error('Failed to get user tweets');
    }
  }

  /**
   * Upload media
   */
  async uploadMedia(mediaUrl: string): Promise<string> {
    try {
      // Download media first (currently unused but will be needed for real implementation)
      await axios.get(mediaUrl, {
        responseType: 'arraybuffer',
      });

      // Upload to Twitter (simplified - actual implementation needs OAuth 1.0a)
      // This is a placeholder - real implementation requires media upload endpoint
      console.log('Media upload not fully implemented - requires OAuth 1.0a');

      return 'media_id_placeholder';
    } catch (error) {
      console.error('Error uploading media:', error);
      throw new Error('Failed to upload media');
    }
  }

  /**
   * Get account analytics
   */
  async getAccountAnalytics(userId: string, _days: number = 7): Promise<{
    followers: number;
    following: number;
    tweetCount: number;
    avgEngagement: number;
  }> {
    try {
      // TODO: Use days parameter to calculate metrics over time period
      const response = await axios.get(`${this.baseUrl}/users/${userId}`, {
        params: {
          'user.fields': 'public_metrics',
        },
        headers: {
          Authorization: `Bearer ${this.credentials.bearerToken}`,
        },
      });

      const metrics = response.data.data.public_metrics;

      return {
        followers: metrics.followers_count,
        following: metrics.following_count,
        tweetCount: metrics.tweet_count,
        avgEngagement: 0, // Calculate from recent tweets
      };
    } catch (error) {
      console.error('Error getting account analytics:', error);
      throw new Error('Failed to get account analytics');
    }
  }
}

export default TwitterService;
