import * as cdk from 'aws-cdk-lib';
import * as ses from 'aws-cdk-lib/aws-ses';
import * as sns from 'aws-cdk-lib/aws-sns';
import { Construct } from 'constructs';

interface MessagingStackProps extends cdk.StackProps {
  projectName: string;
  environment: string;
}

export class MessagingStack extends cdk.Stack {
  public readonly configurationSet: ses.CfnConfigurationSet;
  public readonly smsTopic: sns.Topic;

  constructor(scope: Construct, id: string, props: MessagingStackProps) {
    super(scope, id, props);

    // ============================================
    // Amazon SES Configuration
    // ============================================

    // Create SES configuration set
    this.configurationSet = new ses.CfnConfigurationSet(this, 'SESConfigSet', {
      name: `${props.projectName}-${props.environment}`,
    });

    // ============================================
    // Amazon SNS for SMS
    // ============================================

    // Create SNS topic for SMS
    this.smsTopic = new sns.Topic(this, 'SMSTopic', {
      topicName: `${props.projectName}-SMS-${props.environment}`,
      displayName: 'Marketing Platform SMS',
    });

    // ============================================
    // Outputs
    // ============================================

    new cdk.CfnOutput(this, 'SESConfigurationSetName', {
      value: this.configurationSet.name!,
      description: 'SES configuration set name',
      exportName: `${props.projectName}-SESConfigSet-${props.environment}`,
    });

    new cdk.CfnOutput(this, 'SMSTopicArn', {
      value: this.smsTopic.topicArn,
      description: 'SNS topic ARN for SMS',
    });
  }
}
