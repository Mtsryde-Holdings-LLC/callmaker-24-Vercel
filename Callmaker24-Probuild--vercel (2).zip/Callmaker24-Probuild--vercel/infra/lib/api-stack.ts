import * as cdk from 'aws-cdk-lib';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as apigatewayv2 from 'aws-cdk-lib/aws-apigatewayv2';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';

interface ApiStackProps extends cdk.StackProps {
  projectName: string;
  environment: string;
  userPool: cognito.UserPool;
  customerTable: dynamodb.Table;
  campaignTable: dynamodb.Table;
  messageTable: dynamodb.Table;
  conversationTable: dynamodb.Table;
  assetBucket: s3.Bucket;
}

export class ApiStack extends cdk.Stack {
  public readonly api: apigateway.RestApi;

  constructor(scope: Construct, id: string, props: ApiStackProps) {
    super(scope, id, props);

    // ============================================
    // API Gateway
    // ============================================

    this.api = new apigateway.RestApi(this, 'Api', {
      restApiName: `${props.projectName}-${props.environment}`,
      description: `Marketing Platform API - ${props.environment}`,
      defaultCorsPreflightOptions: {
        // Security: CORS restricted to specific origins in production to prevent CSRF attacks
        // In development, ALL_ORIGINS is used for local testing convenience
        allowOrigins: props.environment === 'production' 
          ? [
              // TODO: Replace with actual production domains
              'https://yourdomain.com',
              'https://www.yourdomain.com',
            ]
          : apigateway.Cors.ALL_ORIGINS,
        allowMethods: apigateway.Cors.ALL_METHODS,
        allowHeaders: [
          'Content-Type',
          'X-Amz-Date',
          'Authorization',
          'X-Api-Key',
          'X-Tenant-ID',
        ],
      },
      deployOptions: {
        stageName: props.environment,
        metricsEnabled: true,
        loggingLevel: apigateway.MethodLoggingLevel.INFO,
        dataTraceEnabled: props.environment !== 'production',
        throttlingRateLimit: 1000,
        throttlingBurstLimit: 2000,
      },
    });

    // Create Cognito authorizer
    const authorizer = new apigateway.CognitoUserPoolsAuthorizer(this, 'Authorizer', {
      cognitoUserPools: [props.userPool],
    });

    // ============================================
    // Lambda Functions
    // ============================================

    // Create Lambda execution role
    const lambdaRole = new iam.Role(this, 'LambdaExecutionRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AWSXRayDaemonWriteAccess'),
      ],
    });

    // Grant DynamoDB access
    props.customerTable.grantReadWriteData(lambdaRole);
    props.campaignTable.grantReadWriteData(lambdaRole);
    props.messageTable.grantReadWriteData(lambdaRole);
    props.conversationTable.grantReadWriteData(lambdaRole);

    // Grant S3 access
    props.assetBucket.grantReadWrite(lambdaRole);

    // Environment variables for Lambda functions
    const lambdaEnv = {
      DYNAMODB_CUSTOMERS_TABLE: props.customerTable.tableName,
      DYNAMODB_CAMPAIGNS_TABLE: props.campaignTable.tableName,
      DYNAMODB_MESSAGES_TABLE: props.messageTable.tableName,
      DYNAMODB_CONVERSATIONS_TABLE: props.conversationTable.tableName,
      S3_BUCKET_NAME: props.assetBucket.bucketName,
      AWS_NODEJS_CONNECTION_REUSE_ENABLED: '1',
    };

    // ============================================
    // Customer Functions
    // ============================================

    const createCustomerFn = new lambda.Function(this, 'CreateCustomerFn', {
      runtime: lambda.Runtime.NODEJS_18_X,
      handler: 'create.handler',
      code: lambda.Code.fromAsset('../apps/backend/dist/functions/customers'),
      role: lambdaRole,
      environment: lambdaEnv,
      timeout: cdk.Duration.seconds(30),
      memorySize: 512,
      tracing: lambda.Tracing.ACTIVE,
    });

    // API Gateway integration
    const customersResource = this.api.root.addResource('customers');

    customersResource.addMethod(
      'POST',
      new apigateway.LambdaIntegration(createCustomerFn),
      {
        authorizer,
        authorizationType: apigateway.AuthorizationType.COGNITO,
      }
    );

    // ============================================
    // Campaign Functions
    // ============================================

    const createCampaignFn = new lambda.Function(this, 'CreateCampaignFn', {
      runtime: lambda.Runtime.NODEJS_18_X,
      handler: 'create.handler',
      code: lambda.Code.fromAsset('../apps/backend/dist/functions/campaigns'),
      role: lambdaRole,
      environment: lambdaEnv,
      timeout: cdk.Duration.seconds(30),
      memorySize: 512,
      tracing: lambda.Tracing.ACTIVE,
    });

    const listCampaignsFn = new lambda.Function(this, 'ListCampaignsFn', {
      runtime: lambda.Runtime.NODEJS_18_X,
      handler: 'list.handler',
      code: lambda.Code.fromAsset('../apps/backend/dist/functions/campaigns'),
      role: lambdaRole,
      environment: lambdaEnv,
      timeout: cdk.Duration.seconds(30),
      memorySize: 512,
      tracing: lambda.Tracing.ACTIVE,
    });

    const updateCampaignFn = new lambda.Function(this, 'UpdateCampaignFn', {
      runtime: lambda.Runtime.NODEJS_18_X,
      handler: 'update.handler',
      code: lambda.Code.fromAsset('../apps/backend/dist/functions/campaigns'),
      role: lambdaRole,
      environment: lambdaEnv,
      timeout: cdk.Duration.seconds(30),
      memorySize: 512,
      tracing: lambda.Tracing.ACTIVE,
    });

    const deleteCampaignFn = new lambda.Function(this, 'DeleteCampaignFn', {
      runtime: lambda.Runtime.NODEJS_18_X,
      handler: 'delete.handler',
      code: lambda.Code.fromAsset('../apps/backend/dist/functions/campaigns'),
      role: lambdaRole,
      environment: lambdaEnv,
      timeout: cdk.Duration.seconds(30),
      memorySize: 512,
      tracing: lambda.Tracing.ACTIVE,
    });

    // Campaign API endpoints
    const campaignsResource = this.api.root.addResource('campaigns');
    
    campaignsResource.addMethod('POST', new apigateway.LambdaIntegration(createCampaignFn), {
      authorizer,
      authorizationType: apigateway.AuthorizationType.COGNITO,
    });
    
    campaignsResource.addMethod('GET', new apigateway.LambdaIntegration(listCampaignsFn), {
      authorizer,
      authorizationType: apigateway.AuthorizationType.COGNITO,
    });

    const campaignResource = campaignsResource.addResource('{id}');
    campaignResource.addMethod('PUT', new apigateway.LambdaIntegration(updateCampaignFn), {
      authorizer,
      authorizationType: apigateway.AuthorizationType.COGNITO,
    });
    
    campaignResource.addMethod('DELETE', new apigateway.LambdaIntegration(deleteCampaignFn), {
      authorizer,
      authorizationType: apigateway.AuthorizationType.COGNITO,
    });

    // Add more Lambda functions and endpoints here...
    // (Campaign functions, messaging functions, AI functions, etc.)

    // ============================================
    // WebSocket API for Chat
    // ============================================

    const webSocketApi = new apigatewayv2.CfnApi(this, 'WebSocketApi', {
      name: `${props.projectName}-ws-${props.environment}`,
      protocolType: 'WEBSOCKET',
      routeSelectionExpression: '$request.body.action',
    });

    // ============================================
    // Outputs
    // ============================================

    new cdk.CfnOutput(this, 'ApiUrl', {
      value: this.api.url,
      description: 'API Gateway URL',
      exportName: `${props.projectName}-ApiUrl-${props.environment}`,
    });

    new cdk.CfnOutput(this, 'ApiId', {
      value: this.api.restApiId,
      description: 'API Gateway ID',
    });

    new cdk.CfnOutput(this, 'WebSocketApiId', {
      value: webSocketApi.ref,
      description: 'WebSocket API ID',
    });
  }
}
