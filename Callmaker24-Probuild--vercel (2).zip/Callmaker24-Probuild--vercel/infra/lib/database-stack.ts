import * as cdk from 'aws-cdk-lib';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import { Construct } from 'constructs';

interface DatabaseStackProps extends cdk.StackProps {
  projectName: string;
  environment: string;
}

export class DatabaseStack extends cdk.Stack {
  public readonly customersTable: dynamodb.Table;
  public readonly campaignsTable: dynamodb.Table;
  public readonly messagesTable: dynamodb.Table;
  public readonly conversationsTable: dynamodb.Table;
  public readonly rdsInstance?: rds.DatabaseInstance;
  public readonly dbSecret?: secretsmanager.Secret;

  constructor(scope: Construct, id: string, props: DatabaseStackProps) {
    super(scope, id, props);

    // ============================================
    // DynamoDB Tables
    // ============================================

    // Customers Table
    this.customersTable = new dynamodb.Table(this, 'CustomersTable', {
      tableName: `${props.projectName}-customers-${props.environment}`,
      partitionKey: { name: 'id', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'tenantId', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      pointInTimeRecovery: props.environment === 'production',
      removalPolicy: props.environment === 'production'
        ? cdk.RemovalPolicy.RETAIN
        : cdk.RemovalPolicy.DESTROY,
    });

    // Add GSI for email lookup
    this.customersTable.addGlobalSecondaryIndex({
      indexName: 'EmailIndex',
      partitionKey: { name: 'email', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'tenantId', type: dynamodb.AttributeType.STRING },
    });

    // Campaigns Table
    this.campaignsTable = new dynamodb.Table(this, 'CampaignsTable', {
      tableName: `${props.projectName}-campaigns-${props.environment}`,
      partitionKey: { name: 'id', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'tenantId', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      pointInTimeRecovery: props.environment === 'production',
      stream: dynamodb.StreamViewType.NEW_AND_OLD_IMAGES,
      removalPolicy: props.environment === 'production'
        ? cdk.RemovalPolicy.RETAIN
        : cdk.RemovalPolicy.DESTROY,
    });

    // Add GSI for status queries
    this.campaignsTable.addGlobalSecondaryIndex({
      indexName: 'StatusIndex',
      partitionKey: { name: 'tenantId', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'status', type: dynamodb.AttributeType.STRING },
    });

    // Messages Table
    this.messagesTable = new dynamodb.Table(this, 'MessagesTable', {
      tableName: `${props.projectName}-messages-${props.environment}`,
      partitionKey: { name: 'id', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'campaignId', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      timeToLiveAttribute: 'ttl',
      removalPolicy: props.environment === 'production'
        ? cdk.RemovalPolicy.RETAIN
        : cdk.RemovalPolicy.DESTROY,
    });

    // Add GSI for customer messages
    this.messagesTable.addGlobalSecondaryIndex({
      indexName: 'CustomerIndex',
      partitionKey: { name: 'customerId', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'createdAt', type: dynamodb.AttributeType.STRING },
    });

    // Conversations Table
    this.conversationsTable = new dynamodb.Table(this, 'ConversationsTable', {
      tableName: `${props.projectName}-conversations-${props.environment}`,
      partitionKey: { name: 'id', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'tenantId', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      stream: dynamodb.StreamViewType.NEW_AND_OLD_IMAGES,
      removalPolicy: props.environment === 'production'
        ? cdk.RemovalPolicy.RETAIN
        : cdk.RemovalPolicy.DESTROY,
    });

    // Add GSI for status queries
    this.conversationsTable.addGlobalSecondaryIndex({
      indexName: 'StatusIndex',
      partitionKey: { name: 'tenantId', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'status', type: dynamodb.AttributeType.STRING },
    });

    // ============================================
    // RDS PostgreSQL for Analytics (Optional)
    // ============================================

    if (props.environment === 'production') {
      // Create VPC for RDS
      const vpc = new ec2.Vpc(this, 'VPC', {
        maxAzs: 2,
        natGateways: 1,
      });

      // Create database secret
      this.dbSecret = new secretsmanager.Secret(this, 'DBSecret', {
        secretName: `${props.projectName}-db-secret-${props.environment}`,
        generateSecretString: {
          secretStringTemplate: JSON.stringify({ username: 'admin' }),
          generateStringKey: 'password',
          excludePunctuation: true,
          includeSpace: false,
        },
      });

      // Create RDS instance
      this.rdsInstance = new rds.DatabaseInstance(this, 'Database', {
        engine: rds.DatabaseInstanceEngine.postgres({
          version: rds.PostgresEngineVersion.VER_15_4,
        }),
        instanceType: ec2.InstanceType.of(
          ec2.InstanceClass.T3,
          ec2.InstanceSize.SMALL
        ),
        vpc,
        vpcSubnets: {
          subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
        },
        credentials: rds.Credentials.fromSecret(this.dbSecret),
        databaseName: 'marketing_platform',
        allocatedStorage: 20,
        maxAllocatedStorage: 100,
        storageEncrypted: true,
        backupRetention: cdk.Duration.days(7),
        deleteAutomatedBackups: false,
        removalPolicy: cdk.RemovalPolicy.SNAPSHOT,
      });
    }

    // ============================================
    // Outputs
    // ============================================

    new cdk.CfnOutput(this, 'CustomersTableName', {
      value: this.customersTable.tableName,
      description: 'Customers DynamoDB table name',
      exportName: `${props.projectName}-CustomersTable-${props.environment}`,
    });

    new cdk.CfnOutput(this, 'CampaignsTableName', {
      value: this.campaignsTable.tableName,
      description: 'Campaigns DynamoDB table name',
      exportName: `${props.projectName}-CampaignsTable-${props.environment}`,
    });

    new cdk.CfnOutput(this, 'MessagesTableName', {
      value: this.messagesTable.tableName,
      description: 'Messages DynamoDB table name',
    });

    new cdk.CfnOutput(this, 'ConversationsTableName', {
      value: this.conversationsTable.tableName,
      description: 'Conversations DynamoDB table name',
    });

    if (this.rdsInstance && this.dbSecret) {
      new cdk.CfnOutput(this, 'DBSecretArn', {
        value: this.dbSecret.secretArn,
        description: 'RDS database secret ARN',
      });

      new cdk.CfnOutput(this, 'DBEndpoint', {
        value: this.rdsInstance.dbInstanceEndpointAddress,
        description: 'RDS database endpoint',
      });
    }
  }
}
