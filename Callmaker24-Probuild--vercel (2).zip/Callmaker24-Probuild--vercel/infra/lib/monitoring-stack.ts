import * as cdk from 'aws-cdk-lib';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as sns from 'aws-cdk-lib/aws-sns';
import * as subscriptions from 'aws-cdk-lib/aws-sns-subscriptions';
import * as actions from 'aws-cdk-lib/aws-cloudwatch-actions';
import { Construct } from 'constructs';

interface MonitoringStackProps extends cdk.StackProps {
  projectName: string;
  environment: string;
  apiGateway: apigateway.RestApi;
}

export class MonitoringStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: MonitoringStackProps) {
    super(scope, id, props);

    // Create SNS topic for alarms
    const alarmTopic = new sns.Topic(this, 'AlarmTopic', {
      topicName: `${props.projectName}-alarms-${props.environment}`,
      displayName: 'Marketing Platform Alarms',
    });

    // Add email subscription (configure in AWS Console after deployment)
    // alarmTopic.addSubscription(
    //   new subscriptions.EmailSubscription('your-email@example.com')
    // );

    // ============================================
    // API Gateway Metrics
    // ============================================

    // API Gateway 5XX errors alarm
    const api5xxAlarm = new cloudwatch.Alarm(this, 'Api5xxAlarm', {
      alarmName: `${props.projectName}-api-5xx-${props.environment}`,
      metric: props.apiGateway.metricServerError({
        period: cdk.Duration.minutes(5),
        statistic: 'Sum',
      }),
      threshold: 10,
      evaluationPeriods: 2,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    });

    api5xxAlarm.addAlarmAction(new actions.SnsAction(alarmTopic));

    // API Gateway latency alarm
    const apiLatencyAlarm = new cloudwatch.Alarm(this, 'ApiLatencyAlarm', {
      alarmName: `${props.projectName}-api-latency-${props.environment}`,
      metric: props.apiGateway.metricLatency({
        period: cdk.Duration.minutes(5),
        statistic: 'Average',
      }),
      threshold: 1000, // 1 second
      evaluationPeriods: 2,
      comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
    });

    apiLatencyAlarm.addAlarmAction(new actions.SnsAction(alarmTopic));

    // ============================================
    // CloudWatch Dashboard
    // ============================================

    const dashboard = new cloudwatch.Dashboard(this, 'Dashboard', {
      dashboardName: `${props.projectName}-${props.environment}`,
    });

    // Add API Gateway metrics widget
    dashboard.addWidgets(
      new cloudwatch.GraphWidget({
        title: 'API Requests',
        left: [
          props.apiGateway.metricCount({
            label: 'Total Requests',
            period: cdk.Duration.minutes(5),
          }),
        ],
        width: 12,
      }),
      new cloudwatch.GraphWidget({
        title: 'API Errors',
        left: [
          props.apiGateway.metricClientError({
            label: '4XX Errors',
            period: cdk.Duration.minutes(5),
          }),
          props.apiGateway.metricServerError({
            label: '5XX Errors',
            period: cdk.Duration.minutes(5),
          }),
        ],
        width: 12,
      })
    );

    dashboard.addWidgets(
      new cloudwatch.GraphWidget({
        title: 'API Latency',
        left: [
          props.apiGateway.metricLatency({
            label: 'Average Latency',
            period: cdk.Duration.minutes(5),
            statistic: 'Average',
          }),
        ],
        width: 24,
      })
    );

    // ============================================
    // Outputs
    // ============================================

    new cdk.CfnOutput(this, 'DashboardUrl', {
      value: `https://console.aws.amazon.com/cloudwatch/home?region=${this.region}#dashboards:name=${dashboard.dashboardName}`,
      description: 'CloudWatch Dashboard URL',
    });

    new cdk.CfnOutput(this, 'AlarmTopicArn', {
      value: alarmTopic.topicArn,
      description: 'SNS Topic ARN for alarms',
    });
  }
}
