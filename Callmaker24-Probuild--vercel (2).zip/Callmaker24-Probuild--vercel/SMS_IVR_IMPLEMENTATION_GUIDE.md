# SMS Marketing & IVR System - Complete Implementation Guide

![Status](https://img.shields.io/badge/status-complete-brightgreen.svg)
![Backend](https://img.shields.io/badge/backend-100%25-success.svg)

## 🚀 Overview

This guide documents the complete SMS Marketing and IVR/Voice system implementation for Callmaker24. Both systems are **fully functional** with comprehensive backend Lambda functions integrated with AWS services.

---

## 📋 Table of Contents

- [SMS Marketing System](#sms-marketing-system)
- [IVR/Voice System](#ivr-voice-system)
- [Architecture](#architecture)
- [API Documentation](#api-documentation)
- [Setup Instructions](#setup-instructions)
- [Testing](#testing)

---

## 📱 SMS Marketing System

### Features Implemented

✅ **SMS Campaign Management**
- Bulk SMS sending via AWS SNS
- Personalized message content with customer data
- Campaign scheduling and analytics
- Delivery tracking and failure handling

✅ **SMS Template System**
- Create, read, update, delete templates
- Variable extraction ({{firstName}}, {{lastName}}, etc.)
- Category organization
- Active/inactive status management

✅ **Opt-In/Opt-Out Management**
- Automated STOP/START keyword handling
- Compliance with SMS regulations
- Confirmation messages
- Customer status updates

✅ **Two-Way SMS Conversations**
- Inbound message handling
- Conversation threading
- Message history
- Real-time reply capability

### Backend Files Created

| File | Purpose | Lines |
|------|---------|-------|
| `apps/backend/src/functions/sms/send-sms-campaign.ts` | Send SMS campaigns to segments | 200 |
| `apps/backend/src/functions/sms/manage-templates.ts` | CRUD operations for templates | 400 |
| `apps/backend/src/functions/sms/opt-in-out.ts` | Handle opt-in/opt-out requests | 250 |
| `apps/backend/src/functions/sms/two-way-sms.ts` | Two-way conversation management | 350 |
| `apps/backend/src/lib/sns.ts` | AWS SNS SMS sending utilities | 72 |

**Total SMS Backend Code**: ~1,272 lines

### SMS Campaign Workflow

```
1. Create Campaign (type: SMS)
   ↓
2. Select Customer Segments
   ↓
3. Choose/Create SMS Template
   ↓
4. Preview with Personalization
   ↓
5. Send Campaign
   ↓
6. Track Delivery Status
   ↓
7. Handle Opt-Outs Automatically
   ↓
8. View Analytics
```

### SMS Lambda Functions

#### 1. Send SMS Campaign

**Endpoint**: `POST /sms/campaigns/{id}/send`

**Function**: `send-sms-campaign.ts`

**Features**:
- Retrieves campaign and customer segments
- Filters for SMS opt-in customers only
- Personalizes content per customer
- Adds opt-out footer automatically
- Sends via AWS SNS bulk API
- Records delivery status
- Updates campaign analytics

**Example Request**:
```json
{
  "campaignId": "camp_123",
  "tenantId": "tenant_abc"
}
```

**Example Response**:
```json
{
  "success": true,
  "data": {
    "campaignId": "camp_123",
    "totalRecipients": 150,
    "sent": 148,
    "failed": 2,
    "results": [...]
  }
}
```

#### 2. Manage SMS Templates

**Endpoints**:
- `POST /sms/templates` - Create template
- `GET /sms/templates` - List templates
- `GET /sms/templates/{id}` - Get template
- `PUT /sms/templates/{id}` - Update template
- `DELETE /sms/templates/{id}` - Delete template

**Function**: `manage-templates.ts`

**Features**:
- Automatic variable extraction
- Category management
- Active/inactive status
- Variable validation

**Template Example**:
```json
{
  "id": "tmpl_123",
  "name": "Welcome Message",
  "content": "Hi {{firstName}}, welcome to {{company}}! Reply STOP to unsubscribe.",
  "category": "onboarding",
  "variables": ["firstName", "company"],
  "isActive": true
}
```

#### 3. Opt-In/Opt-Out Management

**Endpoints**:
- `POST /sms/opt-in-out` - Handle opt-in/out
- `POST /sms/incoming-webhook` - Process incoming SMS

**Function**: `opt-in-out.ts`

**Supported Keywords**:
- **Opt-Out**: STOP, STOPALL, UNSUBSCRIBE, CANCEL, END, QUIT
- **Opt-In**: START, UNSTOP, YES, SUBSCRIBE
- **Help**: HELP, INFO, SUPPORT

**Features**:
- Automatic keyword detection
- Customer status updates
- Confirmation messages
- Compliance with SMS regulations

#### 4. Two-Way SMS Conversations

**Endpoints**:
- `POST /sms/conversations/incoming` - Handle incoming message
- `POST /sms/conversations/{id}/reply` - Send reply
- `GET /sms/conversations/{id}` - Get conversation history
- `GET /sms/conversations` - List conversations

**Function**: `two-way-sms.ts`

**Features**:
- Conversation threading
- Message history
- Customer linking
- Real-time replies

**Conversation Structure**:
```json
{
  "id": "conv_123",
  "customerId": "cust_456",
  "phoneNumber": "+1234567890",
  "status": "OPEN",
  "messages": [
    {
      "id": "msg_1",
      "from": "+1234567890",
      "to": "+1987654321",
      "content": "Question about my order",
      "direction": "INBOUND",
      "createdAt": "2024-11-04T10:00:00Z"
    },
    {
      "id": "msg_2",
      "from": "+1987654321",
      "to": "+1234567890",
      "content": "Happy to help! What's your order number?",
      "direction": "OUTBOUND",
      "createdAt": "2024-11-04T10:01:00Z"
    }
  ]
}
```

---

## ☎️ IVR/Voice System

### Features Implemented

✅ **Amazon Connect Integration**
- Outbound call initiation
- Inbound call handling
- Call recording and transcription
- Contact attribute management

✅ **IVR Flow Management**
- Visual flow builder (backend)
- Multiple step types (message, menu, input, transfer, callback)
- Flow execution engine
- Conditional logic support

✅ **Call Analytics**
- Real-time call metrics
- Duration tracking
- Status monitoring
- Historical reporting

✅ **Voice Campaigns**
- Mass outbound calling
- Customer segmentation
- Rate limiting
- Success/failure tracking

### Backend Files Created

| File | Purpose | Lines |
|------|---------|-------|
| `apps/backend/src/lib/connect.ts` | Amazon Connect integration utilities | 150 |
| `apps/backend/src/functions/ivr/initiate-call.ts` | Start outbound calls | 150 |
| `apps/backend/src/functions/ivr/handle-connect-events.ts` | Process Connect events | 250 |
| `apps/backend/src/functions/ivr/manage-flows.ts` | IVR flow CRUD operations | 650 |
| `apps/backend/src/functions/ivr/call-analytics.ts` | Call analytics and reporting | 200 |
| `apps/backend/src/functions/ivr/voice-campaign.ts` | Voice campaign execution | 250 |

**Total IVR Backend Code**: ~1,650 lines

### IVR Call Flow

```
1. Define IVR Flow
   ↓
2. Create Voice Campaign
   ↓
3. Select Customer Segments
   ↓
4. Configure Contact Flow
   ↓
5. Initiate Calls
   ↓
6. Handle Customer Input
   ↓
7. Transfer/Record/Queue
   ↓
8. Track Analytics
```

### IVR Lambda Functions

#### 1. Initiate Outbound Call

**Endpoint**: `POST /ivr/calls/initiate`

**Function**: `initiate-call.ts`

**Features**:
- E.164 phone number formatting
- Contact attribute injection
- Call record creation
- Error handling

**Example Request**:
```json
{
  "phoneNumber": "+1234567890",
  "customerId": "cust_123",
  "contactFlowId": "cf-abc-123",
  "attributes": {
    "callPurpose": "survey",
    "customerName": "John Doe"
  },
  "tenantId": "tenant_abc"
}
```

**Example Response**:
```json
{
  "success": true,
  "data": {
    "callId": "call_123",
    "contactId": "contact_abc-123",
    "status": "INITIATED",
    "phoneNumber": "+1234567890"
  }
}
```

#### 2. Handle Connect Events

**Function**: `handle-connect-events.ts`

**Event Types Handled**:
- **ContactFlowEvent**: Call initiated/in progress
- **CallCompleted**: Call ended
- **RecordingAvailable**: Recording ready

**Features**:
- Automatic call recording
- Status updates
- Duration calculation
- Disconnect reason tracking

**Event Processing**:
```javascript
{
  "Details": {
    "ContactData": {
      "ContactId": "abc-123",
      "InitiationMethod": "INBOUND",
      "CustomerEndpoint": {
        "Address": "+1234567890",
        "Type": "TELEPHONE_NUMBER"
      }
    }
  }
}
```

#### 3. Manage IVR Flows

**Endpoints**:
- `POST /ivr/flows` - Create flow
- `GET /ivr/flows` - List flows
- `GET /ivr/flows/{id}` - Get flow
- `PUT /ivr/flows/{id}` - Update flow
- `DELETE /ivr/flows/{id}` - Delete flow
- `POST /ivr/flows/execute` - Execute flow step

**Function**: `manage-flows.ts`

**IVR Step Types**:

1. **Message**: Play audio or text-to-speech
2. **Menu**: Present options with DTMF input
3. **Input**: Collect digits or speech
4. **Transfer**: Transfer to phone number or agent
5. **Callback**: Queue callback request
6. **Voicemail**: Leave voicemail
7. **Hours**: Check business hours
8. **Queue**: Place in queue

**Flow Example**:
```json
{
  "id": "flow_123",
  "name": "Support Flow",
  "description": "Main customer support IVR",
  "entryStepId": "step_1",
  "steps": [
    {
      "id": "step_1",
      "type": "message",
      "message": "Thank you for calling support. Please listen to the following options.",
      "nextStepId": "step_2"
    },
    {
      "id": "step_2",
      "type": "menu",
      "message": "Press 1 for sales, 2 for support, 3 for billing",
      "options": [
        {
          "digit": "1",
          "label": "Sales",
          "action": "transfer",
          "transferNumber": "+1234567890"
        },
        {
          "digit": "2",
          "label": "Support",
          "action": "queue",
          "nextStepId": "step_3"
        },
        {
          "digit": "3",
          "label": "Billing",
          "action": "transfer",
          "transferNumber": "+1234567891"
        }
      ]
    },
    {
      "id": "step_3",
      "type": "queue",
      "message": "Please hold while we connect you to the next available agent.",
      "queueId": "queue_support"
    }
  ],
  "isActive": true
}
```

#### 4. Call Analytics

**Endpoints**:
- `GET /ivr/analytics` - Get analytics for date range
- `GET /ivr/calls/{id}` - Get call details
- `GET /ivr/calls` - List calls with filters

**Function**: `call-analytics.ts`

**Analytics Metrics**:
```json
{
  "totalCalls": 1500,
  "inboundCalls": 800,
  "outboundCalls": 700,
  "completedCalls": 1350,
  "failedCalls": 150,
  "averageDuration": 180,
  "totalDuration": 270000,
  "callsByStatus": {
    "COMPLETED": 1350,
    "FAILED": 100,
    "NO_ANSWER": 50
  },
  "callsByHour": {
    "09": 150,
    "10": 200,
    "11": 180
  },
  "callsByDay": {
    "2024-11-01": 500,
    "2024-11-02": 520,
    "2024-11-03": 480
  }
}
```

#### 5. Voice Campaigns

**Endpoint**: `POST /voice/campaigns/{id}/send`

**Function**: `voice-campaign.ts`

**Features**:
- Mass outbound calling
- Customer segmentation
- Rate limiting (configurable)
- Batch processing
- Success/failure tracking

**Campaign Execution**:
```json
{
  "success": true,
  "data": {
    "campaignId": "camp_voice_123",
    "totalRecipients": 500,
    "initiated": 485,
    "failed": 15,
    "results": [...]
  }
}
```

---

## 🏗️ Architecture

### SMS Architecture

```
┌─────────────┐
│   Frontend  │
│   (React)   │
└──────┬──────┘
       │
       ├─────► POST /sms/campaigns/{id}/send
       ├─────► POST /sms/templates
       ├─────► GET  /sms/conversations
       │
       ▼
┌──────────────────────────────────┐
│      API Gateway                 │
└──────────┬───────────────────────┘
           │
           ├──► send-sms-campaign.ts ──► AWS SNS ──► Customer Phone
           ├──► manage-templates.ts ──► DynamoDB (Templates)
           ├──► opt-in-out.ts ──► DynamoDB (Customers)
           └──► two-way-sms.ts ──► DynamoDB (Conversations)
                       │
                       └──► SNS Webhook ◄── Incoming SMS
```

### IVR Architecture

```
┌─────────────┐
│   Frontend  │
│   (React)   │
└──────┬──────┘
       │
       ├─────► POST /ivr/calls/initiate
       ├─────► POST /ivr/flows
       ├─────► GET  /ivr/analytics
       │
       ▼
┌──────────────────────────────────┐
│      API Gateway                 │
└──────────┬───────────────────────┘
           │
           ├──► initiate-call.ts ──────────────┐
           ├──► manage-flows.ts ──► DynamoDB   │
           ├──► call-analytics.ts ──► DynamoDB │
           └──► voice-campaign.ts ────────────┐│
                                               ││
                         ┌────────────────────▼▼─────────┐
                         │   Amazon Connect              │
                         │   - Contact Flows             │
                         │   - Call Recording            │
                         │   - Transcription             │
                         └────────┬──────────────────────┘
                                  │
                         ┌────────▼──────────┐
                         │  Connect Events   │
                         │  (EventBridge)    │
                         └────────┬──────────┘
                                  │
                         ┌────────▼──────────────────┐
                         │  handle-connect-events.ts │
                         │  - Update call status     │
                         │  - Start/stop recording   │
                         └───────────────────────────┘
```

---

## 📡 API Documentation

### SMS Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/sms/campaigns/{id}/send` | Send SMS campaign to segment |
| POST | `/sms/templates` | Create SMS template |
| GET | `/sms/templates` | List all templates |
| GET | `/sms/templates/{id}` | Get template details |
| PUT | `/sms/templates/{id}` | Update template |
| DELETE | `/sms/templates/{id}` | Delete template |
| POST | `/sms/opt-in-out` | Handle opt-in/opt-out |
| POST | `/sms/incoming-webhook` | Process incoming SMS |
| POST | `/sms/conversations/incoming` | Handle incoming message |
| POST | `/sms/conversations/{id}/reply` | Send SMS reply |
| GET | `/sms/conversations/{id}` | Get conversation history |
| GET | `/sms/conversations` | List conversations |

### IVR Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/ivr/calls/initiate` | Initiate outbound call |
| POST | `/ivr/flows` | Create IVR flow |
| GET | `/ivr/flows` | List IVR flows |
| GET | `/ivr/flows/{id}` | Get flow details |
| PUT | `/ivr/flows/{id}` | Update flow |
| DELETE | `/ivr/flows/{id}` | Delete flow |
| POST | `/ivr/flows/execute` | Execute flow step |
| GET | `/ivr/analytics` | Get call analytics |
| GET | `/ivr/calls/{id}` | Get call details |
| GET | `/ivr/calls` | List calls |
| POST | `/voice/campaigns/{id}/send` | Send voice campaign |

---

## ⚙️ Setup Instructions

### Prerequisites

1. **AWS Services**:
   - AWS SNS (for SMS)
   - Amazon Connect (for IVR/Voice)
   - DynamoDB (for data storage)
   - EventBridge (for Connect events)
   - Lambda (serverless functions)

2. **Environment Variables**:

```env
# SMS Configuration
SMS_SENDER_NUMBER=+1234567890
SMS_TEMPLATES_TABLE=sms-templates
SMS_CONVERSATIONS_TABLE=sms-conversations
SMS_MESSAGES_TABLE=sms-messages

# IVR Configuration
CONNECT_INSTANCE_ID=abc-123-def-456
CONNECT_PHONE_NUMBER=+1987654321
CALLS_TABLE=calls
IVR_FLOWS_TABLE=ivr-flows
AUTO_RECORD_CALLS=true
MAX_CONCURRENT_CALLS=10

# AWS General
AWS_REGION=us-east-1
```

### Step 1: Deploy Lambda Functions

```bash
cd apps/backend

# Deploy SMS functions
aws lambda create-function --function-name send-sms-campaign \
  --runtime nodejs20.x \
  --handler dist/functions/sms/send-sms-campaign.handler \
  --role arn:aws:iam::ACCOUNT:role/lambda-exec-role \
  --zip-file fileb://dist.zip

# Deploy IVR functions
aws lambda create-function --function-name initiate-call \
  --runtime nodejs20.x \
  --handler dist/functions/ivr/initiate-call.handler \
  --role arn:aws:iam::ACCOUNT:role/lambda-exec-role \
  --zip-file fileb://dist.zip

# ... repeat for other functions
```

### Step 2: Configure Amazon Connect

1. **Create Connect Instance**:
   - Go to Amazon Connect console
   - Create new instance
   - Note the instance ID

2. **Set Up Phone Number**:
   - Claim phone number
   - Configure for outbound calling

3. **Create Contact Flows**:
   - Use the IVR flow builder (frontend)
   - Deploy contact flows
   - Note contact flow IDs

### Step 3: Configure AWS SNS

1. **Enable SMS**:
   - Go to SNS console
   - Request SMS production access
   - Set spending limits

2. **Configure Sender ID** (optional):
   - Register company name
   - Configure sender ID

### Step 4: Set Up DynamoDB Tables

```bash
# Create SMS tables
aws dynamodb create-table --table-name sms-templates \
  --attribute-definitions AttributeName=id,AttributeType=S AttributeName=tenantId,AttributeType=S \
  --key-schema AttributeName=id,KeyType=HASH \
  --global-secondary-indexes IndexName=tenantId-index,Keys=[{AttributeName=tenantId,KeyType=HASH}] \
  --billing-mode PAY_PER_REQUEST

# Create IVR tables
aws dynamodb create-table --table-name calls \
  --attribute-definitions AttributeName=id,AttributeType=S AttributeName=tenantId,AttributeType=S \
  --key-schema AttributeName=id,KeyType=HASH \
  --global-secondary-indexes IndexName=tenantId-createdAt-index \
  --billing-mode PAY_PER_REQUEST

# ... create other tables
```

### Step 5: Configure API Gateway

1. **Create REST API**
2. **Add Resources**:
   - `/sms/*`
   - `/ivr/*`
   - `/voice/*`
3. **Integrate with Lambda functions**
4. **Deploy API**

---

## 🧪 Testing

### SMS Testing

#### 1. Test SMS Campaign Send

```bash
curl -X POST https://api.example.com/sms/campaigns/camp_123/send \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: tenant_abc" \
  -d '{}'
```

#### 2. Test Template Creation

```bash
curl -X POST https://api.example.com/sms/templates \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: tenant_abc" \
  -d '{
    "name": "Welcome Message",
    "content": "Hi {{firstName}}, welcome! Reply STOP to unsubscribe.",
    "category": "onboarding"
  }'
```

#### 3. Test Opt-Out

```bash
curl -X POST https://api.example.com/sms/opt-in-out \
  -H "Content-Type: application/json" \
  -d '{
    "phoneNumber": "+1234567890",
    "action": "OPT_OUT",
    "tenantId": "tenant_abc"
  }'
```

### IVR Testing

#### 1. Test Outbound Call

```bash
curl -X POST https://api.example.com/ivr/calls/initiate \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: tenant_abc" \
  -d '{
    "phoneNumber": "+1234567890",
    "contactFlowId": "cf-abc-123",
    "customerId": "cust_123"
  }'
```

#### 2. Test IVR Flow Creation

```bash
curl -X POST https://api.example.com/ivr/flows \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: tenant_abc" \
  -d '{
    "name": "Test Flow",
    "steps": [
      {
        "id": "step_1",
        "type": "message",
        "message": "Welcome",
        "nextStepId": "step_2"
      }
    ],
    "entryStepId": "step_1"
  }'
```

#### 3. Test Call Analytics

```bash
curl -X GET "https://api.example.com/ivr/analytics?startDate=2024-11-01&endDate=2024-11-04" \
  -H "X-Tenant-ID: tenant_abc"
```

---

## 📊 Code Statistics

### SMS System
- **Lambda Functions**: 4
- **Total Lines**: ~1,272
- **Coverage**: 100% (all features implemented)

### IVR System
- **Lambda Functions**: 6
- **Total Lines**: ~1,650
- **Coverage**: 100% (all features implemented)

### Combined
- **Total Lambda Functions**: 10
- **Total Code Lines**: ~2,922
- **Status**: ✅ **Production Ready**

---

## 🎯 Next Steps

### Frontend Development (Optional)

While all backend functionality is complete, you can build frontend UI for:

1. **SMS Management**:
   - Campaign creation wizard
   - Template editor
   - Conversation inbox
   - Analytics dashboard

2. **IVR Management**:
   - Visual flow builder (drag-and-drop)
   - Call monitoring dashboard
   - Real-time call analytics
   - Recording player

3. **Voice Campaigns**:
   - Campaign wizard
   - Customer segment selector
   - Success/failure reports

---

## 🔒 Security & Compliance

### SMS Compliance
- ✅ Automatic opt-out handling
- ✅ STOP keyword processing
- ✅ Confirmation messages
- ✅ Customer consent tracking

### IVR Security
- ✅ E.164 phone number validation
- ✅ Call recording encryption
- ✅ Secure attribute injection
- ✅ Rate limiting

---

## 📝 License

This implementation is part of the Callmaker24 platform. All rights reserved.

---

**Version**: 1.0.0
**Last Updated**: November 2024
**Status**: ✅ Production Ready
