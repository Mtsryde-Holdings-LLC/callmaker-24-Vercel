# Quick Start Guide

Get Marketing Platform Pro running in under 30 minutes!

## Prerequisites

- Node.js 18+ installed
- AWS Account with CLI configured
- npm or yarn

## 1. Clone and Install (2 minutes)

```bash
git clone <repository-url>
cd marketing-platform
npm install
```

## 2. Configure AWS (5 minutes)

```bash
# Configure AWS CLI
aws configure
# Enter your credentials

# Install AWS CDK globally
npm install -g aws-cdk

# Verify
aws sts get-caller-identity
```

## 3. Deploy Infrastructure (10 minutes)

```bash
# Navigate to infra
cd infra
npm install

# Bootstrap CDK (first time only)
export AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
cdk bootstrap aws://$AWS_ACCOUNT_ID/us-east-1

# Deploy all stacks
npm run deploy:dev
```

**Wait for deployment** - This will create:
- ✅ Cognito User Pool
- ✅ DynamoDB Tables
- ✅ API Gateway
- ✅ Lambda Functions
- ✅ S3 Bucket & CloudFront
- ✅ SES Configuration
- ✅ Monitoring

## 4. Configure Environment (3 minutes)

```bash
# Go back to root
cd ..

# Copy environment template
cp .env.example .env.local

# Get deployment outputs
export USER_POOL_ID=$(aws cloudformation describe-stacks \
  --stack-name MarketingPlatform-Auth-development \
  --query 'Stacks[0].Outputs[?OutputKey==`UserPoolId`].OutputValue' \
  --output text)

export CLIENT_ID=$(aws cloudformation describe-stacks \
  --stack-name MarketingPlatform-Auth-development \
  --query 'Stacks[0].Outputs[?OutputKey==`UserPoolClientId`].OutputValue' \
  --output text)

export API_URL=$(aws cloudformation describe-stacks \
  --stack-name MarketingPlatform-Api-development \
  --query 'Stacks[0].Outputs[?OutputKey==`ApiUrl`].OutputValue' \
  --output text)

# Update .env.local
echo "NEXT_PUBLIC_COGNITO_USER_POOL_ID=$USER_POOL_ID" >> .env.local
echo "NEXT_PUBLIC_COGNITO_CLIENT_ID=$CLIENT_ID" >> .env.local
echo "NEXT_PUBLIC_API_URL=$API_URL" >> .env.local
```

## 5. Create Admin User (2 minutes)

```bash
# Create admin user
aws cognito-idp admin-create-user \
  --user-pool-id $USER_POOL_ID \
  --username admin@example.com \
  --user-attributes Name=email,Value=admin@example.com Name=email_verified,Value=true \
  --temporary-password "TempPass123!" \
  --message-action SUPPRESS

# Add to Admins group
aws cognito-idp admin-add-user-to-group \
  --user-pool-id $USER_POOL_ID \
  --username admin@example.com \
  --group-name Admins
```

## 6. Start Development Server (1 minute)

```bash
npm run dev
```

**Open**: http://localhost:3000

## 7. Login & Explore! 🎉

1. Navigate to http://localhost:3000
2. Login with:
   - Email: `admin@example.com`
   - Password: `TempPass123!`
3. You'll be prompted to change password
4. Explore the platform!

---

## Optional: Seed Sample Data

```bash
npm run seed
```

This adds:
- 10 sample customers
- 3 sample campaigns

---

## Next Steps

### Configure External Services

#### Stripe (for payments)
1. Sign up at https://stripe.com
2. Get test API key
3. Add to `.env.local`:
   ```
   STRIPE_SECRET_KEY=sk_test_...
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
   ```

#### OpenAI (for AI features)
1. Sign up at https://openai.com
2. Create API key
3. Add to `.env.local`:
   ```
   OPENAI_API_KEY=sk-...
   ```

#### SES Email Sending
```bash
# Verify your email
aws ses verify-email-identity --email-address your-email@domain.com

# Check verification status
aws ses get-identity-verification-attributes --identities your-email@domain.com
```

### Customize Theme

Edit `apps/frontend/src/styles/theme.ts`:

```typescript
export const theme = {
  colors: {
    primary: {
      600: '#YOUR_COLOR', // Main primary color
    },
    // ... other colors
  },
};
```

### Add More Features

The platform includes framework for:
- ✅ Email campaigns (configured)
- ✅ SMS campaigns (needs Twilio or SNS setup)
- ✅ AI content generation (needs OpenAI key)
- ✅ Customer chat (WebSocket ready)
- ✅ IVR system (needs Amazon Connect setup)
- ✅ Analytics & reports (configured)

---

## Troubleshooting

### "CDK Bootstrap Error"
```bash
# Run bootstrap with explicit account/region
cdk bootstrap aws://YOUR_ACCOUNT_ID/us-east-1
```

### "Cannot find module"
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### "API returns 401"
- Check Cognito configuration in `.env.local`
- Verify user exists in User Pool
- Check token hasn't expired

### "Deployment takes too long"
- This is normal for first deployment (10-15 minutes)
- Subsequent deployments are faster (2-5 minutes)

---

## Development URLs

After setup, you'll have:

- **Frontend**: http://localhost:3000
- **API**: https://xxxxx.execute-api.us-east-1.amazonaws.com/development
- **CloudWatch Logs**: AWS Console > CloudWatch > Logs
- **DynamoDB Tables**: AWS Console > DynamoDB
- **Cognito Users**: AWS Console > Cognito

---

## Support

- **Documentation**: See `docs/` folder
- **Issues**: GitHub Issues
- **Full Guide**: See `README.md`

---

**That's it!** You now have a fully functional marketing platform running on AWS. 🚀

For production deployment, see `docs/operations/deployment.md`
